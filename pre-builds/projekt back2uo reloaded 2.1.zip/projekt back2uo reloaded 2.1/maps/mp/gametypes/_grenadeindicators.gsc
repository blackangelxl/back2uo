init()
{
	level thread onPlayerConnect();
}

onPlayerConnect()
{
	for(;;)
	{
		level waittill("connecting", player);

		player thread updateGrenadeIndicators();
	}
}

updateGrenadeIndicators()
{
	self endon("disconnect");
	
	for(;;)
	{
	
	// Granaten Indecator Abfrage ( 0 = Aus | 1 = An )
	if(game["back2uo_granatenindecator_enable"])
	{
  	// Fullscreen scale aktiviert
		self setClientCvar("cg_hudGrenadeIconHeight", "25");
		self setClientCvar("cg_hudGrenadeIconWidth", "25");
		self setClientCvar("cg_hudGrenadeIconOffset", "50");
		//self setClientCvar("cg_hudGrenadeIconInScope", "0");
		//self setClientCvar("cg_hudGrenadeIconMaxRange", "250");
		self setClientCvar("cg_hudGrenadePointerHeight", "12");
		self setClientCvar("cg_hudGrenadePointerWidth", "25");
		self setClientCvar("cg_hudGrenadePointerPivot", "12 27");
		self setClientCvar("cg_fovscale", "1");	
	}else{
		// Fullscreen scale deaktiviert
		self setClientCvar("cg_hudGrenadeIconHeight", "0");
		self setClientCvar("cg_hudGrenadeIconWidth", "0");
		self setClientCvar("cg_hudGrenadeIconOffset", "0");
		//self setClientCvar("cg_hudGrenadeIconInScope", "0");
		//self setClientCvar("cg_hudGrenadeIconMaxRange", "0");
		self setClientCvar("cg_hudGrenadePointerHeight", "0");
		self setClientCvar("cg_hudGrenadePointerWidth", "0");
		self setClientCvar("cg_hudGrenadePointerPivot", "0 0");
		self setClientCvar("cg_fovscale", "0");
	}	

		while(!isSplitScreen())
			wait .05;
			
		// Splitscreen scale
		self setClientCvar("cg_hudGrenadeIconHeight", "37.5");
		self setClientCvar("cg_hudGrenadeIconWidth", "37.5");
		self setClientCvar("cg_hudGrenadeIconOffset", "75");
		//self setClientCvar("cg_hudGrenadeIconInScope", "0");
		//self setClientCvar("cg_hudGrenadeIconMaxRange", "250");
		self setClientCvar("cg_hudGrenadePointerHeight", "18");
		self setClientCvar("cg_hudGrenadePointerWidth", "37.5");
		self setClientCvar("cg_hudGrenadePointerPivot", "18 40.5");
		self setClientCvar("cg_fovscale", ".75");
		
		while(isSplitScreen())
			wait .05;
	}
}

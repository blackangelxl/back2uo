init()
{
  // Minifadenkreuz Anzeige ( 0 = Aus | 1 = Ein // Optimal = 0 )
	if(!(game["back2uo_minicrosshair_enable"])) return;
	
	// Precache Shader
	precacheShader("damage_feedback");

  // Weiterleitung Player Connect
	level thread onPlayerConnect();
}

onPlayerConnect()
{
	for(;;)
	{
		level waittill("connecting", player);

	  // Minifadenkreuz Anzeige ( 0 = Aus | 1 = Ein // Optimal = 0 )
    if(game["back2uo_minicrosshair_enable"] == 1)
    {
		player.hud_damagefeedback = newClientHudElem(player);
		player.hud_damagefeedback.horzAlign = "center";
		player.hud_damagefeedback.vertAlign = "middle";
		player.hud_damagefeedback.x = -12;
		player.hud_damagefeedback.y = -12;
		player.hud_damagefeedback.alpha = 0;
		player.hud_damagefeedback.archived = true;
		player.hud_damagefeedback setShader("damage_feedback", 24, 24);
		}
	}
}

updateDamageFeedback()
{
	if(isPlayer(self))
	{
	  // Minifadenkreuz Anzeige ( 0 = Aus | 1 = Ein // Optimal = 0 )
    if(game["back2uo_minicrosshair_enable"] == 1)
    {
		self.hud_damagefeedback.alpha = 1;
		self.hud_damagefeedback fadeOverTime(1);
		self.hud_damagefeedback.alpha = 0;
		self playlocalsound("MP_hit_alert");
		}
	}
}

/////////////////////////////////////
// Back2Uo Client Settings - Init //
///////////////////////////////////
back2uo_clientset_init()
{
 // Abfrage
 if(isdefined(self.pers["client_set"])) return;
  self.pers["client_set"] = true; 

 // Blood Abfrage ( 0 = Aus | 1 = Ein // Standart = 1 )
 game["back2uo_blood"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_blood", 1, 0, 1);
 self setClientCvar("cg_blood", game["back2uo_blood"]);

 // Crosshair Abfrage ( 0 = Aus | 1 = Ein // Standart = 1 )
 game["back2uo_drawcrosshair"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_crosshair", 1, 0, 1);
 self setClientCvar("cg_drawcrosshair", game["back2uo_drawcrosshair"]);
 
 // Turret Crosshair Abfrage ( 0 = Aus | 1 = Ein // Standart = 1 )
 game["back2uo_drawturretcrosshair"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_turretcrosshair", 1, 0, 1);
 self setClientCvar("cg_drawturretcrosshair", game["back2uo_drawturretcrosshair"]);
   
 // Crosshair Name ( 0 = Aus | 1 = Ein // Standart = 1 )
 game["back2uo_drawcrosshairnames"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_crosshairnames", 1, 0, 1);
 self setClientCvar("cg_drawcrosshairnames", game["back2uo_drawcrosshairnames"]);
 
 // Rotes Crosshair ( 0 = Aus | 1 = Ein )
 game["back2uo_crosshairenemycolor"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_redcrosshair", 1, 0, 1); 
 self setClientCvar("cg_crosshairenemycolor", game["back2uo_crosshairenemycolor"]);
	
 // Bomben Punkte Anzeige ( 0 = Aus | 1 = Ein )
 game["back2uo_drawmantlehint"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_objindekator", 1, 0, 1);  
 self setClientCvar("cg_drawmantlehint", game["back2uo_drawmantlehint"]); 
 		 
 // Hud Compass Ausblendung 
 game["back2uo_hudcompassfade"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_hudcompassfade", 1, 0, 1); 
 self setClientCvar("hud_fade_compass", game["back2uo_hudcompassfade"]);

 // Hud Stance Ausblendung 
 game["back2uo_hudstancefade"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_hudstancefade", 1, 0, 1); 
 self setClientCvar("hud_fade_stance", game["back2uo_hudstancefade"]); 
 
 // Hud Offhand Ausblendung 
 game["back2uo_hudoffhandfade"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_hudoffhandfade", 1, 0, 1); 
 self setClientCvar("hud_fade_offhand", game["back2uo_hudoffhandfade"]);
 
 // Hud Ammo Display Ausblendung 
 game["back2uo_hudammodisplayfade"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_hudammodisplayfade", 1, 0, 1); 
 self setClientCvar("hud_fade_ammodisplay", game["back2uo_hudammodisplayfade"]);
 
 // Anti Sound �berlagerung
 self setClientCvar("mss_Q3fs", 1); 
 
 // Compass Size
 game["back2uo_hudcompasssize"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_hudcompasssize", 1, 0, 1);
 self setClientCvar("cg_hudCompassSize", game["back2uo_hudcompasssize"]); 

 // Red Compass Dots
 game["back2uo_compassreddots"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_redcompassdots", 0, 0, 1);
 self setClientCvar("cg_hudCompassSoundPingFadeTime", game["back2uo_compassreddots"]); 
}

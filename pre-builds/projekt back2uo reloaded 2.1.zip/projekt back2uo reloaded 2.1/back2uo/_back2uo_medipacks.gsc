//////////////////////////
// Back2Uo Drop Health //
////////////////////////
back2uo_dropHealthPacks()
{
 // Abfrage
 if(!game["back2uo_medipacks_enable"]) return;

 // String
 trace = bulletTrace(self.origin, self.origin + (0,0,-1000),false,undefined);	

 // Item Model
 item_health = spawn("script_model", (0,0,0));	
 item_health setModel("xmodel/health_medium");
 item_health.targetname = "item_healths";
 item_health hide();    	
 item_health.origin = trace["position"] + (0, 0, 1);
 item_health.angles = (0, randomint(360), 0);
 item_health show(); 
	
 // Weiterleitung
 item_health thread back2uo_healththink();
 item_health thread back2uo_healthclear();
}

///////////////////////////
// Back2Uo Health Think //
/////////////////////////
back2uo_healththink()
{
 // Abfrage
 if(!game["back2uo_medipacks_enable"]) return;

 // While Schleife
 while(1)
 {
  // Warteschleife 0.2 Sekunden
  wait 0.2;

  // Abfrage
	if(!isDefined(self))
  return;

  // String
	player = "";
	players = getentarray("player", "classname");

  // For Schleife
	for(i = 0; i < players.size; i++)
	{  
   // String           
	 player = players[i];

   // Abfrage
	 if(player.sessionstate == "playing" && distance(self.origin,player.origin) < 50 && player.health < player.maxhealth)
	 {
	  // String
		player endon("disconnect");
		player.health += 1 * level.back2uo_medipacks_health;

    // Abfrage
		if(player.health > player.maxhealth)
    // String
    player.health = player.maxhealth;

    // Play Sound
		player playLocalSound("health_pickup_medium");

		// Abfrage
    if(isDefined(self))
    self delete();

    // Return
		return;
	 }	 
	}				
 }
}

///////////////////////////
// Back2Uo Health Clear //
/////////////////////////
back2uo_healthclear()
{
 // Abfrage
 if(!isDefined(self))
 return;

 // Abfrage
 if(!level.back2uo_medipacks_hide < 1)
 { 
  // Warteschleife 
  wait level.back2uo_medipacks_hide;
    
  // Abfrage
  if(isDefined(self))
  self delete();
 }
}

///////////////////
// Back2Uo Main //
/////////////////
back2uo_main()
{
 // Back2Uo MOD Enable
 game["back2uo_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_status", 0, 0, 1);
 
 // Weiterleitung Back2uo load Inits
 back2uo_load_inits();
 
 // Weiterleitung Cod 2 Settings
 back2uo_cod2_settings();
 
 // Weiterleitung Server Info
 back2uo_serverinfo();
}

/////////////////////////
// Back2Uo Load Inits //
///////////////////////
back2uo_load_inits()
{
 ////////////////////
 // Binocular Hud //
 //////////////////
 
  // Back2Uo Binocular Distance Hud Enable
  game["back2uo_binocularhud_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_binocular_distance", 0, 0, 1);
  
  // Abfrage
  if(game["back2uo_binocularhud_enable"])
  {
   // Precache Text
   level.back2uo_binocularm1 = &"BACK2UOMOD_BINOCULAR_DISTANCE";
   level.back2uo_binocularm2 = &"BACK2UOMOD_BINOCULAR_METERS";
   level.back2uo_binocularm3 = &"BACK2UOMOD_BINOCULAR_UNKNOWN";
   level.back2uo_binocularm4 = &"BACK2UOMOD_BINOCULAR_NONE";
   
   // Precache String
   precacheString(level.back2uo_binocularm1);
   precacheString(level.back2uo_binocularm2);
   precacheString(level.back2uo_binocularm3);
   precacheString(level.back2uo_binocularm4);
  }

 /////////////////////
 // Blood Splatter //
 /////////////////// 

  // Back2Uo Blood Splatter Enable
  game["back2uo_bloodsplater_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_bloodsplater", 0, 0, 1); 

  // Abfrage
  if(game["back2uo_bloodsplater_enable"])
  {
   // Precache 
   precacheShader("gfx/impact/flesh_hit2");
   precacheShader("gfx/impact/flesh_hitgib");		
  }
  
 //////////////
 // Compass //
 ////////////

  // Abfrage
  if(game["back2uo_enable"])
  {	
   // Precache Compass Shader
   precacheShader("gfx/custom/back2uo_compasszeiger.tga");
  } 
   
 ////////////////
 // Healthbar //
 //////////////    

  // Back2Uo Healthbar Enable
  game["back2uo_healthbar_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_healthbar", 0, 0, 1);
  
  // Abfrage
  if(game["back2uo_healthbar_enable"])
  {
   // Precache Healthbar Shader
   precacheShader("gfx/hud/hud@health_back.tga");
   precacheShader("gfx/hud/hud@health_bar.tga");
   precacheShader("gfx/hud/hud@health_cross.tga");	
  }    
  
 //////////////////
 // Hud FX Draw //
 //////////////// 

  // Back2Uo Hud FX Draw Enable
  game["back2uo_hudfx_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_hudfx_aktiv", 0, 0, 1);
  
  // Abfrage
  if(game["back2uo_hudfx_enable"])
  { 
   // Precache Shader 
   precacheShader("gfx/custom/back2uo_hud_rainfx.tga");	
   precacheShader("gfx/custom/back2uo_hud_thunderfx.tga");
   precacheShader("gfx/custom/back2uo_hud_snowfx.tga");
   precacheShader("gfx/custom/back2uo_hud_flakfx.tga");
   precacheShader("gfx/custom/back2uo_hud_mortarfx.tga"); 
   precacheShader("gfx/custom/back2uo_hud_artilleryfx.tga");
  }  
  
 //////////////////////
 // Player Position //
 ////////////////////     
   
  // Back2Uo Player Position Enable
  game["back2uo_playerposition_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_playerposition", 0, 0, 1);
 
  // Abfrage
  if(game["back2uo_playerposition_enable"])
  {
   // Precache Position Shader
   precacheShader("gfx/custom/stance_bg.tga");	
  } 
  
 ///////////////////
 // Player Score //
 ///////////////// 
 
  // Back2Uo Player Score Enable
  game["back2uo_playerscore_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_playerscore", 0, 0, 1); 
  
  // String
  level.back2uo_hudscore_alpha = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_hudscore_alpha", 1, 0, 1, "float");   
  
  // Abfrage
  if(game["back2uo_playerscore_enable"] || getcvar("g_gametype") == "dm")
  {   
   // Precache Flags
   precacheShader("gfx/custom/back2uo_flag_ammis.tga");
   precacheShader("gfx/custom/back2uo_flag_british.tga"); 
   precacheShader("gfx/custom/back2uo_flag_russian.tga");
   precacheShader("gfx/custom/back2uo_flag_german.tga"); 
  }  
  
 /////////////////////
 // Player Ranking //
 /////////////////// 
 
  // Back2Uo Player Ranking
  game["back2uo_ranking_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_playerranking", 0, 0, 1);
  
  // String
  level.back2uo_ranking_level1 = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_ranking_level1", 10, 1, 100, "int");
  level.back2uo_ranking_level2 = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_ranking_level2", 20, 1, 100, "int");
  level.back2uo_ranking_level3 = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_ranking_level3", 30, 1, 100, "int");
  level.back2uo_ranking_level4 = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_ranking_level4", 40, 1, 100, "int");
  
  // String
  level.back2uo_binocular_onrank = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_binocular_onrang", 3, 0, 4, "int");
  level.back2uo_artillery_onrank = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_artillery_onrang", 4, 0, 4, "int");  
   
  // Abfrage
  if(getcvar("g_gametype") == "hq" || getcvar("g_gametype") == "ctf")
	{
	 // String
	 bigranking = 10;
	 
   // String
   level.back2uo_ranking_level1 = int(level.back2uo_ranking_level1 * bigranking);
   level.back2uo_ranking_level2 = int(level.back2uo_ranking_level2 * bigranking);
   level.back2uo_ranking_level3 = int(level.back2uo_ranking_level3 * bigranking);
   level.back2uo_ranking_level4 = int(level.back2uo_ranking_level4 * bigranking);    
  }  
  
  // String
  level.back2uo_points_alive = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_points_alive", 0, 10, 3, "int");
  level.back2uo_points_plant = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_points_plant", 0, 10, 3, "int");
  level.back2uo_points_defuse = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_point_defuse", 0, 10, 3, "int"); 
   
  // String
  level.back2uo_rang1_getgranade = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rang1_getgranade", 1, 0, 10, "int");
  level.back2uo_rang1_getsmoke = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rang1_getsmoke", 0, 0, 10, "int");
  level.back2uo_rang1_getpriammo = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rang1_getpriammo", 0, 0, 99, "int");
  level.back2uo_rang1_getsekammo = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rang1_getsekammo", 10, 0, 99, "int");
   
  // String
  level.back2uo_rang2_getgranade = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rang2_getgranade", 1, 0, 10, "int");
  level.back2uo_rang2_getsmoke = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rang2_getsmoke", 1, 0, 10, "int");
  level.back2uo_rang2_getpriammo = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rang2_getpriammo", 10, 0, 99, "int");
  level.back2uo_rang2_getsekammo = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rang2_getsekammo", 10, 0, 99, "int");   
   
  // String
  level.back2uo_rang3_getgranade = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rang3_getgranade", 2, 0, 10, "int");
  level.back2uo_rang3_getsmoke = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rang3_getsmoke", 1, 0, 10, "int");
  level.back2uo_rang3_getpriammo = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rang3_getpriammo", 20, 0, 99, "int");
  level.back2uo_rang3_getsekammo = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rang3_getsekammo", 20, 0, 99, "int");
      
  // String
  level.back2uo_rang4_getgranade = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rang4_getgranade", 2, 0, 10, "int");
  level.back2uo_rang4_getsmoke = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rang4_getsmoke", 1, 0, 10, "int");
  level.back2uo_rang4_getpriammo = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rang4_getpriammo", 30, 0, 99, "int");
  level.back2uo_rang4_getsekammo = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rang4_getsekammo", 30, 0, 99, "int");
  
  // Abfrage
  if(game["back2uo_ranking_enable"])
  {    
   // Precache Shader
   precacheShader("gfx/custom/back2uo_ranking_lv1.tga");
   precacheShader("gfx/custom/back2uo_ranking_lv2.tga");
   precacheShader("gfx/custom/back2uo_ranking_lv3.tga");
   precacheShader("gfx/custom/back2uo_ranking_lv4.tga");
   precacheShader("gfx/custom/back2uo_ranking_lv5.tga");
   
   // Precache Status Icon
   precacheStatusIcon("gfx/custom/back2uo_ranking_lv1.tga");
   precacheStatusIcon("gfx/custom/back2uo_ranking_lv2.tga");
   precacheStatusIcon("gfx/custom/back2uo_ranking_lv3.tga");
   precacheStatusIcon("gfx/custom/back2uo_ranking_lv4.tga");
   precacheStatusIcon("gfx/custom/back2uo_ranking_lv5.tga");
   precacheStatusIcon("gfx/custom/back2uo_deadicon.tga");
  }
  
 ////////////////////
 // Player Points //
 //////////////////
 
  // Back2Uo Player Points
  game["back2uo_playerpoints_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_points_system", 0, 0, 1);

  // String - (+) Points
  level.back2uo_sd_plant_points = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_points_plant", 3, 0, 5, "int");
  level.back2uo_sd_defuse_points = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_points_defuse", 3, 0, 5, "int");
  level.back2uo_playeralive = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_points_alive", 3, 0, 5, "int");
  
  // String - (-) Points
  level.back2uo_selfkill_mpoints = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_mpoints_suicide", 1, 0, 5, "int");

  
 /////////////////
 // Team Score //
 ///////////////
 
  // Back2Uo Team Score Enable
  game["back2uo_teamscore_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_teamscore", 0, 0, 1);
  	
  // String
  level.back2uo_hudscore_alpha = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_hudscore_alpha", 1, 0, 1, "float");
  
  // Abfrage
  if(game["back2uo_teamscore_enable"] || getcvar("g_gametype") != "dm")
  { 
   // Precache String
   level.cuticon = &"|";
   precacheString(level.cuticon);
 
   // Precache Flags
   precacheShader("gfx/custom/back2uo_flag_ammis.tga");
   precacheShader("gfx/custom/back2uo_flag_british.tga");  
   precacheShader("gfx/custom/back2uo_flag_russian.tga");
   precacheShader("gfx/custom/back2uo_flag_german.tga");   
 
   // Precache Kill & Death Icon
   precacheShader("gfx/custom/back2uo_liveicon.tga");
   precacheShader("gfx/custom/back2uo_deadicon.tga");
  }   
  
 ////////////////////////////////
 // Back2Uo Talking HeadIcons //
 //////////////////////////////

  // Back2Uo Talking HeadIcons Enable
  game["back2uo_talkingicon"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_talkingicon", 0, 0, 1);  
  
 ///////////////////////
 // Call Voting Menu // 
 /////////////////////
  
  // Back2Uo Kickingplayer Enable
  game["back2uo_playerkickvote_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_vote_playerkick", 0, 0, 1);

  // Back2Uo Vote Gametype + Map Enable
  game["back2uo_vote_gametype_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_vote_gametype", 0, 0, 1);

  // Back2Uo Vote Map Enable
  game["back2uo_vote_map_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_vote_map", 0, 0, 1); 

  // Back2Uo Vote Next Map in Rotation Enable
  game["back2uo_vote_nextmap_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_vote_nextmap", 0, 0, 1);

  // Back2Uo Vote Map Restart Enable
  game["back2uo_vote_map_restart_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_vote_maprestart", 0 ,0, 1);  

 //////////////////////////////////
 // Only Auto Team Change Allow //
 ////////////////////////////////  
 
  // Back2Uo Only Auto Team Change Allow Enable
  game["back2uo_autoteam_changeallow_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_autoteam_change", 0, 0, 1);  
  
 ///////////////////////
 // Cookable Granade //
 /////////////////////

  // Back2Uo Cookable Granade Enable
  game["back2uo_cookgrenade_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_cookable_grenade", 0, 0, 1); 
  
 //////////////////
 // Fall Damage //
 ////////////////
  
  // Back2Uo Auto Download Test Enable
  game["back2uo_falldamage_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_falldamage_aktiv", 0, 0, 1); 
  
	// String
	level.back2uo_falldamage_min = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_falldamage_min", 256, 1, 1000, "int");
	level.back2uo_falldamage_max = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_falldamage_max", 480, 1, 1000, "int");
  
  // Abfrage
	if(game["back2uo_falldamage_enable"])
	{	
	 // String
	 setcvar("bg_fallDamageMinHeight", level.back2uo_falldamage_min);
	 setcvar("bg_fallDamageMaxHeight", level.back2uo_falldamage_max);	 
	}		

 ///////////////////////////////
 // Back2UO Reloaded Credits //
 /////////////////////////////	
 
  // Abfrage
  if(game["back2uo_enable"])
  {	
   // Back2Uo Credits Text
   level.back2uo_creditstext = &"BACK2UOMOD_MOD_CREDITS";
  
   // Precache Credits String
   precacheString(level.back2uo_creditstext);
  }
    
 ////////////////////////////
 // Message Show Next Map //
 //////////////////////////   
  
  // Back2Uo Message Show Next Map Enable
  game["back2uo_mapmsg_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_mapmsg_aktiv", 0, 0, 1); 
  
  // String
  level.back2uo_mapmsg_maptype	= back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_mapmsg_maptype", 2, 1, 2, "int");
  level.back2uo_mapmsg_delay	= back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_mapmsg_delay", 30, 1, 1440, "int");
  level.back2uo_mapmsg_loop	= back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_mapmsg_loop", 1, 0, 1, "int");      
  
 //////////////////
 // Server Text //
 ////////////////   

  // Back2Uo Server Text Enable
  game["back2uo_servertext_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_servertext_aktiv", 0, 0, 1);
  
 ////////////////////
 // Clan Messages //
 ////////////////// 

  // Back2Uo Clan Messages Enable
  game["back2uo_clanm_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_clanm_aktiv", 0, 0, 1); 
 
  // String
  level.back2uo_clanmrepeatwait = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_clanm_repeatwait", 20, 1, 120, "float");
  game["back2uo_clanmsg"] = back2uo\_back2uo_cvars::back2uo_getarray("back2uo_clanm");    

 ////////////////////////
 // Wellcome Messages //
 //////////////////////        

  // Back2Uo Wellcome Messages Enable
  game["back2uo_wellm_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_wellm_aktiv", 0, 0, 1); 
   
  // String
  game["back2uo_wellmsg"] = back2uo\_back2uo_cvars::back2uo_getarray("back2uo_wellm");
  
 ///////////////////////
 // Health Verhalten //
 /////////////////////    
 
  // Back2Uo Health Verhalten Enable
  game["back2uo_health_is_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_health_is", 0, 0, 1);  
  
 //////////////////////////
 // Death | Kill Sounds //
 ////////////////////////   
  
  // Back2Uo Death Sound Enable
  game["back2uo_deathsound_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_deathsound_aktiv", 0, 0, 1);
  
  // Back2Uo Pain Sound Enable
  game["back2uo_painsound_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_painsound_aktiv", 0, 0, 1);
  
  // String
  level.back2uo_painsound_random = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_painsound_random", 30 ,0, 100, "int");
  level.back2uo_deathsound_random = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_deathsound_random", 70 ,0, 100, "int"); 
  
  // Abfrage
  if(game["back2uo_deathsound_enable"] || game["back2uo_painsound_enable"])
  {
   // String
   level.back2uo_voices["german"] = 3;
   level.back2uo_voices["american"] = 7;
   level.back2uo_voices["russian"] = 6;
   level.back2uo_voices["british"] = 6;
  }
  
 ////////////////
 // Medipacks //
 ////////////// 
     
  // Back2Uo Medipacks Enable
  game["back2uo_medipacks_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_drophealth", 0, 0, 1);

  // String
  level.back2uo_medipacks_health = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_medipacks_health", 40, 1, 100, "int");
  level.back2uo_medipacks_hide = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_medipacks_hide", 30, 0, 999, "int");
  
  // Abfrage
  if(game["back2uo_medipacks_enable"])
  {
   // Precache Models
   precacheModel("xmodel/health_medium");				
  }       

 //////////////////////
 // Anti Player AFK //
 //////////////////// 

  // Back2Uo Anti Player AFK Enable
  game["back2uo_antiplay_afk_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_antiplay_afk_aktiv", 0, 0, 1);
 
  // String
  level.back2uo_antiplay_afk_limit = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_antiplay_afk_lmd", 80, 0, 230, "int");

 /////////////////////////
 // Anti Player Camper //
 /////////////////////// 

  // Back2uo Camper Protektor Enable
  game["back2uo_antiplay_cmp_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_antiplay_cmp_aktiv", 0, 0, 1);
  
  // String
	level.back2uo_antiplay_cmp_timer = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_antiplay_cmp_lmd", 60, 0, 120, "int");   
	level.back2uo_antiplay_cmp_objtime = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_antiplay_cmp_go", 40, 0, 120, "int");
	level.back2uo_antiplay_cmp_radius = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_antiplay_cmp_rad", 160, 0, 999, "int");
  
  // Abfrage
  if(game["back2uo_antiplay_cmp_enable"])
  {
	 // Precache
	 precacheShader("gfx/custom/back2uo_camper_german.tga");
	 precacheShader("gfx/custom/back2uo_camper_russian.tga");
	 precacheShader("gfx/custom/back2uo_camper_british.tga");
	 precacheShader("gfx/custom/back2uo_camper_american.tga");
	 precacheShader("objpoint_radio");
  }
  
 ///////////////////////
 // Spawn Protection //
 /////////////////////

	// Back2uo Spawn Protektor Enable
	game["back2uo_antiplay_sp_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_antiplay_sp_aktiv", 0, 0, 1);
	
	// String	 
	level.back2uo_antiplay_sp_time = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_antiplay_sp_lmd", 1, 1, 60, "int");	 
 				 
	// String
	level.back2uo_drawfriend = back2uo\_back2uo_cvars::back2uo_getcvardef("scr_drawfriend", 1, 0, 1, "int");
  
  // Abfrage
  if(game["back2uo_antiplay_sp_enable"])
  {	   
	 // Precache Icon
	 game["headicon_sp_icon"] = "gfx/hud/hud@health_cross.tga";
	 PrecacheHeadIcon(game["headicon_sp_icon"]);
  } 
  
 /////////////
 // War Fx //
 /////////// 
 
  // Back2Uo War Fx Enable
  game["back2uo_warfx_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_warfx_aktiv", 0, 0, 1);
  
  // String  
  level.back2uo_warfx_random = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_warfx_random", 40 ,1, 100, "int");   
      
 //////////////// 
 // Airplanes // 
 //////////////
 
  // Back2uo Airplanes Enable
  game["back2uo_airplanesfx_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_airplanes_aktiv", 0, 0, 1);
  
  // String
	level.back2uo_airplanes_count = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_airplanes_count", 10, 1, 10, "int");
  
  // Abfrage
  if(game["back2uo_airplanesfx_enable"])
  {    
   // Precache
   PrecacheModel("xmodel/vehicle_stuka_flying");
	 PrecacheModel("xmodel/vehicle_spitfire_flying");
	 PrecacheModel("xmodel/vehicle_p51_mustang"); 
	 PrecacheModel("xmodel/vehicle_condor");
	 PrecacheModel("xmodel/prop_stuka_bomb");
	
	 // Load Fx
	 level.back2uo_effect["plane_smoke"] = loadfx("fx/fire/fire_airplane_trail.efx");
	 level.back2uo_effect["plane_explosion"] = loadfx("fx/explosions/matmata_plane_explosion.efx");
  }
   
 //////////////
 // Flak Fx //
 ////////////  
 
  // Back2Uo Flak Fx Enable
  game["back2uo_flakfx_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_flaksfx_aktiv", 0, 0, 1);
  
  // Abfrage
  if(game["back2uo_flakfx_enable"])
  {
   // Flak Effekte Laden
   level.back2uo_effect["flak_smoke"]	= loadfx("fx/explosions/flak_puff.efx");
   level.back2uo_effect["flak_flash"]	= loadfx("fx/explosions/default_explosion.efx");
   level.back2uo_effect["flak_dust"]	= loadfx("fx/dust/flak_dust_blowback.efx");
  }
  
 ////////////////
 // Mortar Fx //
 //////////////   	   

  // Back2Uo Mortar Fx Enable
  game["back2uo_mortarfx_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_mortar_aktiv", 0, 0, 1);
 
  // String  
  level.back2uo_mortar_random = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_mortar_random", 1, 0, 1, "int");
  level.back2uo_mortar_count = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_mortar_count", 20, 1, 100, "int");  
  level.back2uo_mortar_alert = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_mortar_alert", 1, 0, 1, "int");
  level.back2uo_mortar_quake = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_mortar_quake", 1, 0, 1, "int"); 
  level.back2uo_mortar_damage = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_mortar_damage", 1, 0, 1, "int");   
  level.back2uo_mortar_radius = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_mortar_radius", 600, 1, 999, "int");
  level.back2uo_mortar_strength = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_mortar_stre", 300, 1, 999, "int");    	

  // Abfrage
  if(game["back2uo_mortarfx_enable"])
  { 
   // String - Load Mortar Fx
   level.back2uo_effect["mortar_beach"] = loadfx("fx/explosions/mortarExp_beach.efx");
   level.back2uo_effect["mortar_concrete"] = loadfx("fx/explosions/mortarExp_concrete.efx");
   level.back2uo_effect["mortar_dirt"] = loadfx("fx/explosions/mortarExp_dirt.efx");
   level.back2uo_effect["mortar_mud"] = loadfx("fx/explosions/mortarExp_mud.efx");
   level.back2uo_effect["mortar_water"] = loadfx("fx/explosions/mortarExp_water.efx");
   level.back2uo_effect["mortar_snow"] = loadfx("fx/explosions/grenadeExp_snow.efx");
   level.back2uo_effect["mortar_wood"] = loadfx("fx/explosions/grenadeExp_wood.efx");
   level.back2uo_effect["mortar_smoke"] = loadfx("fx/smoke/dark_smoke_trail.efx");

   // Load Mortar Fx	
   PrecacheModel("xmodel/prop_mortar_ammunition");
  }

 ///////////////////
 // Artillery Fx //
 /////////////////

  // Back2Uo Artillery FX Enable
  game["back2uo_artilleryfx_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_artillery_aktiv", 0, 0, 1);

  // String  
  level.back2uo_artillery_random = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_artillery_random", 1, 0, 1, "int");
  level.back2uo_artillery_count = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_artillery_count", 20, 1, 100, "int");  
  level.back2uo_artillery_alert = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_artillery_alert", 1, 0, 1, "int");
  level.back2uo_artillery_danger = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_artillery_danger", 400, 0, 999, "int");

  // Abfrage
  if(game["back2uo_artilleryfx_enable"])
  {	
   // String - Load Artillery Fx
   level.back2uo_effect["artillery_beach"] = loadfx("fx/explosions/artilleryExp_dirt_libya.efx");
   level.back2uo_effect["artillery_concrete"] = loadfx("fx/explosions/artilleryExp_dirt_libya.efx");
   level.back2uo_effect["artillery_dirt"] = loadfx("fx/explosions/artilleryExp_dirt_libya.efx");
   level.back2uo_effect["artillery_mud"] = loadfx("fx/explosions/artilleryExp_dirt_libya.efx");
   level.back2uo_effect["artillery_water"] = loadfx("fx/explosions/mortarExp_water.efx");
   level.back2uo_effect["artillery_snow"] = loadfx("fx/explosions/grenadeExp_snow.efx");
   level.back2uo_effect["artillery_wood"] = loadfx("fx/explosions/grenadeExp_wood.efx");
   level.back2uo_effect["artillery_smoke"] = loadfx("fx/smoke/dark_smoke_trail.efx");

   // Load Artillery Fx	
   PrecacheModel("xmodel/vehicle_halftrack_rockets_shell_d");
   
   // Precache Text
   level.back2uo_artilm = &"BACK2UOMOD_ARTILLERY_USE";
   
   // Precache String
   precacheString(level.back2uo_artilm);
  }  
      
 /////////////////
 // Weather Fx //
 ///////////////  
 
  // Back2Uo Weather Fx Enable
  game["back2uo_weatherfx_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_weatherfx_aktiv", 0, 0, 1);
  
  // String  
  level.back2uo_weatherfx_random = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weatherfx_random", 40 ,1, 100, "int");
  
 /////////////////
 // Coldbreath //
 /////////////// 
 
  // Back2uo Coldbreath Enable
  game["back2uo_coldbreath_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_coldbreath_aktiv",0, 0, 1);
  
  // Abfrage
  if(game["back2uo_coldbreath_enable"] && game["back2uo_weatherfx_enable"])
  {
   // Load breath fx
   level.back2uo_breathfx = loadfx("fx/misc/cold_breath.efx");  
  }  
  
 //////////////
 // Rain Fx //
 ////////////  

  // Back2Uo Rain Fx Enable
  game["back2uo_rainfx_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_rainfx_aktiv", 0, 0, 1);
  
  // String  
  level.back2uo_rainfx_strength = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rain_strength", 10 ,1, 100, "int");  
  
  // Abfrage
  if(game["back2uo_rainfx_enable"] && game["back2uo_weatherfx_enable"])
  {  
   // String - Regen Effekte Laden 
   level.back2uo_effect["rain_1"]	= loadfx ("fx/back2uo/rain_1.efx");
  }  
  
 //////////////
 // Snow Fx //
 ////////////  

  // Back2Uo Snow Fx Enable
  game["back2uo_snowfx_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_snowfx_aktiv", 0, 0, 1);
  
  // Abfrage
  if(game["back2uo_snowfx_enable"] && game["back2uo_weatherfx_enable"])
  {
   // String - Schnee Effekte Laden 
   level.back2uo_effect["snow_1"]	= loadfx ("fx/back2uo/snow_1.efx");
  }          
  
 /////////////////
 // Thunder Fx //
 ///////////////  
 
  // Back2Uo Thunder Fx Enable
  game["back2uo_thunderfx_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_thunderfx_aktiv", 0, 0, 1);
  
  // Abfrage
  if(game["back2uo_thunderfx_enable"] && game["back2uo_weatherfx_enable"])
  { 
   // String - Thunder Effekte Laden	
   level.back2uo_effect["lightning"] = loadfx ("fx/misc/lightning.efx");
  }  
    
 /////////////////
 // Map System //
 ///////////////  
 
  // Back2Uo Map System Enable
  game["back2uo_mapsystem_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_randommaprotation", 0, 0, 1); 

 ////////////////
 // Test Bots //
 //////////////   
 
  // Back2Uo Test Bots Enable
  game["back2uo_testbots_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_testbots_aktiv", 0, 0, 1);  
    
 ////////////////////
 // Waffen System //
 //////////////////    

  // Back2Uo Waffen System Enable
  game["back2uo_weaponsystem_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_weaponsetup_aktiv", 0, 0, 1);
  
  // String
  level.back2uo_weapon_limit = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weapons_allow", 0, 0, 3, "float");
  level.back2uo_pistel_allow	= back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_pistel_allow", 1, 0, 1, "float");
  level.back2uo_turret_allow = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_turret_allow", 1, 0, 1, "float");
  level.back2uo_binocular_allow = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_binocular_allow", 1, 0, 1, "float");
   
  // String
  level.back2uo_rocketl_allow = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_rocketlancher_on", 0, 0, 1, "float");
  level.back2uo_g43sniper_allow = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_g43sniper_on", 0, 0, 1, "float");
    
  // String  
  level.back2uo_smoke_grana_aktiv = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_smoke_grana_aktiv", 0, 0, 1, "int");  
  level.back2uo_granaten_allow = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_frag_allow", 3 ,1, 10, "int");     
  level.back2uo_granaten_use = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_frag_use", 2, 1, 10, "int");
  level.back2uo_smoke_allow = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_smoke_allow", 3, 1, 10, "int");      
  level.back2uo_smoke_use = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_smoke_use", 1, 1, 10, "int");    
}

////////////////////////////
// Back2Uo Cod2 Settings //
//////////////////////////
back2uo_cod2_settings()
{
 // Back2Uo Deathicons Enable
 game["back2uo_deathicon_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_deathicon", 1, 0, 1);	   
 
 // Back2Uo Friendicons Enable
 game["back2uo_friendicon_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_friendicon", 1, 0, 1);	
  
 // Back2Uo Granaten Indecator Enable
 game["back2uo_granatenindecator_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_granatenindecator", 1, 0, 1);	  

 // Back2Uo Minifadenkreuz Enable
 game["back2uo_minicrosshair_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_minicrosshair", 1, 0, 1);	  
 
 // Back2Uo Objekt Indekator Enable
 game["back2uo_objindekator_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_objindekator", 1, 0, 1);  
 
 // Back2Uo Objekt Indekator CTF Enable
 game["back2uo_objindekator_ctf_enable"] = back2uo\_back2uo_cvars::back2uo_setconfig("back2uo_objindekator_ctf", 1, 0, 1); 
 
 // Back2Uo Killcam Enable
 game["back2uo_killcam"] = back2uo\_back2uo_cvars::back2uo_setconfig("scr_killcam", 0, 0, 1);     
}	

//////////////////////////
// Back2Uo Server Info //
////////////////////////
back2uo_serverinfo()
{
 // String - Effects
 back2uo\_back2uo_cvars::back2uo_setui_var("ui_back2uo_airplaneeffect", game["back2uo_airplanesfx_enable"]);
 back2uo\_back2uo_cvars::back2uo_setui_var("ui_back2uo_mortareffect", game["back2uo_mortarfx_enable"]);
 back2uo\_back2uo_cvars::back2uo_setui_var("ui_back2uo_artilleryeffect", game["back2uo_artilleryfx_enable"]);
 back2uo\_back2uo_cvars::back2uo_setui_var("ui_back2uo_weathereffect", game["back2uo_weatherfx_enable"]);

 // String - Systems
 back2uo\_back2uo_cvars::back2uo_setui_var("ui_back2uo_antiafksystem", game["back2uo_antiplay_afk_enable"]);
 back2uo\_back2uo_cvars::back2uo_setui_var("ui_back2uo_anticampersystem", game["back2uo_antiplay_cmp_enable"]);
 back2uo\_back2uo_cvars::back2uo_setui_var("ui_back2uo_savespawnsystem", game["back2uo_antiplay_sp_enable"]);
 
 // String - Cod 2 / Extra
 back2uo\_back2uo_cvars::back2uo_setui_var("ui_hudbombpoints", game["back2uo_drawmantlehint"]);  
 back2uo\_back2uo_cvars::back2uo_setui_var("ui_skullicons", game["back2uo_deathicon_enable"]);  
 back2uo\_back2uo_cvars::back2uo_setui_var("ui_friendicons", game["back2uo_friendicon_enable"]); 
 back2uo\_back2uo_cvars::back2uo_setui_var("ui_grenadesinde", game["back2uo_granatenindecator_enable"]);   
 back2uo\_back2uo_cvars::back2uo_setui_var("ui_allow_onlyautoteam", game["back2uo_autoteam_changeallow_enable"]); 
 
 // String - Call Vote
 back2uo\_back2uo_cvars::back2uo_setui_var("ui_allowvotekick", game["back2uo_playerkickvote_enable"]);
 back2uo\_back2uo_cvars::back2uo_setui_var("ui_allowvotetypemap", game["back2uo_vote_gametype_enable"]);
 back2uo\_back2uo_cvars::back2uo_setui_var("ui_allowvotemap", game["back2uo_vote_map_enable"]);
 back2uo\_back2uo_cvars::back2uo_setui_var("ui_allowvotemaprotate", game["back2uo_vote_nextmap_enable"]);
 back2uo\_back2uo_cvars::back2uo_setui_var("ui_allowvotemaprestart", game["back2uo_vote_map_restart_enable"]);
}

///////////////////////////////
// Back2Uo Player Spectator //
/////////////////////////////
back2uo_playermsg_spectator(back2uo_playername)
{
 // Abfrage
 if(!game["back2uo_statusmsg_enable"]) return;

 // Abfrage
 if(isdefined(self)) back2uo\_back2uo_cvars::back2uo_player_message(&"BACK2UOMOD_PLAYER_SPECTATOR", self);
}

//////////////////////////////
// Back2Uo Spawn Attacking //
////////////////////////////
back2uo_spawn_attacking()
{
 // String
 self endon("disconnect");
 
 // Abfrage
 if(isDefined(self.back2uo_spawn_att)) return;
	self.back2uo_spawn_att = true;
	
 // Abfrage
 if(isPlayer(self))
 {
	self iprintlnbold(&"BACK2UOMOD_SPAWN_PLAYER_ATTACKE");
 }	
}

///////////////////////////
// Back2Uo Credits Draw //
/////////////////////////
back2uo_credits_draw()
{
 // Abfrage
 if(!game["back2uo_enable"]) return;
 
 // Abfrage
 if(!isdefined(self.back2uo_credits))
 { 
  // String
	self.back2uo_credits = newHudElem();	
	self.back2uo_credits.x = 7;
	self.back2uo_credits.y = 472;
	self.back2uo_credits.alignX = "left";
 	self.back2uo_credits.alignY = "middle";
	self.back2uo_credits.alpha = 0.8;
	self.back2uo_credits.fontScale = 0.7; 
	self.back2uo_credits setText(&"BACK2UOMOD_MOD_CREDITS");
 } 
}

////////////////////////////////////////
// Back2Uo Wellcome Messages Control //
//////////////////////////////////////
back2uo_wellc_messages_draw()
{
 // Abfrage
 if(!game["back2uo_wellm_enable"]) return;

 // String
 self endon("disconnect");
 self notify("spawned");
 
 // Abfrage
 if(isdefined(self.pers["wellcome_msg"])) return;
  self.pers["wellcome_msg"] = true;
  
 // String
 msg_count_welc = 0;   
 
 // While Schleife 
 while(isdefined(game["back2uo_wellmsg"]) && msg_count_welc < game["back2uo_wellmsg"].size) 
 {
  // String
	welmsg = game["back2uo_wellmsg"][msg_count_welc];

  // Abfrage
  if(isdefined(welmsg))
  {
   // String
   self iprintlnbold(welmsg);
   
   // Warteschleife
	 wait 3;
	}

	// String
	msg_count_welc++;    
  
  // Abfrage           
	if(msg_count_welc == game["back2uo_wellmsg"].size) break;
	
	// Warteschleife
	wait 0.05;
 }      
}

/////////////////////////////////
// Back2Uo Clan Messages Draw //
///////////////////////////////
back2uo_clan_messages_draw()
{
 // Abfrage
 if(!game["back2uo_clanm_enable"]) return;

 // String
 self endon("disconnect");
 self notify("spawned");
 
 // String
 level endon("back2uo_killthreads");
 
 // For Schleife
 for(;;)
 { 
  // Abfrage
  if(isdefined(game["clanout"])) wait level.back2uo_clanmrepeatwait;
   game["clanout"] = true; 
 
  // String
  msg_count_clan = 0;   
 
  // While Schleife 
  while(isdefined(game["back2uo_clanmsg"]) && msg_count_clan < game["back2uo_clanmsg"].size) 
  {
   // String
	 clanmsg = game["back2uo_clanmsg"][msg_count_clan];

   // Abfrage
   if(isdefined(clanmsg))
   {
    // Weiterleitung
    back2uo\_back2uo_cvars::back2uo_player_message("",clanmsg);
   
    // Warteschleife
	  wait 3;
	 }

	 // String
	 msg_count_clan++;    
  
   // Abfrage           
	 if(msg_count_clan == game["back2uo_clanmsg"].size) break;
	
	 // Warteschleife
	 wait 0.05;
	}
 } 
}

////////////////////////////////////////////
// Back2uo Show Next Map Messages - Draw //
//////////////////////////////////////////
back2uo_nextmap_messages_draw(x)
{
 // Abfrage
 if(!game["back2uo_mapmsg_enable"]) return;
 
 // Abfrage
 if(!isdefined(x)) return;
 
 // String
 self endon("disconnect");
 level endon("kill_endround");
 self notify("spawned"); 
 
 // String
 maps = undefined;
 
 // Abfrage
 if(isdefined(x.maps)) maps = x.maps;
 
 // String
 level endon("back2uo_killthreads");
 
 // For Schleife
 for(;;)
 {
  // Abfrage
  if(isdefined(game["mapmsg_loop"])) return;
  if(level.back2uo_mapmsg_loop != 1) game["mapmsg_loop"] = true;
   
  // Warteschleife "Config" Sekunden
  wait level.back2uo_mapmsg_delay;
  
  // Abfrage
  if(isdefined(maps))
  {
   // String
   level.back2uo_nextmap = maps[0]["map"];
   
   // Abfrage
   if(isdefined(maps[0]["gametype"]))
   {
    level.back2uo_nextgt = maps[0]["gametype"];
   }
   else
   {
    level.back2uo_nextgt = getcvar("g_gametype");
   }
  } 
  	
  // Abfrage
	if(level.back2uo_mapmsg_maptype == 1)
	{
   // Abfrage
	 if(isdefined(level.back2uo_nextmap))
	 {
	  // String
	  lstr = &"BACK2UOMOD_NEXT_MAP";
    wert = back2uo\_back2uo_tools::back2uo_get_mapname(level.back2uo_nextmap); 
   
    // Weiterleitung
    back2uo\_back2uo_cvars::back2uo_player_message(lstr,wert); 
   }
	}
	
	// Abfrage
	if(level.back2uo_mapmsg_maptype == 2)
	{
	 // Abfrage
	 if(isdefined(level.back2uo_nextmap))
	 {
	  // String
	  lstr = &"BACK2UOMOD_NEXT_MAP";
    wert = back2uo\_back2uo_tools::back2uo_get_mapname(level.back2uo_nextmap); 
   
    // Weiterleitung
    back2uo\_back2uo_cvars::back2uo_player_message(lstr,wert); 
   }
    
	 // Abfrage
	 if(isdefined(level.back2uo_nextgt))
	 {
	  // String
	  lstr = &"BACK2UOMOD_NEXT_GT";
    wert = back2uo\_back2uo_tools::back2uo_get_gametypename(level.back2uo_nextgt); 
   
    // Weiterleitung
    back2uo\_back2uo_cvars::back2uo_player_message(lstr,wert); 
   }    
  }
  
  // Warteschleife
  wait 0.1;    
 }
}

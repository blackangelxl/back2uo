////////////////////////////////
// Back2Uo Player Score Draw //
//////////////////////////////
back2uo_playerscore_draw()
{
 // Abfrage
 if(!game["back2uo_playerscore_enable"] || getcvar("g_gametype") != "dm") return;

 // Switch
 switch(game["allies"])
 {
	case "american":
	 game["hudicon_allies"] = "gfx/custom/back2uo_flag_ammis.tga";
	break;
	
	case "british":
	 game["hudicon_allies"] = "gfx/custom/back2uo_flag_british.tga";
	break;
	
	case "russian":
	 game["hudicon_allies"] = "gfx/custom/back2uo_flag_russian.tga";
	break;
 }
	
 // String	
 assert(game["axis"] == "german");
 game["hudicon_axis"] = "gfx/custom/back2uo_flag_german.tga";
 
 // Hud Kill Icons	
 if(!isDefined(self.hud_lifeicon))
 {	
  self.hud_lifeicon = newClientHudElem(self);
  self.hud_lifeicon.horzAlign = "left";
  self.hud_lifeicon.vertAlign = "top";
  self.hud_lifeicon.x = 6;
  self.hud_lifeicon.y = 28;
  self.hud_lifeicon.archived = true;
  self.hud_lifeicon.alpha = level.back2uo_hudscore_alpha;
  self.hud_lifeicon setShader("gfx/custom/back2uo_liveicon.tga", 26, 24);
 }  
  
 // Player Icon
 if(!isdefined(self.hud_playericon))
 {
  self.hud_playericon = newClientHudElem(self);
  self.hud_playericon.horzAlign = "left";
	self.hud_playericon.vertAlign = "top";
	self.hud_playericon.x = 6;
	self.hud_playericon.y = 54;
	self.hud_playericon.alpha = level.back2uo_hudscore_alpha;
	self.hud_playericon.archived = true;
 }

 // Player Score
 if(!isdefined(self.hud_playerscore))
 {
	self.hud_playerscore = newClientHudElem(self);
	self.hud_playerscore.horzAlign = "left";
	self.hud_playerscore.vertAlign = "top";
	self.hud_playerscore.x = 36;
	self.hud_playerscore.y = 26;
	self.hud_playerscore.alpha = level.back2uo_hudscore_alpha;
	self.hud_playerscore.font = "default";
	self.hud_playerscore.fontscale = 2;
	self.hud_playerscore.archived = true;
 }	 
   
 // String
 assert(self.pers["team"] == "allies" || self.pers["team"] == "axis");
		
 // Abfrage  
 if(self.pers["team"] == "allies")
  self.hud_playericon setShader(game["hudicon_allies"], 48, 24);
 else
  self.hud_playericon setShader(game["hudicon_axis"], 48, 24); 
}

//////////////////////////////////
// Back2Uo Player Score Update //
////////////////////////////////
back2uo_playerscore_update()
{
 // Abfrage
 if(!game["back2uo_playerscore_enable"] || getcvar("g_gametype") != "dm") return;

 // For Schleife
 for(;;)
 {
  // Abfrage
  if(isDefined(self.hud_playerscore))
	 self.hud_playerscore setValue(self.score);

  // Warteschleife
  wait 0.1;
 }
}

/////////////////////////////////
// Back2Uo Player Score Clear //
///////////////////////////////
back2uo_playerscore_clear()
{
 // Abfrage
 if(!game["back2uo_playerscore_enable"] || getcvar("g_gametype") != "dm") return;

 // Hud Kill Icon Clear
 if(isDefined(self.hud_lifeicon))
  self.hud_lifeicon destroy();

 // Playerscore Icon Clear
 if(isDefined(self.hud_playericon))
	self.hud_playericon destroy();

 // Playerscore Score Clear
 if(isDefined(self.hud_playerscore))
	self.hud_playerscore destroy();
}

//////////////////////////////
// Back2Uo Team Score Draw //
////////////////////////////
back2uo_teamscore_draw()
{
 // Abfrage
 if(!game["back2uo_teamscore_enable"] || getcvar("g_gametype") == "dm") return;

 // Switch Funktion
 switch(game["allies"])
 {
	case "american":
	 game["hudicon_allies"] = "gfx/custom/back2uo_flag_ammis.tga";
  break;
	
	case "british":
	 game["hudicon_allies"] = "gfx/custom/back2uo_flag_british.tga";
	break;

	case "russian":
	 game["hudicon_allies"] = "gfx/custom/back2uo_flag_russian.tga";
	break;
 }
	
 // String	
 assert(game["axis"] == "german");
 game["hudicon_axis"] = "gfx/custom/back2uo_flag_german.tga"; 
 
 // Team Icon
 if(!isdefined(self.hud_teamicon)) 
 {
	self.hud_teamicon = newClientHudElem(self);
	self.hud_teamicon.horzAlign = "left";
	self.hud_teamicon.vertAlign = "top";
	self.hud_teamicon.x = 12;
	self.hud_teamicon.y = 42;
	self.hud_teamicon.alpha = level.back2uo_hudscore_alpha; 
	self.hud_teamicon.archived = true;
	self.hud_teamicon setShader(game["hudicon_allies"], 48, 24);
 }

 // Team Score
 if(!isdefined(self.hud_teamscore)) 
 {
	self.hud_teamscore = newClientHudElem(self);
	self.hud_teamscore.horzAlign = "left";
	self.hud_teamscore.vertAlign = "top";
	self.hud_teamscore.x = 65;
	self.hud_teamscore.y = 40;
	self.hud_teamscore.font = "default";
	self.hud_teamscore.fontscale = 2;
	self.hud_teamscore.alpha = level.back2uo_hudscore_alpha; 
	self.hud_teamscore.archived = true;
 }		
  
 // Enemy Icon
 if(!isdefined(self.hud_enemyicon)) 
 {
	self.hud_enemyicon = newClientHudElem(self);
	self.hud_enemyicon.horzAlign = "left";
	self.hud_enemyicon.vertAlign = "top";
	self.hud_enemyicon.x = 12;
	self.hud_enemyicon.y = 75;
	self.hud_enemyicon.alpha = level.back2uo_hudscore_alpha; 
	self.hud_enemyicon.archived = true;
	self.hud_enemyicon setShader(game["hudicon_axis"], 48, 24);
 }

 // Enemy Icon Score
 if(!isdefined(self.hud_enemyscore)) 
 {
	self.hud_enemyscore = newClientHudElem(self);
	self.hud_enemyscore.horzAlign = "left";
	self.hud_enemyscore.vertAlign = "top";
	self.hud_enemyscore.x = 65;
	self.hud_enemyscore.y = 73;
	self.hud_enemyscore.font = "default";
	self.hud_enemyscore.fontscale = 2;
	self.hud_enemyscore.alpha = level.back2uo_hudscore_alpha; 
	self.hud_enemyscore.archived = true;
 }

 // Hud Icons	
 if(!isDefined(self.hud_lifeicon))
 {	
  self.hud_lifeicon = newClientHudElem(self);
  self.hud_lifeicon.horzAlign = "left";
  self.hud_lifeicon.vertAlign = "top";
  self.hud_lifeicon.x = 10;
  self.hud_lifeicon.y = 21;
  self.hud_lifeicon.archived = true;
  self.hud_lifeicon.alpha = level.back2uo_hudscore_alpha;
  self.hud_lifeicon setShader("gfx/custom/back2uo_liveicon.tga", 26, 24);
 }

 if(!isDefined(self.hud_deathicon))
 {	 
  self.hud_deathicon = newClientHudElem(self);
  self.hud_deathicon.horzAlign = "left";
  self.hud_deathicon.vertAlign = "top";
  self.hud_deathicon.x = 35;
  self.hud_deathicon.y = 21;
  self.hud_deathicon.archived = true;
  self.hud_deathicon.alpha = level.back2uo_hudscore_alpha;
  self.hud_deathicon setShader("gfx/custom/back2uo_deadicon.tga", 26, 24);
 }

 if(!isDefined(self.hud_teamcuticon))
 {	
  self.hud_teamcuticon = newClientHudElem(self);
  self.hud_teamcuticon.horzAlign = "left";
  self.hud_teamcuticon.vertAlign = "top";
  self.hud_teamcuticon.x = 34;
  self.hud_teamcuticon.y = 62;
  self.hud_teamcuticon.font = "default";
  self.hud_teamcuticon.fontscale = 1;
  self.hud_teamcuticon.archived = true;
  self.hud_teamcuticon.alpha = level.back2uo_hudscore_alpha;
  self.hud_teamcuticon setText(level.cuticon);
 }

 if(!isDefined(self.hud_enemycuticon))
 {		
  self.hud_enemycuticon = newClientHudElem(self);
  self.hud_enemycuticon.horzAlign = "left";
  self.hud_enemycuticon.vertAlign = "top";
  self.hud_enemycuticon.x = 34;
  self.hud_enemycuticon.y = 95;
  self.hud_enemycuticon.font = "default";
  self.hud_enemycuticon.fontscale = 1;
  self.hud_enemycuticon.archived = true;
  self.hud_enemycuticon.alpha = level.back2uo_hudscore_alpha;
  self.hud_enemycuticon setText(level.cuticon);	 
 }
 
 // Allierte Team Life
 if(!isDefined(self.hud_teamlife))
 {
  self.hud_teamlife = newClientHudElem(self);
  self.hud_teamlife.horzAlign = "left";
  self.hud_teamlife.vertAlign = "top";
  self.hud_teamlife.x = 19;
  self.hud_teamlife.y = 62;
  self.hud_teamlife.font = "default";
  self.hud_teamlife.fontscale = 1;
  self.hud_teamlife.archived = true;
  self.hud_teamlife.alpha = level.back2uo_hudscore_alpha;
  self.hud_teamlife setValue(0);
 }
 
 // Allierte Team Death	
 if(!isDefined(self.hud_teamdeath))
 {	
  self.hud_teamdeath = newClientHudElem(self);
  self.hud_teamdeath.horzAlign = "left";
  self.hud_teamdeath.vertAlign = "top";
  self.hud_teamdeath.x = 45;
  self.hud_teamdeath.y = 62;
  self.hud_teamdeath.font = "default";
  self.hud_teamdeath.fontscale = 1;
  self.hud_teamdeath.archived = true;
  self.hud_teamdeath.alpha = level.back2uo_hudscore_alpha;
  self.hud_teamdeath setValue(0);	
 }
  
 // Axenm�chte Team Life
 if(!isDefined(self.hud_enemylife))
 {
  self.hud_enemylife = newClientHudElem(self);
  self.hud_enemylife.horzAlign = "left";
  self.hud_enemylife.vertAlign = "top";
  self.hud_enemylife.x = 19;
  self.hud_enemylife.y = 95;
  self.hud_enemylife.font = "default";
  self.hud_enemylife.fontscale = 1;
  self.hud_enemylife.archived = true;
  self.hud_enemylife.alpha = level.back2uo_hudscore_alpha;
  self.hud_enemylife setValue(0);
 }

 // Axenm�chte Team Death
 if(!isDefined(self.hud_enemydeath))
 {
  self.hud_enemydeath = newClientHudElem(self);
  self.hud_enemydeath.horzAlign = "left";
  self.hud_enemydeath.vertAlign = "top";
  self.hud_enemydeath.x = 45;
  self.hud_enemydeath.y = 95;
  self.hud_enemydeath.font = "default";
  self.hud_enemydeath.fontscale = 1;
  self.hud_enemydeath.archived = true;
  self.hud_enemydeath.alpha = level.back2uo_hudscore_alpha;
  self.hud_enemydeath setValue(0); 
 }
}	

////////////////////////////////
// Back2Uo Team Score Update //
//////////////////////////////
back2uo_teamscore_update()
{
 // Abfrage
 if(!game["back2uo_teamscore_enable"] || getcvar("g_gametype") == "dm") return;

 // Kill Threads
 level endon("back2uo_killthreads");

 // For Schleife	
 for(;;)
 {
  // Warteschleife 1 Sekunde
  wait 1;
  
  // Hudscore ( 0  = Aus | 1 = Ein // Standart = 1 )
  if(game["back2uo_teamscore_enable"] && getcvar("g_gametype") != "dm")
  {
   // Spieler String
	 level.players = getentarray("player", "classname"); 
   alliedlife = [];
   allieddeath = [];
	 axislife = [];	
	 axisdeath = [];

   // Strings
   alliedscore = getTeamScore("allies");
   axisscore = getTeamScore("axis");

	 // For Schleife
	 for(i = 0; i < level.players.size; i++)
	 {
	  // String
	  player = level.players[i];
	  
	  // Abfrage
	  if(isdefined(player.hud_teamscore) && isdefined(player.hud_enemyscore))
	  {
     player.hud_teamscore setValue(alliedscore);
	   player.hud_enemyscore setValue(axisscore);
    }
	 
	  // Abfrage
	  if(player.pers["team"] == "allies")
	  {
	   if(player.sessionstate == "playing")
	   {
	    alliedlife[alliedlife.size] = player;
	   }
	   else if(player.sessionstate != "playing")
	   {
      allieddeath[allieddeath.size] = player;
     }
    }
    else if(player.pers["team"] == "axis") 
	  {
 	   if(player.sessionstate == "playing")
	   {
	    axislife[axislife.size] = player;
	   }
	   else if(player.sessionstate != "playing")
	   {
	    axisdeath[axisdeath.size] = player; 
     }   
    }
    
    // Abfrage
    if(isdefined(self.hud_teamlife) && isdefined(self.hud_enemylife))
	  {
     // Allierte
	   self.hud_teamlife setValue(alliedlife.size);
	   self.hud_teamdeath setValue(allieddeath.size);
	 
	   // Axenm�chte
	   self.hud_enemylife setValue(axislife.size);
	   self.hud_enemydeath setValue(axisdeath.size);    	   
    }    
   }       
  }
 }
}

///////////////////////////////
// Back2Uo Team Score Clear //
/////////////////////////////
back2uo_teamscore_clear()
{
 // Abfrage
 if(!game["back2uo_teamscore_enable"] || getcvar("g_gametype") == "dm") return;

 // Hud Icons     
 if(isDefined(self.hud_lifeicon))
  self.hud_lifeicon destroy();  
 if(isDefined(self.hud_deathicon))
  self.hud_deathicon destroy();  
 if(isDefined(self.hud_teamcuticon))
  self.hud_teamcuticon destroy();  
 if(isDefined(self.hud_enemycuticon))
  self.hud_enemycuticon destroy();
  
 // Allierte
 if(isDefined(self.hud_teamicon))
  self.hud_teamicon destroy();
 if(isDefined(self.hud_teamscore))
  self.hud_teamscore destroy();
  
 if(isDefined(self.hud_teamlife))
  self.hud_teamlife destroy();    
 if(isDefined(self.hud_teamdeath))
  self.hud_teamdeath destroy();   
		
 // Axenm�chte		
 if(isDefined(self.hud_enemyicon))
  self.hud_enemyicon destroy();	
 if(isDefined(self.hud_enemyscore))
  self.hud_enemyscore destroy();	  
  		
 if(isDefined(self.hud_enemylife))
  self.hud_enemylife destroy();  
 if(isDefined(self.hud_enemydeath))
  self.hud_enemydeath destroy();  
}

/////////////////////////////
// Back2Uo Healthbar Draw //
///////////////////////////
back2uo_healthbar_draw()
{
 // Abfrage
 if(!game["back2uo_healthbar_enable"]) return;
    
 // String
 balkenWidth = 128;
 
 // String - Hud Anzeige( x | y )
 healthbar_x = 501;
 healthbar_y = 461;

 // Healthbar Hintergrund
 if(!isDefined(self.healthbar_bg)) 
 {
  self.healthbar_bg = newClientHudElem(self);                                    
  self.healthbar_bg.x = healthbar_x;                                          
  self.healthbar_bg.y = healthbar_y + 1;                                       
  self.healthbar_bg.horzAlign = "left";                                          
  self.healthbar_bg.vertAlign = "top";                                          
  self.healthbar_bg.alpha = 1;                                                  
  self.healthbar_bg.sort = 1;                                                  
  self.healthbar_bg.archived = true;                                             
  self.healthbar_bg setShader("gfx/hud/hud@health_back.tga", 130, 10);           
 }
 		
 // Healthbar Blank
 if(!isDefined(self.healthbar_gruen))
 {
  self.healthbar_gruen = newClientHudElem(self);                           
  self.healthbar_gruen.x = healthbar_x + 1;                                     
  self.healthbar_gruen.y = healthbar_y + 2;                                     
  self.healthbar_gruen.horzAlign = "left";                                       
  self.healthbar_gruen.vertAlign = "top";                                        
  self.healthbar_gruen.color = (1.0-(self.health/100.0), (self.health/100.0)-0.4, 0);
  self.healthbar_gruen.alpha = 0.4;                                             
  self.healthbar_gruen.sort = 4;                                                 
  self.healthbar_gruen.archived = true;                                          
  self.healthbar_gruen setShader("gfx/hud/hud@health_bar.tga", balkenWidth, 8); 
 }

 // Healthbar Cross
 if(!isDefined(self.healthbar_kreuz))
 {
  self.healthbar_kreuz = newClientHudElem(self);                   
  self.healthbar_kreuz.x = healthbar_x - 13;                                   
  self.healthbar_kreuz.y = healthbar_y;                                          
  self.healthbar_kreuz.horzAlign = "left";                                       
  self.healthbar_kreuz.vertAlign = "top";                                  
  self.healthbar_kreuz.alpha = 1;                                                
  self.healthbar_kreuz.sort = 1;                                                 
  self.healthbar_kreuz.archived = true;                                          
  self.healthbar_kreuz setShader("gfx/hud/hud@health_cross.tga", 12, 12);        	
 }
}

///////////////////////////////
// Back2Uo Healthbar Update //
/////////////////////////////
back2uo_healthbar_spawn_prot(time, wert)
{
 // Abfrage - Healthbar Update	
 if(isdefined(self.healthbar_kreuz)) 	   
 {
  // String  
  self.healthbar_kreuz setShader("gfx/hud/hud@health_cross.tga", 12, 12); 	
  self.healthbar_kreuz.color = (0, 2, 2);        						

  // String
  self.healthbar_kreuz.alpha = 1;
	self.healthbar_kreuz fadeOverTime(1); 
	self.healthbar_kreuz.alpha = 0;
 }
 
 if(isdefined(self.healthbar_kreuz) && isdefined(wert))
 {
  // String
  self.healthbar_kreuz.alpha = 1;
  self.healthbar_kreuz setShader("gfx/hud/hud@health_cross.tga", 12, 12);
  self.healthbar_kreuz.color = (1, 1, 1);    
 }
}

///////////////////////////////
// Back2Uo Healthbar Update //
/////////////////////////////
back2uo_healthbar_update()
{
 // Abfrage
 if(!game["back2uo_healthbar_enable"]) return;
 
 // Disconnect
 self endon("disconnect"); 
 
 // Kill Threads
 level endon("back2uo_killthreads");
 
 // For Schleife
 for(;;)
 { 
  //String
  balkenWidth = 128;
   
  // String
  health_status1 = self.health;
  wait .05;
  health_status2 = self.health;
 		
  // Abfrage
  if(health_status2 != health_status1)
  {
   // String
	 balkenWidth = Int(health_status2 * 1.28);
   	 
   // Abfrage -  Healthbar Blank Clear	 
	 if (balkenWidth == 0 || balkenWidth < 0) 
   {
    if(isdefined(self.healthbar_gruen)) self.healthbar_gruen destroy();   
   }
       		
   // Abfrage - Healthbar Update	
   if(isdefined(self.healthbar_gruen)) 	   
   { 
    self.healthbar_gruen.alpha = 0.4;  
		self.healthbar_gruen setShader("gfx/hud/hud@health_bar.tga", balkenWidth, 8); 	
    self.healthbar_gruen.color = (1.0-(self.health/100.0), (self.health/100.0)-0.4, 0);        						
	 }		
  }
 }		
}

//////////////////////////////
// Back2Uo Healthbar Clear //
////////////////////////////
back2uo_healthbar_clear()
{
 // Abfrage
 if(!game["back2uo_healthbar_enable"]) return;

 // Abfrage
 if(isDefined(self.healthbar_bg)) 
  self.healthbar_bg destroy();
  
 // Abfrage
 if(isDefined(self.healthbar_gruen))
  self.healthbar_gruen destroy(); 
 
 // Abfrage   
 if(isDefined(self.healthbar_kreuz))
  self.healthbar_kreuz destroy();    
}

/////////////////////////////////////
// Back2Uo Player Position - Draw //
///////////////////////////////////
back2uo_playerposition_draw()
{
 // Abfrage
 if(!game["back2uo_playerposition_enable"]) return;
   
 // Player Position Hintergrund
 if(!isDefined(self.playerposition_bg)) 
 {
  self.playerposition_bg = newClientHudElem(self);                               // Neues Client Hud-Anzeige Element
  self.playerposition_bg.x = 103;                                                 // X - Axe ( <- | -> )
  self.playerposition_bg.y = 419;                                                // Y - Axe ( A | V )
  self.playerposition_bg.horzAlign = "left";                                     // Horizantale Anordnung ( left, center, right )
  self.playerposition_bg.vertAlign = "top";                                      // Vertikale Anordnung ( top, center, bottom ) 
  self.playerposition_bg.alpha = 0.6;                                            // Alpha ( 1 = An | 0 = Aus )
  self.playerposition_bg.sort = 1;                                               // Anordnung Ebene 
  self.playerposition_bg.archived = true;                                        // Archivierung ( true = An | false = Aus )
  self.playerposition_bg setShader("gfx/custom/stance_bg.tga", 49, 47);          // Shader ( "Name", L�nge, H�he )
 }          
}

//////////////////////////////////////
// Back2Uo Player Position - Clear //
////////////////////////////////////
back2uo_playerposition_clear()
{
 // Abfrage
 if(!game["back2uo_playerposition_enable"]) return;

 // Abfrage
 if(isDefined(self.playerposition_bg)) 
 self.playerposition_bg destroy();
}

///////////////////////////
// Back2Uo Compass Draw //
/////////////////////////
back2uo_compass_draw()
{
 // Abfrage
 if(!game["back2uo_enable"]) return;

 // String
 compass_size = 39;

 // Compass Zeiger
 if(!isdefined(self.compass_zeiger))
 {
  self.compass_zeiger = newClientHudElem(self);                                    
  self.compass_zeiger.x = 35;                                                      
  self.compass_zeiger.y = 388;                                                     
  self.compass_zeiger.horzAlign = "left";                                          
  self.compass_zeiger.vertAlign = "top";                                            
  self.compass_zeiger.alpha = 1;                                                   
  self.compass_zeiger.sort = 1;                                                    
  self.compass_zeiger.archived = true;                                             
  self.compass_zeiger setShader("gfx/custom/back2uo_compasszeiger.tga", compass_size, compass_size);   
 }
}

////////////////////////////
// Back2Uo Compass Clear //
//////////////////////////
back2uo_compass_clear()
{
 // Abfrage
 if(!game["back2uo_enable"]) return;

 // Abfrage
 if(isDefined(self.compass_zeiger)) 
 // Healthbar Hintergrund Destroy
 self.compass_zeiger destroy(); 
}

////////////////////////////
// Back2Uo View Blood FX //
//////////////////////////
back2uo_view_bloodfx()
{ 
 // Abfrage
 if(!game["back2uo_bloodsplater_enable"]) return;

 // Weiterleitung Clear Blood FX
 back2uo_clear_bloodfx();
 
 // Abfrage
 if(!isDefined(self.back2uo_bloodyscreen))
 {
  // String
	bs1 = randomint(496);
	bs2 = randomint(336); 
	bs3 = randomint(48);
	self.back2uo_bloodyscreen = newClientHudElem(self);
	self.back2uo_bloodyscreen.alignX = "left";
	self.back2uo_bloodyscreen.alignY = "top";	
	self.back2uo_bloodyscreen.x = bs1;
	self.back2uo_bloodyscreen.y = bs2;
	self.back2uo_bloodyscreen.color = (1,1,1);	
	self.back2uo_bloodyscreen.alpha = 1;
	self.back2uo_bloodyscreen.archived = true;
	self.back2uo_bloodyscreen SetShader("gfx/impact/flesh_hit2",96 + bs3 , 96 + bs3);
 }
 
 // Abfrage
 if(!isDefined(self.back2uo_bloodyscreen1))
 { 
  // String
	bs1a = randomint(496);
	bs2a = randomint(336);	
	bs3a = randomint(48);
	self.back2uo_bloodyscreen1 = newClientHudElem(self);
	self.back2uo_bloodyscreen1.alignX = "left";
	self.back2uo_bloodyscreen1.alignY = "top";	
	self.back2uo_bloodyscreen1.x = bs1a;
	self.back2uo_bloodyscreen1.y = bs2a;
  self.back2uo_bloodyscreen1.color = (1,1,1);	
  self.back2uo_bloodyscreen1.alpha = 1;
  self.back2uo_bloodyscreen1.archived = true;
  self.back2uo_bloodyscreen1 SetShader("gfx/impact/flesh_hitgib",96 + bs3a , 96 + bs3a);
 }
 
 // Abfrage
 if(!isDefined(self.back2uo_bloodyscreen2))
 { 
  // String	
	bs1b = randomint(496);
	bs2b = randomint(336);	
	bs3b = randomint(48);
	self.back2uo_bloodyscreen2 = newClientHudElem(self);
	self.back2uo_bloodyscreen2.alignX = "left";
	self.back2uo_bloodyscreen2.alignY = "top";	
	self.back2uo_bloodyscreen2.x = bs1b;
	self.back2uo_bloodyscreen2.y = bs2b;	
	self.back2uo_bloodyscreen2.color = (1,1,1);
	self.back2uo_bloodyscreen2.alpha = 1;
	self.back2uo_bloodyscreen2.archived = true;
	self.back2uo_bloodyscreen2 SetShader("gfx/impact/flesh_hit2",96 + bs3b , 96 + bs3b);
 }
 
 // Abfrage
 if(!isDefined(self.back2uo_bloodyscreen3))
 { 
  // String
	bs1c = randomint(496);
	bs2c = randomint(336);
  bs3c = randomint(48);	
	self.back2uo_bloodyscreen3 = newClientHudElem(self);
	self.back2uo_bloodyscreen3.alignX = "left";
	self.back2uo_bloodyscreen3.alignY = "top";
	self.back2uo_bloodyscreen3.x = bs1c;
	self.back2uo_bloodyscreen3.y = bs2c;
	self.back2uo_bloodyscreen3.color = (1,1,1);
  self.back2uo_bloodyscreen3.alpha = 1;
  self.back2uo_bloodyscreen3.archived = true;
  self.back2uo_bloodyscreen3 SetShader("gfx/impact/flesh_hitgib",96 + bs3c , 96 + bs3c);
 }
 
 // Warteschleife 5 Sekunden
 wait 5;
 
 // Weiterleitung Update Blood FX
 self back2uo_update_bloodfx();
}
 
//////////////////////////////
// Back2Uo Update Blood FX //
////////////////////////////
back2uo_update_bloodfx()
{
 // Abfrage
 if(!game["back2uo_bloodsplater_enable"]) return;

 // Abfrage
 if(isDefined(self.back2uo_bloodyscreen))
 {
  self.back2uo_bloodyscreen.alpha = 1;
	self.back2uo_bloodyscreen fadeOverTime(1); 
	self.back2uo_bloodyscreen.alpha = 0;
 }

 // Abfrage
 if(isDefined(self.back2uo_bloodyscreen1))
 {
  self.back2uo_bloodyscreen1.alpha = 1;	
	self.back2uo_bloodyscreen1 fadeOverTime(1);
	self.back2uo_bloodyscreen1.alpha = 0;
 }

 // Abfrage
 if(isDefined(self.back2uo_bloodyscreen2))
 {
  self.back2uo_bloodyscreen2.alpha = 1;	
	self.back2uo_bloodyscreen2 fadeOverTime(1);
	self.back2uo_bloodyscreen2.alpha = 0;
 }

 // Abfrage
 if(isDefined(self.back2uo_bloodyscreen3))
 {	
  self.back2uo_bloodyscreen3.alpha = 1;
	self.back2uo_bloodyscreen3 fadeOverTime(1);
	self.back2uo_bloodyscreen3.alpha = 0;
 }
 
 // Warteschleife 3 Sekunden
 wait 3;	
  
 // Weiterleitung Clear Blood FX
 self back2uo_clear_bloodfx();  
}

/////////////////////////////
// Back2Uo Clear Blood FX //
///////////////////////////
back2uo_clear_bloodfx()
{
 // Abfrage
 if(!game["back2uo_bloodsplater_enable"]) return;

 // Abfrage
 if(isDefined(self.back2uo_bloodyscreen))	
  self.back2uo_bloodyscreen destroy();

 // Abfrage  
 if(isDefined(self.back2uo_bloodyscreen1))	
  self.back2uo_bloodyscreen1 destroy();

 // Abfrage  
 if(isDefined(self.back2uo_bloodyscreen2))	
  self.back2uo_bloodyscreen2 destroy();

 // Abfrage  
 if(isDefined(self.back2uo_bloodyscreen3))	
  self.back2uo_bloodyscreen3 destroy(); 
}

//////////////////////////
// Back2Uo Hud FX Draw //
////////////////////////
back2uo_hudfx_draw()
{
 // Abfrage
 if(!game["back2uo_hudfx_enable"]) return;
 
 // Abfrage
 if(!isdefined(level.back2uo_weather_allow)) level.back2uo_weather_allow = false;
 
 // Weiterleitung
 back2uo_hudfx_clear();

 // String
 level.hudfx_x = 93;
 level.hudfx_y = 465;

 // Abfrage - ThunderFx
 if(!isDefined(self.hud_thunderfx) && game["back2uo_weatherfx_enable"] && game["back2uo_thunderfx_enable"] && isdefined(game["weather_allow"]))
 {
  // Abfrage
  if(game["german_soldiertype"] != "winterlight" && game["german_soldiertype"] != "winterdark")
  {
   // String
   level.hudfx_x = level.hudfx_x + 15;
 
   self.hud_thunderfx = newClientHudElem(self);                               
   self.hud_thunderfx.x = level.hudfx_x;                                                
   self.hud_thunderfx.y = level.hudfx_y;                                                
   self.hud_thunderfx.horzAlign = "left";                                     
   self.hud_thunderfx.vertAlign = "top";                                      
   self.hud_thunderfx.alpha = 0.6;                                            
   self.hud_thunderfx.sort = 1;                                               
   self.hud_thunderfx.archived = true;                                       
   self.hud_thunderfx setShader("gfx/custom/back2uo_hud_thunderfx.tga", 10, 10); 
  }
 }
 
 // Abfrage - RainFx
 if(!isDefined(self.hud_rainfx) && game["back2uo_weatherfx_enable"] && game["back2uo_rainfx_enable"] && isdefined(game["weather_allow"]))
 {
  // Abfrage
  if(game["german_soldiertype"] != "winterlight" && game["german_soldiertype"] != "winterdark")
  {
   // String
   level.hudfx_x = level.hudfx_x + 15;
 
   self.hud_rainfx = newClientHudElem(self);                               
   self.hud_rainfx.x = level.hudfx_x;                                                
   self.hud_rainfx.y = level.hudfx_y;                                                
   self.hud_rainfx.horzAlign = "left";                                     
   self.hud_rainfx.vertAlign = "top";                                      
   self.hud_rainfx.alpha = 0.6;                                            
   self.hud_rainfx.sort = 1;                                               
   self.hud_rainfx.archived = true;                                       
   self.hud_rainfx setShader("gfx/custom/back2uo_hud_rainfx.tga", 10, 10);   
  }
 }

 // Abfrage - SnowFx
 if(!isDefined(self.hud_winterfx) && game["back2uo_weatherfx_enable"] && game["back2uo_snowfx_enable"] && isdefined(game["weather_allow"]))
 {
  // Abfrage
  if(game["german_soldiertype"] == "winterlight" || game["german_soldiertype"] == "winterdark")
  {
   // String
   level.hudfx_x = level.hudfx_x + 15;
   
   self.hud_winterfx = newClientHudElem(self);                               
   self.hud_winterfx.x = level.hudfx_x;                                                
   self.hud_winterfx.y = level.hudfx_y;                                                
   self.hud_winterfx.horzAlign = "left";                                     
   self.hud_winterfx.vertAlign = "top";                                      
   self.hud_winterfx.alpha = 0.6;                                            
   self.hud_winterfx.sort = 1;                                               
   self.hud_winterfx.archived = true;                                       
   self.hud_winterfx setShader("gfx/custom/back2uo_hud_snowfx.tga", 10, 10);  
  }
 }

 // Abfrage - FlakFx
 if(!isDefined(self.hud_flakfx) && game["back2uo_warfx_enable"] && game["back2uo_flakfx_enable"])
 {
  // String
  level.hudfx_x = level.hudfx_x + 15; 
 
  self.hud_flakfx = newClientHudElem(self);                               
  self.hud_flakfx.x = level.hudfx_x;                                                
  self.hud_flakfx.y = level.hudfx_y;                                                
  self.hud_flakfx.horzAlign = "left";                                     
  self.hud_flakfx.vertAlign = "top";                                      
  self.hud_flakfx.alpha = 0.6;                                            
  self.hud_flakfx.sort = 1;                                               
  self.hud_flakfx.archived = true;                                       
  self.hud_flakfx setShader("gfx/custom/back2uo_hud_flakfx.tga", 10, 10);  
 }
 
 // Abfrage - MortarFx 
 if(!isDefined(self.hud_mortarfx) && game["back2uo_warfx_enable"] && game["back2uo_mortarfx_enable"])
 {
  // String
  level.hudfx_x = level.hudfx_x + 15; 
 
  self.hud_mortarfx = newClientHudElem(self);                               
  self.hud_mortarfx.x = level.hudfx_x;                                                
  self.hud_mortarfx.y = level.hudfx_y;                                                
  self.hud_mortarfx.horzAlign = "left";                                     
  self.hud_mortarfx.vertAlign = "top";                                      
  self.hud_mortarfx.alpha = 0.6;                                            
  self.hud_mortarfx.sort = 1;                                               
  self.hud_mortarfx.archived = true;                                       
  self.hud_mortarfx setShader("gfx/custom/back2uo_hud_mortarfx.tga", 10, 10);  
 } 
 
 // Abfrage - ArtilleryFx 
 if(!isDefined(self.hud_artilleryfx) && game["back2uo_warfx_enable"] && game["back2uo_artilleryfx_enable"])
 {
  // String
  level.hudfx_x = level.hudfx_x + 15; 
 
  self.hud_artilleryfx = newClientHudElem(self);                               
  self.hud_artilleryfx.x = level.hudfx_x;                                                
  self.hud_artilleryfx.y = level.hudfx_y;                                                
  self.hud_artilleryfx.horzAlign = "left";                                     
  self.hud_artilleryfx.vertAlign = "top";                                      
  self.hud_artilleryfx.alpha = 0.6;                                            
  self.hud_artilleryfx.sort = 1;                                               
  self.hud_artilleryfx.archived = true;                                       
  self.hud_artilleryfx setShader("gfx/custom/back2uo_hud_artilleryfx.tga", 10, 10);  
 }
} 

///////////////////////////
// Back2Uo Hud FX Clear //
/////////////////////////
back2uo_hudfx_clear()
{
 // Abfrage
 if(!game["back2uo_hudfx_enable"]) return;

 // Abfrage
 if(isDefined(self.hud_rainfx)) 
  self.hud_rainfx destroy();
  
 // Abfrage
 if(isDefined(self.hud_thunderfx)) 
  self.hud_thunderfx destroy();
  
 // Abfrage
 if(isDefined(self.hud_winterfx)) 
  self.hud_winterfx destroy();
      
 // Abfrage
 if(isDefined(self.hud_flakfx)) 
  self.hud_flakfx destroy();  
  
 // Abfrage
 if(isDefined(self.hud_mortarfx)) 
  self.hud_mortarfx destroy();  
  
 // Abfrage
 if(isDefined(self.hud_artilleryfx )) 
  self.hud_artilleryfx  destroy();     
} 

///////////////////////////
// Back2Uo Ranking Draw //
/////////////////////////
back2uo_ranking_draw()
{
 // Abfrage	
 if(!game["back2uo_ranking_enable"]) return;

 // Abfrage
 if(!isdefined(self.hud_ranking_lv))
 {
  // String
  self.hud_ranking_lv = newClientHudElem(self);                               
  self.hud_ranking_lv.x = -204;                                                
  self.hud_ranking_lv.y = 390;                                                
  self.hud_ranking_lv.horzAlign = "center";                                     
  self.hud_ranking_lv.vertAlign = "top";                                                                                
  self.hud_ranking_lv.sort = 1;                                               
  self.hud_ranking_lv.archived = true;  
  self.hud_ranking_lv.alpha = 0.6;        
 }
 
 // Abfrage
 if(!isdefined(self.pers["back2uo_score_ranking_pic"])) self.pers["back2uo_score_ranking_pic"] = "gfx/custom/back2uo_ranking_lv1.tga";
 self.statusicon = self.pers["back2uo_score_ranking_pic"]; 
}

/////////////////////////////
// Back2Uo Ranking Update //
///////////////////////////
back2uo_ranking_update() 
{
 // Abfrage	
 if(!game["back2uo_ranking_enable"]) return;
 
 // Disconnect
 self endon("disconnect"); 
  
 // Kill Threads
 level endon("back2uo_killthreads"); 
 
 // String - Artillery
 if(game["back2uo_artilleryfx_enable"] && isdefined(self.pers["artillery_save"]))
 {
  // Weiterleitung
  thread back2uo\_back2uo_warfx::back2uo_artilleryfx_binowaituse(); 
 }
	
 // For Schleife
 for(;;) 
 {   
  // String
  player_score = self.score;
  
  // Abfrage
  if(!isdefined(self.pers["back2uo_ranking"])) self.pers["back2uo_ranking"] = 1; 
  self.pers["back2uo_ranking_new"] = self.pers["back2uo_ranking"];
 
	// Abfrage	
	if(player_score >= level.back2uo_ranking_level1 && player_score < level.back2uo_ranking_level2) 
  {	
   // String                                       
   self.back2uo_ranking_pic = "gfx/custom/back2uo_ranking_lv2.tga";
   self.pers["back2uo_score_ranking_pic"] = "gfx/custom/back2uo_ranking_lv2.tga";  
   self.pers["back2uo_ranking"] = 2;                                    
	}
	else if(player_score >= level.back2uo_ranking_level2 && player_score < level.back2uo_ranking_level3) 
  {		
   // String                                         
   self.back2uo_ranking_pic = "gfx/custom/back2uo_ranking_lv3.tga";
   self.pers["back2uo_score_ranking_pic"] = "gfx/custom/back2uo_ranking_lv3.tga";
   self.pers["back2uo_ranking"] = 3;                                      
	}
	else if(player_score >= level.back2uo_ranking_level3 && player_score < level.back2uo_ranking_level4) 
  {		
   // String                                         
   self.back2uo_ranking_pic = "gfx/custom/back2uo_ranking_lv4.tga"; 
   self.pers["back2uo_score_ranking_pic"] = "gfx/custom/back2uo_ranking_lv4.tga"; 
   self.pers["back2uo_ranking"] = 4;
	}
	else if(player_score >= level.back2uo_ranking_level4) 
  {		
   // String                                         
   self.back2uo_ranking_pic = "gfx/custom/back2uo_ranking_lv5.tga"; 
   self.pers["back2uo_score_ranking_pic"] = "gfx/custom/back2uo_ranking_lv5.tga";
   self.pers["back2uo_ranking"] = 5;                                
	}
	else
	{
   // String                                        
   self.back2uo_ranking_pic = "gfx/custom/back2uo_ranking_lv1.tga";
   self.pers["back2uo_score_ranking_pic"] = "gfx/custom/back2uo_ranking_lv1.tga";
   self.pers["back2uo_ranking"] = 1;  
  }
  
  // Abfrage
  if(self.pers["back2uo_ranking"] != self.pers["back2uo_ranking_new"])
  {
   // Abfrage
	 if(self.pers["back2uo_ranking"] > self.pers["back2uo_ranking_new"])
	 {
    // String - Play Sound
    self playLocalSound("ranking_up");  
   
    // String - Iprint
    self iprintln(&"BACK2UOMOD_RANKING_UP");
   }
   else
   {
    // String - Play Sound
    self playLocalSound("ranking_down");  
   
    // String - Iprint
    self iprintln(&"BACK2UOMOD_RANKING_DOWN");   
   }
  
   // Abfrage
   if(isdefined(self.hud_ranking_lv))
   {     
    // String
    self.statusicon = self.pers["back2uo_score_ranking_pic"];
     
    // String
	  self.hud_ranking_lv.alpha = 0.4;
	  self.hud_ranking_lv.x = -206;
	  self.hud_ranking_lv.y = 388;
    self.hud_ranking_lv setShader(self.back2uo_ranking_pic, 28, 28);
    wait 0.2;
	  self.hud_ranking_lv.alpha = 0.2; 
	  self.hud_ranking_lv.x = -208;
	  self.hud_ranking_lv.y = 386;
    self.hud_ranking_lv setShader(self.back2uo_ranking_pic, 32, 32);
    wait 0.2;
	  self.hud_ranking_lv.alpha = 0.4;
	  self.hud_ranking_lv.x = -206;
	  self.hud_ranking_lv.y = 388;
    self.hud_ranking_lv setShader(self.back2uo_ranking_pic, 28, 28);
    wait 0.1;
	  self.hud_ranking_lv.alpha = 0.6;
	  self.hud_ranking_lv.x = -204;
	  self.hud_ranking_lv.y = 390;
    self.hud_ranking_lv setShader(self.back2uo_ranking_pic, 24, 24);  
   }
   
   // Abfrage
   if(self.pers["back2uo_ranking"] == 1)
   {
    // String
    self.pers["back2uo_artillery_go"] = false; 
   }
   else if(self.pers["back2uo_ranking"] == 2)
   { 
    // Abfrage
    if(isdefined(self.pers["rankinglevel_a"])) return;
     self.pers["rankinglevel_a"] = true;    
   
    // String - Pistel
    if(level.back2uo_rang1_getsekammo > 0)
    {
     pistelammo = self getWeaponSlotClipAmmo("primaryb");
     pistelresammo = self getWeaponSlotAmmo("primary");			
     self setWeaponSlotAmmo("primaryb", pistelammo + pistelresammo + level.back2uo_rang1_getsekammo);
    }
  
    // String - MG
    if(level.back2uo_rang1_getpriammo > 0)
    {
     mgammo = self getWeaponSlotClipAmmo("primary");
     mgresammo = self getWeaponSlotAmmo("primary");		
     self setWeaponSlotAmmo("primary", mgammo + mgresammo + level.back2uo_rang1_getpriammo);     
    }
 
    // String - Granade
    if(level.back2uo_rang1_getgranade > 0)
    {
     granadetype = self back2uo\_back2uo_tools::back2uo_getgranade_type("granade");
     granadecount = self getammocount(granadetype);
     self setWeaponClipAmmo(granadetype, granadecount + level.back2uo_rang1_getgranade);
    }
  
    // String - Smoke
    if(level.back2uo_rang1_getsmoke > 0)
    {
     smoketype = self back2uo\_back2uo_tools::back2uo_getgranade_type("smoke");
     smokecount = self getammocount(smoketype);	
     self setWeaponClipAmmo(smoketype, smokecount + level.back2uo_rang1_getsmoke);   
    }
    
    // String - Binocular
    if(level.back2uo_binocular_allow && level.back2uo_binocular_onrank == 1)
    {
     // String
     self takeWeapon("binoculars_mp");
    }
  
    // String - Artillery
    if(game["back2uo_artilleryfx_enable"] && level.back2uo_artillery_onrank == 1)
    {    
     // Abfrage
     if(isdefined(self.pers["artillery_save"])) return; 
  
     // Weiterleitung
     thread back2uo\_back2uo_warfx::back2uo_artilleryfx_control(); 
    }  
   }
   else if(self.pers["back2uo_ranking"] == 3)
   { 
    // Abfrage
    if(isdefined(self.pers["rankinglevel_b"])) return;
     self.pers["rankinglevel_b"] = true;   
     
    // String - Pistel
    if(level.back2uo_rang2_getsekammo > 0)
    {  
     pistelammo = self getWeaponSlotClipAmmo("primaryb");	
     pistelresammo = self getWeaponSlotAmmo("primary");		
     self setWeaponSlotAmmo("primaryb", pistelammo + pistelresammo + level.back2uo_rang2_getsekammo); 
    } 
  
    // String - MG
    if(level.back2uo_rang2_getpriammo > 0)
    {   
     mgammo = self getWeaponSlotClipAmmo("primary");	
     mgresammo = self getWeaponSlotAmmo("primary");		
     self setWeaponSlotAmmo("primary", mgammo + mgresammo + level.back2uo_rang2_getpriammo);  
    }
 
    // String - Granade
    if(level.back2uo_rang2_getgranade > 0)
    {   
     granadetype = self back2uo\_back2uo_tools::back2uo_getgranade_type("granade");
     granadecount = self getammocount(granadetype);
     self setWeaponClipAmmo(granadetype, granadecount + level.back2uo_rang2_getgranade);
    }

    // String - Smoke
    if(level.back2uo_rang2_getsmoke > 0)
    {   
     smoketype = self back2uo\_back2uo_tools::back2uo_getgranade_type("smoke");
     smokecount = self getammocount(smoketype);	
     self setWeaponClipAmmo(smoketype, smokecount + level.back2uo_rang2_getsmoke);  
    }
    
    // String - Binocular
    if(level.back2uo_binocular_allow && level.back2uo_binocular_onrank <= 2)
    {
     // String
     self takeWeapon("binoculars_mp");
    }    

    // String - Artillery
    if(game["back2uo_artilleryfx_enable"] && level.back2uo_artillery_onrank <= 2)
    {      
     // Abfrage
     if(isdefined(self.pers["artillery_save"])) return;  
  
     // Weiterleitung
     thread back2uo\_back2uo_warfx::back2uo_artilleryfx_control(); 
    }  
   } 
   else if(self.pers["back2uo_ranking"] == 4)
   {  
    // Abfrage
    if(isdefined(self.pers["rankinglevel_c"])) return;
     self.pers["rankinglevel_c"] = true;   
   
    // String - Pistel
    if(level.back2uo_rang3_getsekammo > 0)
    {  
     pistelammo = self getWeaponSlotClipAmmo("primaryb");	
     pistelresammo = self getWeaponSlotAmmo("primary");		
     self setWeaponSlotAmmo("primaryb", pistelammo + pistelresammo + level.back2uo_rang3_getsekammo); 
    }
  
    // String - MG
    if(level.back2uo_rang3_getpriammo > 0)
    {    
     mgammo = self getWeaponSlotClipAmmo("primary");	
     mgresammo = self getWeaponSlotAmmo("primary");		
     self setWeaponSlotAmmo("primary", mgammo + mgresammo + level.back2uo_rang3_getpriammo);     
    }
  
    // String - Granade
    if(level.back2uo_rang3_getgranade > 0)
    {    
     granadetype = self back2uo\_back2uo_tools::back2uo_getgranade_type("granade");
     granadecount = self getammocount(granadetype);
     self setWeaponClipAmmo(granadetype, granadecount + level.back2uo_rang3_getgranade);
    }

    // String - Smoke
    if(level.back2uo_rang3_getsmoke > 0)
    {    
     smoketype = self back2uo\_back2uo_tools::back2uo_getgranade_type("smoke");
     smokecount = self getammocount(smoketype);	
     self setWeaponClipAmmo(smoketype, smokecount + level.back2uo_rang3_getsmoke);  
    }
    
    // String - Binocular
    if(level.back2uo_binocular_allow && level.back2uo_binocular_onrank <= 3)
    {
     // String
     self takeWeapon("binoculars_mp");
    }    
  
    // String - Artillery
    if(game["back2uo_artilleryfx_enable"] && level.back2uo_artillery_onrank <= 3)
    {       
     // Abfrage
     if(isdefined(self.pers["artillery_save"])) return;        
   
     // Weiterleitung
     thread back2uo\_back2uo_warfx::back2uo_artilleryfx_control(); 
    }  
   }
   else if(self.pers["back2uo_ranking"] == 5)
   {
    // Abfrage
    if(isdefined(self.pers["rankinglevel_d"])) return;
     self.pers["rankinglevel_d"] = true;   
   
    // String - Pistel
    if(level.back2uo_rang4_getsekammo > 0)
    {  
     pistelammo = self getWeaponSlotClipAmmo("primaryb");	
     pistelresammo = self getWeaponSlotAmmo("primary");		
     self setWeaponSlotAmmo("primaryb", pistelammo + pistelresammo + level.back2uo_rang4_getsekammo); 
    }
 
    // String - MG
    if(level.back2uo_rang4_getpriammo > 0)
    {  
     mgammo = self getWeaponSlotClipAmmo("primary");	
     mgresammo = self getWeaponSlotAmmo("primary");		
     self setWeaponSlotAmmo("primary", mgammo + mgresammo + level.back2uo_rang4_getpriammo);    
    }
 
    // String - Granade
    if(level.back2uo_rang4_getgranade > 0)
    {  
     granadetype = self back2uo\_back2uo_tools::back2uo_getgranade_type("granade");
     granadecount = self getammocount(granadetype);
     self setWeaponClipAmmo(granadetype, granadecount + level.back2uo_rang4_getgranade);
    }

    // String - Smoke
    if(level.back2uo_rang4_getsmoke > 0)
    {  
     smoketype = self back2uo\_back2uo_tools::back2uo_getgranade_type("smoke");
     smokecount = self getammocount(smoketype);	
     self setWeaponClipAmmo(smoketype, smokecount + level.back2uo_rang4_getsmoke);  
    }
   
    // String - Binocular
    if(level.back2uo_binocular_allow && level.back2uo_binocular_onrank == 4)
    {
     // String
     self takeWeapon("binoculars_mp");
    }   
   
    // String - Artillery
    if(game["back2uo_artilleryfx_enable"] && level.back2uo_artillery_onrank == 4)
    {      
     // Abfrage
     if(isdefined(self.pers["artillery_save"])) return;          
   
     // Weiterleitung
     thread back2uo\_back2uo_warfx::back2uo_artilleryfx_control(); 
    }
   }   
  }
  else
  {
   // Abfrage
   if(isdefined(self.hud_ranking_lv))
   {       
    // String
    self.hud_ranking_lv setShader(self.back2uo_ranking_pic, 24, 24); 
   }
  }   
   
  // Warteschleife 0.5 Sekunde
  wait 0.5;
 }
}

////////////////////////////
// Back2Uo Ranking Clear //
//////////////////////////
back2uo_ranking_clear()
{
 // Abfrage	
 if(!game["back2uo_ranking_enable"]) return;

 // Abfrage
 if(isDefined(self.hud_ranking_lv))
  self.hud_ranking_lv destroy();      
  
 // String
 self.statusicon = "gfx/custom/back2uo_deadicon.tga";                                 
}

////////////////////////////////
// Back2Uo Binocular Control //
//////////////////////////////
back2uo_binocular_control()
{
 // Abfrage
 if(!game["back2uo_binocularhud_enable"]) return;

 // String
 self endon("disconnect");

 // For Schleife
 for (;;)
 {
  // Warteschleife -  Binocular Enter
	self waittill("binocular_enter");
	
	// Warteschleife 0.3 Sekunden
	wait (0.3);
	
	// Weiterleitung
	self thread back2uo_binocular_distance_draw();
	
  // Weiterleitung
  self thread back2uo_binocular_distance_clear();
	
  // Warteschleife
  wait .2;
 }
}

//////////////////////////////////////
// Back2Uo Binocular Distance Draw //
////////////////////////////////////
back2uo_binocular_distance_draw()
{
 // Abfrage
 if(!game["back2uo_binocularhud_enable"]) return;

 // String
 self endon("binocular_exit"); 

 // Abfrage
 if(!isdefined(self.back2uo_artlength))
 { 
  // String
  self.back2uo_artlength = newClientHudElem( self );
	self.back2uo_artlength.alignX = "right";
	self.back2uo_artlength.alignY = "top";
	self.back2uo_artlength.fontScale = 1;
	self.back2uo_artlength.x = 340;
	self.back2uo_artlength.y = 380;
	self.back2uo_artlength.alpha = 0.7;	
	self.back2uo_artlength.label = &"BACK2UOMOD_BINOCULAR_DISTANCE";
 }
 
 // Abfrage
 if(!isdefined(self.back2uo_artmeters))
 { 
  // String
  self.back2uo_artmeters = newClientHudElem( self );
	self.back2uo_artmeters.alignX = "left";
	self.back2uo_artmeters.alignY = "top";
	self.back2uo_artmeters.fontScale = 1;
	self.back2uo_artmeters.x = 340;
	self.back2uo_artmeters.y = 380;
	self.back2uo_artmeters.alpha = 0.7;	
	self.back2uo_artmeters setText(&"BACK2UOMOD_BINOCULAR_METERS");
 } 

 // For Schleife
 for(;;)
 {
  // String
  binopositarget = back2uo\_back2uo_cvars::back2uo_getpositarget();
 
  // Abfrage
  if(isdefined(binopositarget))
  {
   // String
   dangerzonegitter = distance( self.origin, binopositarget ); 
   dangerzonemeter = int(int(dangerzonegitter * 2.5) / 100);
   
   // Abfrage
   if(isdefined(self.back2uo_artlength))
   {
    self.back2uo_artlength.x = 340;
    self.back2uo_artlength.alpha = 0.7;
    self.back2uo_artlength setValue(dangerzonemeter);
   }
   
   // Abfrage
   if(isdefined(self.back2uo_artmeters))
   {
    self.back2uo_artmeters.alpha = 0.7;
    self.back2uo_artmeters setText(&"BACK2UOMOD_BINOCULAR_METERS");
   }
  }
  else
  { 
   // Abfrage
   if(isdefined(self.back2uo_artlength))
   {
    // String
    self.back2uo_artlength.x = 332;
    self.back2uo_artlength.alpha = 0.7;
    self.back2uo_artlength setText(&"BACK2UOMOD_BINOCULAR_NONE");
   } 
   
   // Abfrage
   if(isdefined(self.back2uo_artmeters))
   {
    // String
    self.back2uo_artmeters.alpha = 0.7; 
    self.back2uo_artmeters setText(&"BACK2UOMOD_BINOCULAR_UNKNOWN");
   }    
  }
     
  // Warteschleife
  wait (0.1);
 }
}

///////////////////////////////////////
// Back2Uo Binocular Distance Clear //
/////////////////////////////////////
back2uo_binocular_distance_clear()
{
 // Abfrage
 if(!game["back2uo_binocularhud_enable"]) return;
 
 // Warteschleife
 self waittill("binocular_exit"); 
 
 // Abfrage
 if(isdefined(self.back2uo_artlength)) self.back2uo_artlength destroy(); 
 if(isdefined(self.back2uo_artmeters)) self.back2uo_artmeters destroy();
}

/////////////////////////////////////////
// Back2Uo Binocular Distance Clear 2 //
///////////////////////////////////////
back2uo_binocular_distance_clear2()
{
 // Abfrage
 if(!game["back2uo_binocularhud_enable"]) return;
 
 // Abfrage
 if(isdefined(self.back2uo_artlength)) self.back2uo_artlength destroy(); 
 if(isdefined(self.back2uo_artmeters)) self.back2uo_artmeters destroy();
}

/////////////////////////////
// Back2Uo Start GameType //
///////////////////////////
back2uo_start_gametype()
{
 // Abfrage
 if(!game["back2uo_enable"]) return;	

 // Weiterleitung ( Map | Player ) Dimension
 back2uo\_back2uo_tools::back2uo_playerdimension();
 back2uo\_back2uo_tools::back2uo_mapdimension();
 
 // Weiterleitung Map Weather Random Allow
 back2uo\_back2uo_weatherfx::back2uo_weather_randomallow(); 
 
 // Weiterleitung War FX Random
 thread back2uo\_back2uo_warfx::back2uo_warfx_random();  
 
 // Weiterleitung Random Map Rotation
 thread back2uo\_back2uo_tools::back2uo_getmaprotation_control(); 
 
 // Weiterleitung Map Weather Control
 thread back2uo\_back2uo_weatherfx::back2uo_weathercontrol();
  
 // Weiterleitung Weather Thunder Fx Draw  
 thread back2uo\_back2uo_weatherfx::back2uo_thunder_draw(); 
  
 // Weiterleitung Mortar FX Draw
 thread back2uo\_back2uo_warfx::back2uo_mortarfx_control(); 
 
 // Weiterleitung Airplanes FX Draw
 thread back2uo\_back2uo_warfx::back2uo_airplanefx_control();  
 
 // Weiterleitung Weapon Limitierung
 thread back2uo\_back2uo_weaponsystem::back2uo_weapon_limitiert();
 
 // Weiterleitung Weapon Optimierung
 thread back2uo\_back2uo_weaponsystem::back2uo_weapon_optimizer();
 
 // Weiterleitung Switch Spectator
 thread back2uo\_back2uo_antiplay::back2uo_switchspec();   
 
 // Weiterleitung Servertext Message Draw
 thread back2uo\_back2uo_messages::back2uo_credits_draw();  
 
 // Weiterleitung Clan Messages Draw
 thread back2uo\_back2uo_messages::back2uo_clan_messages_draw();
}

/////////////////////////////
// Back2Uo Player Connect //
///////////////////////////
back2uo_player_connect()
{ 
 // Abfrage
 if(!game["back2uo_enable"]) return;	
 
 // Weiterleitung Cod 2 Client Settings
 thread back2uo\_back2uo_cod2set::back2uo_clientset_init();
 
 // Weiterleitung Anti Player AFK Draw
 thread back2uo\_back2uo_antiplay::back2uo_antiplay_afk();
 
 // Weiterleitung Anti Player Camper Draw
 thread back2uo\_back2uo_antiplay::back2uo_antiplay_camper(); 
 
 // Weiterleitung Binocular Distance Draw
 thread back2uo\_back2uo_hudfx::back2uo_binocular_control();
}

////////////////////////////////
// Back2Uo Player Disconnect //
//////////////////////////////
back2uo_player_disconnect()
{
 // Abfrage
 if(!game["back2uo_enable"]) return;
}

////////////////////////////
// Back2Uo Player Damage //
//////////////////////////
back2uo_player_damage()
{
 // Abfrage
 if(!game["back2uo_enable"]) return;	

 // Weiterleitung Pain Sound Play
 thread back2uo\_back2uo_sounds::back2uo_painsound_play();
 
 // Weiterleitung Blood Sprites Effekt
 thread back2uo\_back2uo_hudfx::back2uo_view_bloodfx(); 
}

////////////////////////////
// Back2Uo Player Killed //
//////////////////////////
back2uo_player_killed()
{
 // Abfrage
 if(!game["back2uo_enable"]) return;

 // Weiterleitung Pain Sound Play
 thread back2uo\_back2uo_sounds::back2uo_deathsound_play();

 // Weiterleitung Medi Packs
 thread back2uo\_back2uo_medipacks::back2uo_dropHealthPacks();
  
 // Weiterleitung Healthbar Update 
 thread back2uo\_back2uo_hudfx::back2uo_healthbar_update(); 
 
 // Weiterleitung Artillery Binocular Info Clear
 thread back2uo\_back2uo_warfx::back2uo_artilleryfx_binotext_clear2(); 
 
 // Weiterleitung Anti Player Camper Remove
 thread back2uo\_back2uo_antiplay::back2uo_antiplay_camper_remove2();
 
 // Weiterleitung Binocular Distance Clear
 thread back2uo\_back2uo_hudfx::back2uo_binocular_distance_clear2();
}

///////////////////////////
// Back2Uo Player Spawn //
/////////////////////////
back2uo_player_spawn()
{
 // Abfrage
 if(!game["back2uo_enable"]) return;	  
 
 // Weiterleitung Wellcome Message Draw
 thread back2uo\_back2uo_messages::back2uo_wellc_messages_draw();  
 
 // Weiterleitung Spawn Protection Draw
 thread back2uo\_back2uo_antiplay::back2uo_antiplay_spawn_start();     
 
 // Weiterleitung Coldbreath Draw
 thread back2uo\_back2uo_weatherfx::back2uo_coldbreath_draw();   
 
 // Weiterleitung Blood Fx Clear
 thread back2uo\_back2uo_hudfx::back2uo_clear_bloodfx(); 
    
 // Weiterleitung Healthbar Draw 
 thread back2uo\_back2uo_hudfx::back2uo_healthbar_draw();

 // Weiterleitung Player Position Draw 
 thread back2uo\_back2uo_hudfx::back2uo_playerposition_draw();
 
 // Weiterleitung Player Ranking Draw
 thread back2uo\_back2uo_hudfx::back2uo_ranking_draw();
  
 // Weiterleitung Compass Draw
 thread back2uo\_back2uo_hudfx::back2uo_compass_draw(); 
 
 // Weiterleitung Hud Fx Draw
 thread back2uo\_back2uo_hudfx::back2uo_hudfx_draw(); 
 
 // Weiterleitung Player Score Draw
 thread back2uo\_back2uo_hudfx::back2uo_playerscore_draw();  
 
 // Weiterleitung Team Score Draw
 thread back2uo\_back2uo_hudfx::back2uo_teamscore_draw(); 
 
 // Weiterleitung Healthbar Update 
 thread back2uo\_back2uo_hudfx::back2uo_healthbar_update();
 
 // Weiterleitung Player Ranking Update 
 thread back2uo\_back2uo_hudfx::back2uo_ranking_update();
 
 // Weiterleitung Player Score Update
 thread back2uo\_back2uo_hudfx::back2uo_playerscore_update();  
 
 // Weiterleitung Team Score Update
 thread back2uo\_back2uo_hudfx::back2uo_teamscore_update();   
 
 // Weiterleitung Binocular Distance Clear
 thread back2uo\_back2uo_hudfx::back2uo_binocular_distance_clear2();       
}

///////////////////////////////
// Back2Uo Player Spectator //
/////////////////////////////
back2uo_player_spectator()
{
 // Abfrage
 if(!game["back2uo_enable"]) return;	

 // Weiterleitung Blood Fx Clear
 thread back2uo\_back2uo_hudfx::back2uo_clear_bloodfx();

 // Weiterleitung Healthbar Clear
 thread back2uo\_back2uo_hudfx::back2uo_healthbar_clear();
 
 // Weiterleitung Player Position Clear
 thread back2uo\_back2uo_hudfx::back2uo_playerposition_clear();
 
 // Weiterleitung Compass Clear
 thread back2uo\_back2uo_hudfx::back2uo_compass_clear();    

 // Weiterleitung Hud Fx Clear
 thread back2uo\_back2uo_hudfx::back2uo_hudfx_clear();
 
 // Weiterleitung Player Ranking Clear
 thread back2uo\_back2uo_hudfx::back2uo_ranking_clear(); 
 
 // Weiterleitung Player Score Clear
 thread back2uo\_back2uo_hudfx::back2uo_playerscore_clear();
 
 // Weiterleitung Team Score Clear
 thread back2uo\_back2uo_hudfx::back2uo_teamscore_clear(); 
 
 // Weiterleitung Binocular Distance Clear
 thread back2uo\_back2uo_hudfx::back2uo_binocular_distance_clear2(); 
}

///////////////////////////
// Back2Uo Wait Respawn //
/////////////////////////
back2uo_clear_elements()
{
 // Abfrage
 if(!game["back2uo_enable"]) return;	
 
 // Weiterleitung Compass Clear
 thread back2uo\_back2uo_hudfx::back2uo_compass_clear();  

 // Weiterleitung Blood Fx Clear
 thread back2uo\_back2uo_hudfx::back2uo_clear_bloodfx();

 // Weiterleitung Healthbar Clear
 thread back2uo\_back2uo_hudfx::back2uo_healthbar_clear();
 
 // Weiterleitung Player Position Clear
 thread back2uo\_back2uo_hudfx::back2uo_playerposition_clear();
 
 // Weiterleitung Player Ranking Clear
 thread back2uo\_back2uo_hudfx::back2uo_ranking_clear();

 // Weiterleitung Hud Fx Clear
 thread back2uo\_back2uo_hudfx::back2uo_hudfx_clear();
}

///////////////////////////////
// Back2Uo Player Dimension //
/////////////////////////////
back2uo_playerdimension()
{
 // String
 spawnpoints = [];

 spawnpoints_s1 = getentarray("mp_dm_spawn", "classname");
 spawnpoints_s2 = getentarray("mp_tdm_spawn", "classname");
 spawnpoints_s3 = getentarray("mp_ctf_spawn_allied", "classname");
 spawnpoints_s4 = getentarray("mp_ctf_spawn_axis", "classname");
 spawnpoints_s5 = getentarray("mp_sd_spawn_attacker", "classname");
 spawnpoints_s6 = getentarray("mp_sd_spawn_defender", "classname");

 // For Schleife
 for(i=0;i<spawnpoints_s1.size;i++) 
 {
  spawnpoints = maps\mp\gametypes\_spawnlogic::add_to_array(spawnpoints, spawnpoints_s1[i]);
 }
 
 // For Schleife	
 for(i=0;i<spawnpoints_s2.size;i++) 
 {
  spawnpoints = maps\mp\gametypes\_spawnlogic::add_to_array(spawnpoints, spawnpoints_s2[i]);
 }
 
 // For Schleife	
 for(i=0;i<spawnpoints_s3.size;i++) 
 {
  spawnpoints = maps\mp\gametypes\_spawnlogic::add_to_array(spawnpoints, spawnpoints_s3[i]);
 }

 // For Schleife	
 for(i=0;i<spawnpoints_s4.size;i++) 
 {
  spawnpoints = maps\mp\gametypes\_spawnlogic::add_to_array(spawnpoints, spawnpoints_s4[i]);
 }

 // For Schleife	
 for(i=0;i<spawnpoints_s5.size;i++) 
 {
  spawnpoints = maps\mp\gametypes\_spawnlogic::add_to_array(spawnpoints, spawnpoints_s5[i]);
 }

 // For Schleife	
 for(i=0;i<spawnpoints_s6.size;i++) 
 {
  spawnpoints = maps\mp\gametypes\_spawnlogic::add_to_array(spawnpoints, spawnpoints_s6[i]);
 } 

 // String - X-Axe ( Min | Max )
 xMin = spawnpoints[0].origin[0];
 xMax = spawnpoints[0].origin[0];

 // String - Y-Axe ( Min | Max )
 yMin = spawnpoints[0].origin[1];
 yMax = spawnpoints[0].origin[1];

 // String - Z-Axe ( Min | Max )
 zMin = spawnpoints[0].origin[2];
 zMax = spawnpoints[0].origin[2];

 // For Schleife
 for(i=1;i<spawnpoints.size;i++)
 {
  // Abfrage
	if (spawnpoints[i].origin[0] > xMax) xMax = spawnpoints[i].origin[0];
	if (spawnpoints[i].origin[1] > yMax) yMax = spawnpoints[i].origin[1];
	if (spawnpoints[i].origin[2] > zMax) zMax = spawnpoints[i].origin[2];
	
	if (spawnpoints[i].origin[0] < xMin) xMin = spawnpoints[i].origin[0];
	if (spawnpoints[i].origin[1] < yMin) yMin = spawnpoints[i].origin[1];
	if (spawnpoints[i].origin[2] < zMin) zMin = spawnpoints[i].origin[2];
 }
 
 // String
 level.back2uo_playerdimo_xMax = xMax;
 level.back2uo_playerdimo_yMax = yMax;
 level.back2uo_playerdimo_zMax = zMax;
 
 level.back2uo_playerdimo_xMin = xMin;
 level.back2uo_playerdimo_yMin = yMin;
 level.back2uo_playerdimo_zMin = zMin;
 
 // String
 ambientfx_hoehe = 800;
 
 // String
 level.back2uo_playerdimo_centerx = int(int(xMax + xMin)/2);
 level.back2uo_playerdimo_centery = int(int(yMax + yMin)/2);
 level.back2uo_playerdimo_centerz = int(int(zMax + zMin)/2);
 level.back2uo_playerdimo_center = (level.back2uo_playerdimo_centerx, level.back2uo_playerdimo_centery, level.back2uo_playerdimo_centerz);

 // String
 level.back2uo_playerdimo_breite = int(distance((xMin,yMin,ambientfx_hoehe),(xMax,yMin,ambientfx_hoehe))); 
 level.back2uo_playerdimo_laenge = int(distance((xMin,yMin,ambientfx_hoehe),(xMin,yMax,ambientfx_hoehe))); 
}

///////////////////////////////
// Back2Uo Player Dimension //
/////////////////////////////
back2uo_mapdimension()
{
  entitytypes = getentarray();  

	xMax2 = -30000;
	xMin2 = 30000;

	yMax2 = -30000;
	yMin2 = 30000;

	zMax2 = -30000;
	zMin2 = 30000;

	xMin_e[0] = xMax2;
	yMin_e[1] = yMax2;
	zMin_e[2] = zMax2;

	xMax_e[0] = xMin2;
	yMax_e[1] = yMin2;
	zMax_e[2] = zMin2;  
  
	for(i = 1; i < entitytypes.size; i++)
	{	  
		 trace = bulletTrace(entitytypes[i].origin, entitytypes[i].origin - (30000,0,0),false,undefined);
		 if(trace["fraction"] != 1)  xMin_e  = trace["position"];

		 trace = bulletTrace(entitytypes[i].origin, entitytypes[i].origin + (30000,0,0),false,undefined);
		 if(trace["fraction"] != 1)  xMax_e  = trace["position"];

		 trace = bulletTrace(entitytypes[i].origin, entitytypes[i].origin - (0,30000,0),false,undefined);
		 if(trace["fraction"] != 1)  yMin_e  = trace["position"];

		 trace = bulletTrace(entitytypes[i].origin, entitytypes[i].origin + (0,30000,0),false,undefined);
		 if(trace["fraction"] != 1)  yMax_e  = trace["position"];

		 trace = bulletTrace(entitytypes[i].origin, entitytypes[i].origin - (0,0,30000),false,undefined);
		 if(trace["fraction"] != 1)  zMin_e  = trace["position"];

		 trace = bulletTrace(entitytypes[i].origin, entitytypes[i].origin + (0,0,30000),false,undefined);
		 if(trace["fraction"] != 1)  zMax_e  = trace["position"];		
		
    
		 if (xMin_e[0] < xMin2)   xMin2 = xMin_e[0];
		 if (yMin_e[1] < yMin2)   yMin2 = yMin_e[1];
		 if (zMin_e[2] < zMin2)   zMin2 = zMin_e[2];

		 if (xMax_e[0] > xMax2)   xMax2 = xMax_e[0];
		 if (yMax_e[1] > yMax2)   yMax2 = yMax_e[1];
		 if (zMax_e[2] > zMax2)   zMax2 = zMax_e[2];       

		 wait 0.05;
	}

 // String
 level.back2uo_mapdimo_xMin = xMin2;
 level.back2uo_mapdimo_xMax = xMax2;
 
 // String
 level.back2uo_mapdimo_yMin = yMin2;
 level.back2uo_mapdimo_yMax = yMax2; 
 
 // String
 level.back2uo_mapdimo_zMin = zMin2;
 level.back2uo_mapdimo_zMax = zMax2;
 
 entitytypes = [];
 entitytypes = undefined;
}

///////////////////////////////
// Back2Uo Get Granade Type //
/////////////////////////////
back2uo_getgranade_type(type) 
{
 // String
 grenadetype = "";

 // Abfrage
 if(type == "granade")
 {
  // Abfrage
  if(self.pers["team"] == "allies") 
  {
	 // Switch Funktion
	 switch(game["allies"]) 
   {		
	  case "american":
		 grenadetype = "frag_grenade_american_mp";
	  break;

	  case "british":
		 grenadetype = "frag_grenade_british_mp";
	  break;

	  default:
		 grenadetype = "frag_grenade_russian_mp";
	  break;
	 }
  }
  else
  {		
   grenadetype = "frag_grenade_german_mp";			
  }
 }
 
 if(type == "smoke")
 { 
  // Abfrage
  if(self.pers["team"] == "allies") 
  {
	 // Switch Funktion
	 switch(game["allies"]) 
   {		
	  case "american":
		 grenadetype = "smoke_grenade_american_mp";
	  break;

	  case "british":
		 grenadetype = "smoke_grenade_british_mp";
	  break;

	  default:
		 grenadetype = "smoke_grenade_russian_mp";
	  break;
	 }
  }
  else 
  {		
   grenadetype = "smoke_grenade_german_mp";		
  }
 } 

 // Return
 return grenadetype;
}

////////////////////////////////
// Back2Uo Get Gametype Name //
//////////////////////////////
back2uo_get_gametypename(gt)
{
 // Switch Funktion
 switch(gt)
 {
	case "dm":
	 gtname = &"BACK2UOMOD_GT_DM";
	break;
		
	case "tdm":
	 gtname = &"BACK2UOMOD_GT_TDM";
	break;

	case "sd":
	 gtname = &"BACK2UOMOD_GT_SD";
	break;

	case "hq":
	 gtname = &"BACK2UOMOD_GT_HQ";
	break;

	case "ctf":
	 gtname = &"BACK2UOMOD_GT_CTF";
	break;

	default:
	 gtname = gt;
	break;
 }

 // Return
 return gtname;
}

///////////////////////////
// Back2Uo Get Map Name //
/////////////////////////
back2uo_get_mapname(map)
{
 // Switch Funktion
 switch(map)
 {
	case "mp_farmhouse":
	 mapname = &"BACK2UOMOD_MAP_MP_FARMHOUSE";
	break;

	case "mp_brecourt":
	 mapname = &"BACK2UOMOD_MAP_MP_BRECOURT";
	break;

	case "mp_burgundy":
	 mapname = &"BACK2UOMOD_MAP_MP_BURGUNDY";
	break;
		
	case "mp_trainstation":
	 mapname = &"BACK2UOMOD_MAP_MP_TRAINSTATION";
	break;

	case "mp_carentan":
	 mapname = &"BACK2UOMOD_MAP_MP_CARENTAN";
	break;

  case "mp_decoy":
	 mapname = &"BACK2UOMOD_MAP_MP_DECOY";
	break;
		
	case "mp_leningrad":
	 mapname = &"BACK2UOMOD_MAP_MP_LENINGRAD";
	break;
		
	case "mp_matmata":
	 mapname = &"BACK2UOMOD_MAP_MP_MATMATA";
	break;
		
	case "mp_downtown":
	 mapname = &"BACK2UOMOD_MAP_MP_DOWNTOWN";
	break;
		
	case "mp_dawnville":
	 mapname = &"BACK2UOMOD_MAP_MP_DAWNVILLE";
	break;

	case "mp_railyard":
	 mapname = &"BACK2UOMOD_MAP_MP_RAILYARD";
	break;

	case "mp_toujane":
	 mapname = &"BACK2UOMOD_MAP_MP_TOUJANE";
	break;
		
	case "mp_breakout":
	 mapname = &"BACK2UOMOD_MAP_MP_BREAKOUT";
	break;

	default:
	 mapname = map;
	break;
 }

 // Return
 return mapname;
}

///////////////////////////////////////
// Back2Uo Get Map Rotation Control //
/////////////////////////////////////
back2uo_getmaprotation_control()
{
 // String
 self endon("disconnect");
 level endon("kill_endround");

 // Abfrage
 if(game["back2uo_mapsystem_enable"])
 {
  // Weiterleitung - Random Rotation
  x = back2uo_getmaprotation(true, false, undefined);
  
  // Weiterleitung
  thread back2uo_randommap_rotation(x);
  
  // Weiterleitung Show Next Map Message Draw
  thread back2uo\_back2uo_messages::back2uo_nextmap_messages_draw(x); 
 }
 else
 {
  // Weiterleitung - Current Rotation
  x = back2uo_getmaprotation(false, true, 1);
  
  // Weiterleitung Show Next Map Message Draw
  thread back2uo\_back2uo_messages::back2uo_nextmap_messages_draw(x);  
 }
}

//////////////////////////////////
// Back2Uo Random Map Rotation //
////////////////////////////////
back2uo_randommap_rotation(x)
{
 // Abfrage
 if(!game["back2uo_mapsystem_enable"]) return;
 
 // Abfrage
 if(!isdefined(x)) return;

 // String
 self endon("disconnect"); 
 level endon("kill_endround");
 
 // String
 maps = undefined;
 
 // Abfrage
 if(isdefined(x.maps)) maps = x.maps;
  
 // Abfrage
 if(!isdefined(maps) || !maps.size) return;

 // String
 lastexec = "";
 lastjeep = "";
 lasttank = "";
 lastgt = "";
 newmaprotation = "";
	
 // For Schleife
 for(i = 0; i < maps.size; i++)
 {
	// Abfrage
	if(!isdefined(maps[i]["exec"]) || lastexec == maps[i]["exec"])
	 exec = "";
	else
	{
	 lastexec = maps[i]["exec"];
	 exec = " exec " + maps[i]["exec"];
	}

  // Abfrage
	if(!isdefined(maps[i]["jeep"]) || lastjeep == maps[i]["jeep"])
	 jeep = "";
	else
	{
	 lastjeep = maps[i]["jeep"];
	 jeep = " allow_jeeps " + maps[i]["jeep"];
	}

  // Abfrage
	if(!isdefined(maps[i]["tank"]) || lasttank == maps[i]["tank"])
	 tank = "";
	else
	{
	 lasttank = maps[i]["tank"];
	 tank = " allow_tanks " + maps[i]["tank"];	
	}

  // Abfrage
	if(!isdefined(maps[i]["gametype"]) || lastgt == maps[i]["gametype"])
	 gametype = "";
	else
	{
	 lastgt = maps[i]["gametype"];
	 gametype = " gametype " + maps[i]["gametype"];	
	}
		
  // String	
	temp = exec + jeep + tank + gametype + " map " + maps[i]["map"];
			
  // Abfrage      
  if(int(newmaprotation.size + temp.size) > 975)
  {
	 iprintlnbold("Maprotation: ^1Limiting sv_maprotation to avoid server crash! String1 size:" + newmaprotation.size + " String2 size:" + temp.size);
	 break;
	}
	 
	// String
	newmaprotation += temp;
 }

 // String
 setCvar("sv_maprotationcurrent", newmaprotation);
 setCvar("back2uo_random_maprotation", "2");
}

///////////////////////////////
// Back2Uo Get Map Rotation //
/////////////////////////////
back2uo_getmaprotation(random, current, number)
{
 // String
 self endon("disconnect"); 
 level endon("kill_endround");

 // String
 maprot = "";

 // Abfrage
 if(!isdefined(number)) number = 0;

 // Abfrage
 if(current) maprot = strip(getcvar("sv_maprotationcurrent"));

 // Abfrage
 if(maprot == "") maprot = strip(getcvar("sv_maprotation"));	

 // Abfrage
 if(maprot == "") return undefined;
	
 // String
 j=0;
 temparr2[j] = "";
 
 // For Schleife	
 for(i=0; i < maprot.size; i++)
 {
  // Abfrage
	if(maprot[i] == " ")
	{
   j++;
	 temparr2[j] = "";
	}
	else
	 temparr2[j] += maprot[i];
 }

 // String
 temparr = [];
 
 // For Schleife
 for(i=0;i<temparr2.size;i++)
 {
  // String
	element = strip(temparr2[i]);
	
	// Abfrage
	if(element != "")
	{
	 temparr[temparr.size] = element;
	}
 }

 // String
 x = spawn("script_origin",(0,0,0));
 x.maps = [];
 lastexec = undefined;
 lastjeep = undefined;
 lasttank = undefined;
 lastgt = level.back2uo_gametype;
 
 // For Schleife
 for(i=0;i<temparr.size;)
 {
  // Switch Funktion
	switch(temparr[i])
	{
	 case "allow_jeeps":
		if(isdefined(temparr[i+1]))
		 lastjeep = temparr[i+1];
		 i += 2;
	 break;

	 case "allow_tanks":
		if(isdefined(temparr[i+1]))
		 lasttank = temparr[i+1];
		 i += 2;
	 break;
	
	 case "exec":
		if(isdefined(temparr[i+1]))
		 lastexec = temparr[i+1];
		 i += 2;
	 break;

	 case "gametype":
		if(isdefined(temparr[i+1]))
		 lastgt = temparr[i+1];
		 i += 2;
	 break;

	 case "map":
		if(isdefined(temparr[i+1]))
		{
		 x.maps[x.maps.size]["exec"]		= lastexec;
		 x.maps[x.maps.size-1]["jeep"]	= lastjeep;
		 x.maps[x.maps.size-1]["tank"]	= lasttank;
		 x.maps[x.maps.size-1]["gametype"]	= lastgt;
		 x.maps[x.maps.size-1]["map"]	= temparr[i+1];
		}
		
		// Abfrage
		if(!random)
		{
		 lastexec = undefined;
		 lastjeep = undefined;
		 lasttank = undefined;
		 lastgt = undefined;
		}

    // String
		i += 2;
	 break;

	 default:
		iprintlnbold("ERROR IN MAPROTATION!!! Will try to fix.");
	
	  // Abfrage
		if(isGametype(temparr[i]))
		 lastgt = temparr[i];
		else if(isConfig(temparr[i]))
		 lastexec = temparr[i];
		else
		{
		 x.maps[x.maps.size]["exec"]		= lastexec;
		 x.maps[x.maps.size-1]["jeep"]	= lastjeep;
		 x.maps[x.maps.size-1]["tank"]	= lasttank;
		 x.maps[x.maps.size-1]["gametype"]	= lastgt;
		 x.maps[x.maps.size-1]["map"]	= temparr[i];
	
		 // Abfrage
		 if(!random)
		 {
		  lastexec = undefined;
			lastjeep = undefined;
			lasttank = undefined;
			lastgt = undefined;
		 }
		}
			
    // String		
		i += 1;
	 break;
	}
	
	// Abfrage
	if(number && x.maps.size >= number) break;
 }

 // Abfrage
 if(random)
 {
	// For Schleife
	for(k = 0; k < 20; k++)
	{
	 // For Schleife
	 for(i = 0; i < x.maps.size; i++)
	 {
	  // String
		j = randomInt(x.maps.size);
		element = x.maps[i];
		x.maps[i] = x.maps[j];
		x.maps[j] = element;
	 }
  }
 }

 // Return
 return x;
}

isConfig(cfg)
{
 // String
 temparr = explode(cfg,".");
 
 // Abfrage
 if(temparr.size == 2 && temparr[1] == "cfg")
	return true;
 else
	return false;
}

isGametype(gt)
{
 // Switch Funktion
 switch(gt)
 {
	case "dm":
	case "tdm":
	case "sd":
	case "hq":
	case "ctf":
   return true;
  default:
	 return false;
 }
}

explode(s,delimiter)
{
 // String
 j=0;
 temparr[j] = "";	

 // For Schleife
 for(i=0;i<s.size;i++)
 {
  // Abfrage
	if(s[i]==delimiter)
	{
	 j++;
	 temparr[j] = "";
	}
	else
	 temparr[j] += s[i];
 }
 
 // Return
 return temparr;
}

strip(s)
{
 // Abfrage
 if(s=="") return "";

 // String
 s2="";
 s3="";
 i=0;
 
 // While Schleife
 while(i<s.size && s[i]==" ")
	
 // String
 i++;

 // Abfrage
 if(i==s.size) return "";

 // For Schleife	
 for(;i<s.size;i++)
 {
	s2 += s[i];
 }

 // String
 i=s2.size-1;
 
 // While Schleife
 while(s2[i]==" " && i>0)
 
 // String
 i--;

 // For Schleife	
 for(j=0;j<=i;j++)
 {
  s3 += s2[j];
 }
	
 // Return	
 return s3;
}

splitArray( str, sep, quote, skipEmpty )
{
 // Abfrage
 if(!isdefined(str) || str == "") return ( [] );

 // Abfrage
 if(!isdefined(sep) || sep == "") sep = ";";	// Default separator

 // Abfrage
 if(!isdefined(quote)) quote = "";

 // String
 skipEmpty = isdefined( skipEmpty );
 a = _splitRecur( 0, str, sep, quote, skipEmpty );

 // Return
 return ( a );
}

_splitRecur( iter, str, sep, quote, skipEmpty )
{
 // String
 s = sep[ iter ];
 _a = [];
 _s = "";
 doQuote = false;
 
 // For Schleife
 for(i = 0; i < str.size; i++)
 {
  // String
	ch = str[i];
	
	// Abfrage
	if(ch == quote)
	{
	 // String
	 doQuote = !doQuote;

   // Abfrage
	 if(iter + 1 < sep.size) _s += ch;
	}
	else	
	 // Abfrage
	 if(ch == s && !doQuote )
	 {
	  // Abfrage
		if( _s != "" || !skipEmpty)
		{
		 // String
		 _l = _a.size;
		 
		 // Abfrage
     if(iter + 1 < sep.size)
		 {
		  // String
			_x = _splitRecur( iter + 1, _s,	sep, quote, skipEmpty );

      // Abfrage
			if(_x.size > 0 || !skipEmpty)
			{
			 // String
			 _a[ _l ][ "str" ] = _s;
			 _a[ _l ][ "fields" ] = _x;
			}
		 }
		 else 
      _a[ _l ] = _s;
		}

    // String
		_s = "";
	 }
	 else 
    _s += ch;
 }

 // Abfrage
 if( _s != "")
 {
	// String
  _l = _a.size;

  // Abfrage
	if(iter + 1 < sep.size)
	{
	 // String
	 _x = _splitRecur( iter + 1, _s, sep, quote, skipEmpty);
		
	 // Abfrage
	 if(_x.size > 0 )
	 {
		// String
		_a[ _l ][ "str" ] = _s;
		_a[ _l ][ "fields" ] = _x;
	 }
	}
	else 
   _a[ _l ] = _s;
 }

 // Return
 return ( _a );
}

findStr( find, str, pos )
{
 // Abfrage
 if ( !isdefined( find ) || ( find == "" ) || !isdefined( str ) || !isdefined( pos ) || ( find.size > str.size ) ) return ( -1 );

 // String
 fsize = find.size;
 ssize = str.size;

 // Switch Funktion
 switch ( pos )
 {
	case "start": 
   place = 0 ; 
  break;
	
  case "end":	
   place = ssize - fsize; 
  break;
	
  default:	
   place = 0 ; 
  break;
 }

 // For Schleife
 for ( i = place; i < ssize; i++ )
 {
  // Abfrage
	if ( i + fsize > ssize ) break;			

	// For Schleife
	for ( j = 0; j < fsize; j++ )
	
	 // Abfrage
	 if ( str[ i + j ] != find[ j ] ) break;		

   // Abfrage
	 if ( j >= fsize ) return ( i );

   // Abfrage
	 if ( pos == "start" ) break;	
 }

 // Return
 return ( -1 );
}

/////////////////////////////////
// Back2Uo Calc Shell Postion //
///////////////////////////////
back2uo_calcshellpos(targetPos)
{
 // String
 shellPos = undefined;
 iterations = 0;
	
 // While Schleife
 while(!isdefined (shellPos) && iterations < 5)
 {
  // String
	shellPos = targetPos;
	angle = randomfloat( 360 );
	radius = randomfloat( 360 );
	randomOffset = (cos(angle) * radius, sin(angle) * radius, 0);
	shellPos += randomOffset;
	startOrigin = shellPos + (0, 0, 800);
	endOrigin = shellPos + (0, 0, -2048);

  // Trace
	trace = bulletTrace( startOrigin, endOrigin, true, undefined );
	
  // Abfrage	
  if(trace["fraction"] < 1.0) 
   shellPos = trace["position"];
	else 
   shellPos = undefined;

  // String
	iterations++;
 }

 // Return
 return ( shellPos );
}

///////////////////////////////////
// Back2Uo Player Points System //
/////////////////////////////////
back2uo_playerpoints_system(wert)
{
 // Abfrage
 if(!game["back2uo_playerpoints_enable"]) return;

 // Abfrage
 if(!isdefined(wert)) return;

 // String
 bonus = 0;
 text = "";

 // Switch Funktion
 switch (wert)
 {
  // Case - Bomb Plant
	case "bomb_planted":
	 bonus = level.back2uo_sd_plant_points;
	break;

  // Case - Bomb Defuse
  case "bomb_defused":
	 bonus = level.back2uo_sd_defuse_points;
	break;
 }

 // String
 self.pers["score"] = self.pers["score"] + bonus;
 self.score = self.pers["score"];
}

////////////////////////////////////////////
// Back2Uo Airplane FX - Vector Position //
//////////////////////////////////////////
back2uo_airplane_vectorpos(startpos, angle)
{
 // String
 forwardvector = anglestoforward((0,angle,0));
 backpos = startpos + (back2uo_airplane_vectormulti(forwardvector,-30000));
 frontpos = startpos + (back2uo_airplane_vectormulti(forwardvector,30000));
 fronthit = 0;

 // String - Trace
 trace = bulletTrace(startpos,backpos,false,undefined);

 // Abfrage
 if(trace["fraction"] != 1) start = trace["position"];
 else start = backpos;

 // String - Trace
 trace = bulletTrace(startpos,frontpos,false,undefined);
 
 // Abfrage
 if(trace["fraction"] != 1)
 {
	endpoint = trace["position"];
	font_hit = 1;
 }
 else endpoint = frontpos;

 // String
 startpos = start + (back2uo_airplane_vectormulti(forwardvector,-3000));
 endpoint = endpoint + (back2uo_airplane_vectormulti(forwardvector,3000));
 stenpos[0] = startpos;
 stenpos[1] = endpoint;
 stenpos[10] = fronthit;
 
 // Return
 return stenpos;
}

/////////////////////////////////////////
// Back2Uo Airplane FX - Multi Vector //
///////////////////////////////////////
back2uo_airplane_vectormulti(vec, size)
{
 // String
 x = vec[0] * size;
 y = vec[1] * size;
 z = vec[2] * size;
 vec = (x,y,z);
 
 // Return
 return vec;
}

////////////////////////////////////
// Back2Uo give Points to Player //
//////////////////////////////////
back2uo_givepoints_toplayer(team, points)
{
 // String
 players = getentarray("player", "classname");
	
 // For Schleife
 for(i = 0; i < players.size; i++)
 {
  // String
	player = players[i];

  // Abfrage
	if(isAlive(player) && player.pers["team"] == team)
	{
	 // String
	 player.pers["score"] += points;
	 player.score = player.pers["score"];
	}
 }
}

////////////////////////////////////
// Back2Uo lose Points to Player //
//////////////////////////////////
back2uo_losepoints_ofplayer(points)
{
 // Abfrage
 if(!isdefined(points)) return;

 // String
 self.pers["score"] = self.pers["score"] - points;
 self.score = self.pers["score"];
}

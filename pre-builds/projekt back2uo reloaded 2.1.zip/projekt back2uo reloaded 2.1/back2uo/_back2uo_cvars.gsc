////////////////////////////
// Back2Uo Player Stance //
//////////////////////////
back2uo_player_stance()
{
 // String
 pos_type = "stand";
 
 // Abfrage
 if(isdefined(self.origin))
 {
  pose_crouch = bulletTrace( self.origin + ( 20, 0, 60 ), self.origin + ( -20, 0, 60 ), true, undefined );
  pose_prone = bulletTrace( self.origin + ( 20, 0, 40 ), self.origin + ( -20, 0, 40 ), true, undefined );
   
  // Abfrage    
  if(pose_crouch["fraction"] == 1) pos_type = "crouch";   
  if(pose_prone["fraction"] == 1) pos_type = "prone";
 }
 
 // Return
 return pos_type;
}

////////////////////////////
// Back2Uo Player Origin //
//////////////////////////
back2uo_player_origin()
{
 // Abfrage
 if(!isdefined(self.origin)) return;

 // String
 firstorigin = self.origin;
 wait 1;
 secorigin = self.origin;
 
 // String
 player_origin = distance(firstorigin,secorigin);
 
 // Return
 return player_origin;
}

/////////////////////////////
// Back2Uo Player Message //
///////////////////////////
back2uo_player_message(lstr, wert)
{
 // Abfrage
 if(!isdefined(lstr)) lstr = "";
 if(!isdefined(wert)) wert = "";

 // String
 players = getentarray("player", "classname"); 
 
 // For Schleife
 for(p = 0; p < players.size; p++)
 {
  user = players[p];
  
  user iprintln(lstr, wert);
 }
}

//////////////////////////////////
// Back2Uo Player Message Bold //
////////////////////////////////
back2uo_player_messagebold(lstr, wert)
{
 // Abfrage
 if(!isdefined(lstr)) lstr = "";
 if(!isdefined(wert)) wert = "";

 // String
 players = getentarray("player", "classname"); 
 
 // For Schleife
 for(p = 0; p < players.size; p++)
 {
  user = players[p];
  
  user iprintlnbold(lstr, wert);
 }
}

///////////////////////////////////////
// Back2Uo Settting Game Auswertung //
/////////////////////////////////////
back2uo_setconfig(wert, wertdefault, min, max, ui)
{
 // String
 wert2 = wertdefault;
 if(!isDefined(game["back2uo_enable"])) game["back2uo_enable"] = 1; 

 // Abfrage
 if(getcvar(wert) == "")	
 {
  setCvar(wert, wertdefault);
	wert2 = getCvarInt(wert);
 }
 else
 {
  if(!(game["back2uo_enable"]))
  {	
	 setCvar(wert, wertdefault);
	 wert2 = getCvarInt(wert);
  }else{ 
   wert2 = getcvarfloat(wert);
  }
 }

 // Abfrage
 if(min != 0 && wert2 < min)
	wert2 = min;

 // Abfrage
 if(max != 0 && wert2 > max)
	wert2 = max;

 // Return
 return wert2;
}

///////////////////////////////////////
// Back2Uo Settting Game Auswertung //
/////////////////////////////////////
back2uo_setui_var(name, wert)
{
 // Abfrage
 if(!isDefined(name) || !isDefined(wert)) return;

 // Abfrage 
 if(getCvar(name) == "") 
  makeCvarServerInfo(name, wert);

 // Abfrage
 if(getCvarInt(name) != wert) setCvar(name, wert);
}

///////////////////////////////////
// Back2Uo Map Daten Auswertung //
/////////////////////////////////
back2uo_getcvardef(varname, vardefault, min, max, type)
{
	mapname = getcvar("mapname");		// "mp_dawnville", "mp_rocket", etc.
	gametype = getcvar("g_gametype");	// "tdm", "bel", etc.
	multigtmap = gametype + "_" + mapname;

	tempvar = varname + "_" + gametype;	// i.e., scr_teambalance becomes scr_teambalance_tdm
	if(getcvar(tempvar) != "") 		// if the gametype override is being used
		varname = tempvar; 		// use the gametype override instead of the standard variable

	tempvar = varname + "_" + mapname;	// i.e., scr_teambalance becomes scr_teambalance_mp_dawnville
	if(getcvar(tempvar) != "")		// if the map override is being used
		varname = tempvar;		// use the map override instead of the standard variable

	tempvar = varname + "_" + multigtmap;	// i.e., scr_teambalance becomes scr_teambalance_mp_dawnville_tdm
	if(getcvar(tempvar) != "")		// if the map override is being used
		varname = tempvar;		// use the map override instead of the standard variable

 // Switch Funktion
 switch(type)
 {
  // Case - Int
	case "int":
	 if(getcvar(varname) == "")		
		definition = vardefault;	
	 else
		definition = getcvarint(varname);
	break;
	
	// Case - Float
	case "float":
	 if(getcvar(varname) == "")	
		definition = vardefault;	// set the default
	 else
		definition = getcvarfloat(varname);
	 break;
	 
	// Case - String 
	case "string":
	default:
	 if(getcvar(varname) == "")		
		definition = vardefault;	
	 else
		definition = getcvar(varname);
	break;
 }

 // Abfrage
 if((type == "int" || type == "float") && min != 0 && definition < min)
	definition = min;

 // Abfrage
 if((type == "int" || type == "float") && max != 0 && definition > max)
	definition = max;

 return definition;
}

////////////////////////
// Back2Uo Get Array //
//////////////////////
back2uo_getarray(name) 
{
 // String
 nr = 0;
 msg = name + "_"  + nr;
 
 if(getcvar(msg) != "")  
 {
  wert[nr] = getcvar(msg);
 }
 else 
 {                  
	return;
 }

 // While Schleife              
 while(1) 
 {
  // String
  nr++;
	msg = name + "_" + nr;
  
  // Abfrage          
	if(getcvar(msg) != "")	
  {
   // String
	 wert[nr] = getcvar(msg);		
	}
	else 
  {
   break;
  }                      
 }
    
 // Return    
 return wert;
} 

//////////////////////////
// Back2uo Posi Target //
////////////////////////
back2uo_getpositarget()
{
 // String 
 geteyeextra = back2uo_geteyeoffset();
 startOrigin = self getEye() + geteyeextra;
 forward = anglesToForward( self getplayerangles() );
 forward = back2uo_vecscale( forward, 100000 );
 endOrigin = startOrigin + forward;
	
 // String
 trace = bulletTrace( startOrigin, endOrigin, false, self );

 // Abfrage
 if ( trace["fraction"] == 1.0 || trace["surfacetype"] == "default")
	return ( undefined );
 else
	return ( trace["position"] );
}

/////////////////////////
// Back2uo Eye Offset //
///////////////////////
back2uo_geteyeoffset() 
{	
 // String
 offset = (0,0,18);

 // String
 player_stance = back2uo_player_stance();

 // Abfrage
 if(player_stance == "crouch") offset = (0,0,2);
 if(player_stance == "prone") offset = (0,0,-27);
 
 return offset;
}

////////////////////////
// Back2uo Vec Scale //
//////////////////////
back2uo_vecscale(vec, scale)
{
 // String
 vec = (vec[0] * scale, vec[1] * scale, vec[2] * scale);
 
 // Return
 return vec;
}

//////////////////////////////////
// Back2Uo - Weather FX Random //
////////////////////////////////
back2uo_warfx_random()
{
 // Abfrage
 if(!game["back2uo_warfx_enable"]) return;

 // For Schleife
 for(;;)
 {
  // Abfrage
  if(int(randomInt(50) + randomInt(50)) < level.back2uo_warfx_random)
  {  
   level.back2uo_mortarfx_allow = true;
  }
  
  // Warteschleife
  wait (10 + randomint(10));
  
  // Abfrage
  if(int(randomInt(50) + randomInt(50)) < 100)
  {  
   level.back2uo_airplanefx_allow = true;
  } 
  
  // Warteschleife
  wait (30 + randomint(30));
 }
}

///////////////////////////////////
// Back2uo Mortars Fx - Control //
/////////////////////////////////
back2uo_mortarfx_control()
{
 // Abfrage
 if(!game["back2uo_warfx_enable"] || !game["back2uo_mortarfx_enable"]) return;

 // Abfrage
 if(!isdefined(level.back2uo_mortarfx_allow)) level.back2uo_mortarfx_allow = false;

 // For Schleife
 for(;;)
 {
  // Abfrage
  if(level.back2uo_mortarfx_allow)
  {
   // Weiterleitung
   thread back2uo_mortarfx_play();
   
   // String
   level.back2uo_mortarfx_allow = false;
  }
 
  // Warteschleife
  wait 0.1;
 }
}

////////////////////////////////
// Back2uo Mortars Fx - Play //
//////////////////////////////
back2uo_mortarfx_play()
{
 // Abfrage
 if(!game["back2uo_mortarfx_enable"]) return;

 // Weiterleitung
 thread back2uo_mortar_sound();
 
 // String
 wait randomfloat(4) + 0.5;
 mortarcount = 0;
	
 // String
 if(level.back2uo_mortar_random)
 {
	// String
	level.back2uo_mortar_count2 = int(5 + randomint(15));
 }
 else
 {
  // String
  level.back2uo_mortar_count2 = level.back2uo_mortar_count;
 } 

 // While Schleife
 while(mortarcount < level.back2uo_mortar_count2)
 {
	thread back2uo_mortar_draw();
	mortarcount++;
	wait 0.6;
 }
}

////////////////////////////////
// Back2uo Mortars Fx - Draw //
//////////////////////////////
back2uo_mortar_draw()
{
 // Abfrage
 if(!game["back2uo_mortarfx_enable"]) return;
 
 // String - Zufalls Position
 if(!isdefined(level.back2uo_playerdimo_xMin) || !isdefined(level.back2uo_playerdimo_yMin) || !isdefined(level.back2uo_playerdimo_zMin)) return;
 x = level.back2uo_playerdimo_xMin + randomint(level.back2uo_playerdimo_breite);
 y = level.back2uo_playerdimo_yMin + randomint(level.back2uo_playerdimo_laenge);
 z = level.back2uo_playerdimo_zMin + 144;		

 // String - ( Start | End ) Position
 startposition = (x, y, z + 400);
 endposition = back2uo\_back2uo_tools::back2uo_calcshellpos(startposition);

 // String - Mortar Draw Model
 mortar = spawn("script_model", startposition);
 mortar setModel("xmodel/prop_mortar_ammunition");
 mortar.origin = startposition;
 mortar.angles = (90, 0, 0);
 mortar hide();
  
 // String - Trace
 trace = bulletTrace((x, y, z), (x, y, z), false, undefined);
 
 // String 
 mortarfx = "dirt";

 // Switch - Funktion
 switch(trace["surfacetype"])
 {
	case "beach":
	case "sand":
	 mortarfx = "beach";
	break;

  case "asphalt":
	case "metal":
	 mortarfx = "concrete";
	break;

	case "mud":
	case "dirt":
	case "grass":
	 mortarfx = "dirt";
	break;

	case "snow":
	 mortarfx = "snow";
	break;

	case "wood":
	 mortarfx = "wood";
	break;

	case "water":
	 mortarfx = "water";
	break;
 }

 // Warteschleife 0.05 Sekunden
 wait 0.05;

 mortar show();

 // String - Play Mortar Fall Sound 
 soundfx_moerfall[0] = "moerser_fallincome1";
 soundfx_moerfall[1] = "moerser_fallincome2";
 soundfx_moerfall[2] = "moerser_fallincome3";
 
 // String - Random Init
 moerfall_efx = randomInt(soundfx_moerfall.size);

 // String - Sound Play
 mortar playsound(soundfx_moerfall[moerfall_efx]); 
 
 // String
 falltime = 0.8;
 mortar moveto(endposition, falltime);
 
 // Warteschleife
 wait falltime;

 // String - Draw Mortar FX 
 playfx(level.back2uo_effect["mortar_" + mortarfx], endposition);

 // String - Play Mortar Explosion Sound 
 soundfx_moerexplo[0] = "moerser_explod1";
 soundfx_moerexplo[1] = "moerser_explod2";
 soundfx_moerexplo[2] = "moerser_explod3";
 
 // String - Random Init
 moerexplo_efx = randomInt(soundfx_moerexplo.size); 
 
 // String - Play Sound
 mortar playsound(soundfx_moerexplo[moerexplo_efx]);

 // String - Mortar Hide
 mortar hide();

 // String - Artillery Damage
 if(level.back2uo_mortar_damage)
 { 
  radiusDamage(endposition + (0,0,12), level.back2uo_mortar_radius, level.back2uo_mortar_strength, 0);
 }

 // Abfrage
 if(level.back2uo_mortar_quake)
 {
  // String
	peqs = randomInt(100);
	strength = 0.3;
	length = 1 + 3*peqs/100;;
	range = 400 + randomint(200);
	earthquake(strength, length, endposition, range);
 }
 
 // String - Mortar Delete
 mortar delete(); 
}

/////////////////////////////////
// Back2uo Mortars Fx - Sound //
///////////////////////////////
back2uo_mortar_sound()
{
 // Abfrage
 if(!game["back2uo_mortarfx_enable"]) return;
 
 // Abfrage
 if(!level.back2uo_mortar_alert) return;

 // String
 self endon("disconnect");
 nat="";

 // Abfrage
 if(isdefined(self.origin) && self.pers["team"] == "allies")
 {
  // Switch - Funktion
	switch(game["allies"])
	{
	 case "american":
		nat = "US_";
	 break;
					
	 case "british":
		nat = "UK_";
	 break;
						
	 case "russian":
		nat = "RU_";
	 break;
	}
 }
 else if(isdefined(self.origin) && self.pers["team"] == "axis")
 {
  // Switch - Funktion
	switch(game["axis"])
	{
	 case "german":
		nat = "GE_";
	 break;
  }
 }
 else
 {
  nat = "GE_";
 }

 // String
 pc = randomInt(100);
 num = 0;
	
 // Abfrage
 if(pc < 25) num = 0;
 else if(pc >=25 < 50) num = 1;
 else if(pc >=50 < 75) num = 2;
 else if(pc > 75) num = 3;

 // String - Play Sound
 alias = nat + num + "_inform_incoming_mortar";
 
 // Weiterleitung
 level thread back2uo\_back2uo_sounds::back2uo_soundonplayers(alias);
}

////////////////////////////////////
// Back2uo Airplane Fx - Control //
//////////////////////////////////
back2uo_airplanefx_control()
{
 // Abfrage
 if(!game["back2uo_warfx_enable"] || !game["back2uo_airplanesfx_enable"]) return;

 // Abfrage
 if(!isdefined(level.back2uo_airplanefx_allow)) level.back2uo_airplanefx_allow = false;

 // For Schleife
 for(;;)
 {
  // Abfrage
  if(level.back2uo_airplanefx_allow)
  {
   // Weiterleitung
   thread back2uo_airplanefx_play();
   
   // String
   level.back2uo_airplanefx_allow = false;
  }
 
  // Warteschleife
  wait 0.1;
 }
}

/////////////////////////////////
// Back2Uo Airplane FX - Play //
///////////////////////////////
back2uo_airplanefx_play()
{
 // Abfrage
 if(!game["back2uo_airplanesfx_enable"]) return; 
 
 // String
 map_x = level.back2uo_playerdimo_centerx;
 map_y = level.back2uo_playerdimo_centery;
 map_z = level.back2uo_mapdimo_zMax;	

 // String
 airplane_startpoint = [];
 airplane_endpoint = [];
 airplane_extra = [];
	
 // String
 airplane_angles = randomint(360);
 airplane_type = randomint(1); 
 airplane_wait = 1;
 
 // Weiterleitung - Play Flak Effect
 thread back2uo_flakfx_play(level.back2uo_airplanes_count);   
	
 // For Schleife	
 for(i=0; i < level.back2uo_airplanes_count; i++)
 { 
  // String
  airplane_extra[i] = (0, 0, 0);
 	 
  // Switch Funktion
  switch(i)
  {
   case 0:
    airplane_extra[i] += (0, 0, 0);
    airplane_wait = 2;
   break;
   
   case 1:
    airplane_extra[i] += (-1500, 0, 0);
    airplane_wait = 0;   
   break;
   
   case 2:
    airplane_extra[i] += (1500, 0, 0);
    airplane_wait = 2;   
   break;
   
   case 3:
    airplane_extra[i] += (-3000, 0, 0);
    airplane_wait = 0;   
   break;
   
   case 4:
    airplane_extra[i] += (0, 0, 0);
    airplane_wait = 0;   
   break;
   
   case 5:
    airplane_extra[i] += (3000, 0, 0);
    airplane_wait = 2;   
   break;
   
   case 6:
    airplane_extra[i] += (-3000, 0, 0);
    airplane_wait = 0;   
   break;
   
   case 7:
    airplane_extra[i] += (-1500, 0, 0);
    airplane_wait = 0;   
   break;
   
   case 8:
    airplane_extra[i] += (1500, 0, 0);
    airplane_wait = 0;   
   break;
   
   case 9:
    airplane_extra[i] += (3000, 0, 0);
    airplane_wait = 0;   
   break;                           
  }
  
  // String
  airplane_vectorpos = back2uo\_back2uo_tools::back2uo_airplane_vectorpos((map_x, map_y, map_z) + airplane_extra[i], airplane_angles);   
 	 
	// String
	airplane_startpoint[i] = airplane_vectorpos[0];
	airplane_endpoint[i] = airplane_vectorpos[1];
						
	// Weiterleitung - Airplane Draw
	thread back2uo_airplanes_draw(airplane_angles, airplane_startpoint[i], airplane_endpoint[i], airplane_type);
   
	// Warteschleife
	wait airplane_wait;
 }
}

//////////////////////////////////
// Back2Uo Airplanes FX - Draw //
////////////////////////////////
back2uo_airplanes_draw(airplane_angles, airplane_startpoint, airplane_endpoint, airplane_type)
{
 // Abfrage
 if(airplane_type == 0)
 {
  // String
	airplane_model = "xmodel/vehicle_stuka_flying";
	airplane_sound = "stuka_flying1";
	airplane_speed = 200;
 } 
 else
 {
  // String 
	airplane_model = "xmodel/vehicle_spitfire_flying";
	airplane_sound = "spitfire_flying1";
	airplane_speed = 400;
 }  

 // String - Airplane Draw
 plane = spawn("script_model", airplane_startpoint);
 plane setModel(airplane_model);
 plane.angles = (10, airplane_angles, 0);
 plane hide();

 // String - Airplane Sound 
 plane.sound = spawn("script_model", (0, 0, 0));
 plane.sound.origin = airplane_startpoint;
 plane.sound linkto(plane);
 plane.sound playloopsound(airplane_sound);

 // String - Airplane Move 
 airplane_flytime = back2uo_airplane_flytime(airplane_speed, airplane_startpoint, airplane_endpoint);
 plane show();
 plane moveto(airplane_endpoint, airplane_flytime);
 
 // Warteschleife -  Flytime
 wait airplane_flytime;

 // Abfrage
 if(isdefined(plane.sound))
 {
	plane.sound stopLoopSound();
	plane.sound delete();
 }

 // Abfrage
 if(isdefined(plane)) plane delete();
}

////////////////////////////////////
// Back2Uo Airplane FX - Flytime //
//////////////////////////////////
back2uo_airplane_flytime(airplane_speed, airplane_startpoint, airplane_endpoint)
{
 // Abfrage
 if(airplane_speed < 1) return 0.1;

 // String
 fly_distance = distance(airplane_startpoint, airplane_endpoint);
 fly_time = (fly_distance / airplane_speed) / 4;

 // Abfrage
 if(fly_time < 0) fly_time = 0.1;

 // Return
 return fly_time;
}

////////////////////////////////
// Back2uo Flak Effekte Play //
//////////////////////////////
back2uo_flakfx_play(aircount)
{
 // Abfrage
 if(!game["back2uo_flakfx_enable"]) return;
 
 // Warteschleife
 wait 2;
 
 // For Schleife
 for(z=0;z<aircount;z++)
 {	 
  // String
  level.back2uo_flakfx_count = int(3 + randomint(2));
 
  // For Schleife
  for(x=0;x<level.back2uo_flakfx_count;x++)
  {		
	 // String - Zufalls Position
	 if(!isdefined(level.back2uo_playerdimo_xMin) || !isdefined(level.back2uo_playerdimo_yMin) || !isdefined(level.back2uo_mapdimo_zMax) ) return;
    xpos = level.back2uo_playerdimo_xMin + randomint(level.back2uo_playerdimo_breite);
	  ypos = level.back2uo_playerdimo_yMin + randomint(level.back2uo_playerdimo_laenge);
	  zpos = level.back2uo_mapdimo_zMax - randomint(200);		 	
   
   // String
   position = ( xpos, ypos, zpos);
 
   // Weiterleitung Flak Sound
   thread back2uo_flakfx_sound(position); 
  
   // Weiterleitung Flak Draw
   thread back2uo_flakfx_draw(position); 

   // Warteschleife 1 Sekunden
   wait 0.6;
  }
  
  // Warteschleife
  wait 2;
 } 
 
 // Return
 return;
}

////////////////////////////////
// Back2uo Flak Effekte Draw //
//////////////////////////////
back2uo_flakfx_draw(position)
{
 // Abfrage
 if(!game["back2uo_flakfx_enable"]) return;

 // String Play Effekte
 playfx(level.back2uo_effect["flak_flash"], position);
 wait 0.25;

 // String Play Effekte 
 playfx(level.back2uo_effect["flak_smoke"], position);
 wait 0.25;

 // String Play Effekte 
 playfx(level.back2uo_effect["flak_dust"], position);
 wait 0.25;
}

/////////////////////////////////
// Back2uo Flak Effekte Sound //
///////////////////////////////
back2uo_flakfx_sound(position)
{
 // Abfrage
 if(!game["back2uo_flakfx_enable"]) return;

 // Weiterleitung
 thread back2uo\_back2uo_sounds::back2uo_soundonplayers("flak_explosion");
}

/////////////////////////////////////
// Back2uo Artillery Fx - Control //
///////////////////////////////////
back2uo_artilleryfx_control()
{
 // Abfrage
 if(!game["back2uo_artilleryfx_enable"]) return;
 
 // String
 self endon("disconnect");  
 
 // Abfrage
 if(!isdefined(self.back2uo_artillery_go)) self.back2uo_artillery_go = false;
 if(self.back2uo_artillery_go) return;
  
 // String 
 self.back2uo_artillery_go = true;
	
 // Abfrage
 if(self.back2uo_artillery_go)
 {
  // String
  self iprintlnbold(&"BACK2UOMOD_ARTILLERY_GO");
   
  // Weiterleitung
  self thread back2uo_artilleryfx_binowaituse();
 }
}

///////////////////////////////////////////
// Back2Uo Binocular Artillery Use Wait //
/////////////////////////////////////////
back2uo_artilleryfx_binowaituse()
{
 // Abfrage
 if(!game["back2uo_artilleryfx_enable"]) return;

 // String
 self endon("binocular_fire");
 self endon("killed_player");
 
 // String
 self.pers["artillery_save"] = true;

 // For Schleife
 for (;;)
 {
  // Warteschleife -  Binocular Enter
	self waittill("binocular_enter");
	
	// Weiterleitung
	self thread back2uo_artilleryfx_binotext_draw();
	
	// Weiterleitung
	self thread back2uo_artilleryfx_binousing();
	
  // Warteschleife
  wait .2;
 }
}

///////////////////////////////////////////
// Back2Uo Binocular Artillery Use Draw //
/////////////////////////////////////////
back2uo_artilleryfx_binotext_draw()
{
 // String
 self endon("binocular_exit");

 // Abfrage
 if(!isdefined(self.back2uo_artuse))
 { 
  // String
  self.back2uo_artuse = newClientHudElem( self );
	self.back2uo_artuse.alignX = "center";
	self.back2uo_artuse.alignY = "top";
	self.back2uo_artuse.fontScale = 1;
	self.back2uo_artuse.x = 320;
	self.back2uo_artuse.y = 425;
	self.back2uo_artuse.alpha = 1;
	self.back2uo_artuse.sort = 5;	
 }
 
 // String
 self.back2uo_artuse setText(&"BACK2UOMOD_ARTILLERY_USE");
 
 // Weiterleitung
 self thread back2uo_artilleryfx_binotext_clearwait(); 
}

/////////////////////////////////////////////////
// Back2Uo Binocular Artillery Use Clear Wait //
///////////////////////////////////////////////
back2uo_artilleryfx_binotext_clearwait()
{
 // String
 self endon("binocular_enter");
 self endon("killed_player");
 self waittill("binocular_exit");
 
 // Warteschleife
 self waittill("binocular_exit");
 
 // Abfrage
 if(isdefined(self.back2uo_artuse)) self.back2uo_artuse destroy();   
}

////////////////////////////////////////////
// Back2Uo Binocular Artillery Use Clear //
//////////////////////////////////////////
back2uo_artilleryfx_binotext_clear2()
{
 // Abfrage
 if(isdefined(self.back2uo_artuse)) self.back2uo_artuse destroy();   
}

////////////////////////////////////////
// Back2Uo Binocular Artillery Using //
//////////////////////////////////////
back2uo_artilleryfx_binousing()
{
 // String
 self endon("disconnect");
 
 // String
 self notify("binocular_exit");
 wait(0.1);
 self endon("binocular_exit");  

 // For Schleife
 for (;;)
 {
  // Abfrage
	if(isPlayer(self) && self useButtonPressed())
	{
   // Weiterleitung 
   self thread back2uo_artilleryfx_fire();
   
   // Return
   return;
  }
  
  // Warteschleife
	wait .2;
 }
}

//////////////////////////////////
// Back2uo Artillery Fx - Fire //
////////////////////////////////
back2uo_artilleryfx_fire()
{  	
 // String
 binopositarget = back2uo\_back2uo_cvars::back2uo_getpositarget();
	 
 // Abfrage
 if(isdefined(binopositarget)) 
 {
  // String
  dangerdist = distance( self.origin, binopositarget );
				
	// Abfrage
	if(isdefined(level.back2uo_artillery_danger) && level.back2uo_artillery_danger != 0 && dangerdist < level.back2uo_artillery_danger)
	{
	 // String
	 self iprintlnbold(&"BACK2UOMOD_ARTILLERY_DANGER");
	}
   
  // Abfrage
  if(isDefined(self.back2uo_artuse)) self.back2uo_artuse destroy();  
  
  // Weiterleitung
  thread back2uo_artilleryfx_play(binopositarget);
   
  // String
  self iprintlnbold(&"BACK2UOMOD_ARTILLERY_FIRING");
  
  // String
  self.pers["artillery_save"] = undefined;
    
  // Return
  return;
 }
 else
 {
  // Weiterleitung
  self thread back2uo_artilleryfx_binowaituse();
 } 
}

//////////////////////////////////
// Back2uo Artillery Fx - Play //
////////////////////////////////
back2uo_artilleryfx_play(binopositarget)
{
 // Abfrage
 if(!game["back2uo_artilleryfx_enable"]) return;
 
 // String
 self endon("disconnect");

 // String - Play Artillery Launch Sound 
 soundfx_artlaun[0] = "artillery_launch1";
 soundfx_artlaun[1] = "artillery_launch2";
 soundfx_artlaun[2] = "artillery_launch3"; 
 
 // String - Random Init
 artlaun_efx = randomInt(soundfx_artlaun.size); 

 // String - Play Sound
 self thread back2uo\_back2uo_sounds::back2uo_soundonplayers(soundfx_artlaun[artlaun_efx]);
 
 // Warteschleife - Random
 wait (4 + randomint(3));
 
 // Weiterleitung
 thread back2uo_artillery_sound();

 // String
 artillerycount = 0;
	
 // String
 if(level.back2uo_artillery_random)
 {
	// String
	level.back2uo_artillery_count2 = int(10 + randomint(10));
 }
 else
 {
  // String
  level.back2uo_artillery_count2 = level.back2uo_artillery_count;
 } 

 // While Schleife
 while(artillerycount < level.back2uo_artillery_count2)
 {
	// Weiterleitung	
	thread back2uo_artillery_draw(binopositarget);
	 
	// String
	artillerycount++;
	 
	// Warteschleife
	wait 0.8;
 }
 
 // String
 self.back2uo_artillery_go = false; 
}

//////////////////////////////////
// Back2uo Artillery Fx - Draw //
////////////////////////////////
back2uo_artillery_draw(binopositarget)
{
 // Abfrage
 if(!game["back2uo_artilleryfx_enable"]) return;
 
 // String
 self endon("disconnect"); 
 
 // Abfrage
 if(isdefined(level.back2uo_mapdimo_zMax))
 {
  flyon = (0, int(randomint(500) + 400), level.back2uo_mapdimo_zMax);
 } 
 else
 {
  flyon = (0, int(randomint(500) + 400), 800);
 } 
 
 // String - ( Start | End ) Position
 startposition = binopositarget + flyon;
 endposition = back2uo\_back2uo_tools::back2uo_calcshellpos(binopositarget);

 // String - Mortar Draw Model
 artillery = spawn("script_model", startposition);
 artillery setModel("xmodel/vehicle_halftrack_rockets_shell_d");
 artillery.origin = startposition;
 artillery.angles = vectortoangles(vectornormalize((endposition) - startposition));;
 artillery hide();
  
 // String - Trace
 trace = bulletTrace(startposition, endposition, false, self);
 
 // String 
 artilleryfx = "dirt";

 // Switch - Funktion
 switch(trace["surfacetype"])
 {
	case "beach":
	case "sand":
	 artilleryfx = "beach";
	break;

  case "asphalt":
	case "metal":
	 artilleryfx = "concrete";
	break;

	case "mud":
	case "dirt":
	case "grass":
	 artilleryfx = "dirt";
	break;

	case "snow":
	 artilleryfx = "snow";
	break;

	case "wood":
	 artilleryfx = "wood";
	break;

	case "water":
	 artilleryfx = "water";
	break;
 }

 // Warteschleife 0.05 Sekunden
 wait 0.05;

 artillery show();
 
 // String - Play Artillery Fall Sound 
 soundfx_artincom[0] = "artillery_fallincome1";
 soundfx_artincom[1] = "artillery_fallincome2";
 soundfx_artincom[2] = "artillery_fallincome3";
 
 // String - Random Init
 artincom_efx = randomInt(soundfx_artincom.size);
 
 // String - Play Sound 
 artillery playsound(soundfx_artincom[artincom_efx]); 

 // String
 falltime = 0.8;
 artillery moveto(endposition, falltime);

 // Warteschleife
 wait falltime;

 // String - Draw artillery FX 
 playfx(level.back2uo_effect["artillery_" + artilleryfx], endposition);
 
 // String - Play Artillery Explode Sound 
 soundfx_artexplo[0] = "artillery_explod1";
 soundfx_artexplo[1] = "artillery_explod2";
 soundfx_artexplo[2] = "artillery_explod3";
 
 // String - Random Init
 artexplo_efx = randomInt(soundfx_artexplo.size); 
 
 // String - Play Sound
 artillery playsound(soundfx_artexplo[artexplo_efx]);

 // String - Artillery Hide
 artillery hide();
 
 // Weiterleitung
 thread back2uo_artillery_damage(endposition, self);

 // String
 peqs = randomInt(100);
 strength = 0.5;
 length = 1 + 3*peqs/100;;
 range = 600 + randomint(200);
 earthquake(strength, length, endposition, range);
 
 // String - Mortar Delete
 artillery delete();
}

////////////////////////////////////
// Back2uo Artillery Fx - Damage //
//////////////////////////////////
back2uo_artillery_damage(endposition, attacker)
{
 // String
 players = getEntArray("player", "classname");
 
 // For Schleife
 for(i=0; i<players.size; i++)
 {
  // String
	player = players[i];
  dist = distance( player.origin, endposition);
  damage = 0;
				
  // Abfrage
	if(dist <= 200)
	{
	 // String
	 player finishPlayerDamage(player, attacker, 100, 0, "MOD_ARTILLERY", "binoculars_mp", undefined, undefined, "none", player.psOffsetTime);
	 player thread maps\mp\gametypes\_damagefeedback::updateDamageFeedback();
	 player thread back2uo_artillery_shellshockOnDamage(100);
	 player playrumble("damage_heavy");
	}
	else if(dist > 200 && dist <= 400) 
	{
   // String
	 damage = 70;

   // Abfrage
	 if(dist > 250 && dist <= 300) damage = 50;

   // Abfrage
	 if(dist > 300 && dist <= 350) damage = 25;

   // String
	 dist = dist -200; 
   damage = 100 - (dist/2); 

   // String
	 player finishPlayerDamage(player, attacker, int(Damage), 0, "MOD_ARTILLERY", "binoculars_mp", undefined, undefined, "none", player.psOffsetTime);
   player thread maps\mp\gametypes\_damagefeedback::updateDamageFeedback();
	 player thread back2uo_artillery_shellshockOnDamage(damage);
	 player playrumble("damage_heavy");
	}
 }
}

////////////////////////////////////////
// Back2uo Artillery Fx - Shellshock //
//////////////////////////////////////
back2uo_artillery_shellshockOnDamage(damage)
{
 // String
 time = 0;
	
 // Abfrage	
 if(damage >= 90)
	time = 4;
 else if(damage >= 50)
	time = 3;
 else if(damage >= 25)
	time = 2;
 else if(damage > 10)
	time = 1;
		
 // Abfrage	
 if(time) self shellshock("default", time);
}

///////////////////////////////////
// Back2uo Artillery Fx - Sound //
/////////////////////////////////
back2uo_artillery_sound()
{
 // Abfrage
 if(!game["back2uo_artilleryfx_enable"]) return;
 
 // Abfrage
 if(!level.back2uo_artillery_alert) return;

 // String
 self endon("disconnect");

 // String
 nat="";

 // Abfrage
 if(isdefined(self.origin) && self.pers["team"] == "allies")
 {
  // Switch - Funktion
	switch(game["allies"])
	{
	 case "american":
		nat = "GE_";
	 break;
					
	 case "british":
		nat = "GE_";
	 break;
						
	 case "russian":
		nat = "GE_";
	 break;
	}
 }
 else if(isdefined(self.origin) && self.pers["team"] == "axis")
 {
  // Switch - Funktion
	switch(game["axis"])
	{
	 case "german":
		nat = "GE_";
	 break;
  }
 }
 else
 {
  nat = "GE_";
 }

 // String
 pc = randomInt(100);
 num = 0;
	
 // Abfrage
 if(pc < 25) num = 0;
 else if(pc >=25 < 50) num = 1;
 else if(pc >=50 < 75) num = 2;
 else if(pc > 75) num = 3;

 // String - Play Sound
 alias = nat + num + "_inform_incoming_artillery";
 
 // Weiterleitung
 thread back2uo\_back2uo_sounds::back2uo_soundonplayers(alias); 
}

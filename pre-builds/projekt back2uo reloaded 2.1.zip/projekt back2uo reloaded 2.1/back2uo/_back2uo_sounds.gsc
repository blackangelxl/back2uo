//////////////////////////////
// Back2Uo Pain Sound Play //
////////////////////////////
back2uo_painsound_play()
{
 // Abfrage
 if(!game["back2uo_painsound_enable"]) return;

 // Abfrage
 if(level.back2uo_painsound_random > 0 && int(randomInt(50) + randomInt(50)) > level.back2uo_painsound_random) return;
 
 // Weiterleitung - Pain Sound
 self thread back2uo_soundonplayer("generic_pain", "pain");
}

///////////////////////////////
// Back2Uo Death Sound Play //
/////////////////////////////
back2uo_deathsound_play()
{
 // Abfrage
 if(!game["back2uo_deathsound_enable"]) return;

 // Abfrage
 if(level.back2uo_deathsound_random > 0 && int(randomInt(50) + randomInt(50)) > level.back2uo_deathsound_random) return;
 
 // Weiterleitung - Death Sound
 self thread back2uo_soundonplayer("generic_death", "death");
}

/////////////////////////////
// Back2uo Sound Ambiente //
///////////////////////////
back2uo_soundambiente(sound)
{	
 // String
 self endon("disconnect");
 self notify ("weather_sound");
 self endon ("weather_sound"); 
 
 // Abfrage
 if(isdefined(self) && isdefined(sound)) 
  self playlocalsound(sound);	
}

//////////////////////////////
// Back2uo Sound on Player //
////////////////////////////
back2uo_soundonplayer(sound, special)
{	
 if(isdefined(self.origin))
 {
  if(!isdefined(special)) 
  {
   self playSound(sound);
  }
  else
  {
	 if(special == "death" || special == "pain")
	 {
	  if(self.pers["team"] == "allies") 
    {
     self playsound(sound+"_" + game["allies"] + "_" + randomInt(level.back2uo_voices[game["allies"]]));
    }
	  else 
    {
     self playsound(sound+"_german_" + randomInt(level.back2uo_voices["german"]));
    }
	 }
  }
 }
}

////////////////////////////////
// Back2uo Sounds on Players //
//////////////////////////////
back2uo_soundonplayers(sound, team)
{
 players = getentarray("player", "classname");

 if(isdefined(team))
 {
	for(i = 0; i < players.size; i++)
	{
	 if((isdefined(players[i].pers["team"])) && (players[i].pers["team"] == team))
		players[i] playLocalSound(sound);
	}
 }
 else
 {
	for(i = 0; i < players.size; i++)
	 players[i] playLocalSound(sound);
 }
}

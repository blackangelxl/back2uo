////////////////////////////////////
// Back2Uo Spawn Protector Start //
//////////////////////////////////
back2uo_antiplay_spawn_start()
{
 // Abfrage
 if(!game["back2uo_antiplay_sp_enable"]) return;
 
 // String
 self endon("disconnect"); 
 self notify("spawned");
 
 // String
 self.back2uo_spawntime = 0;
 radius = 50;
 
 // String
 //self iprintln(&"BACK2UOMOD_SPAWN_ENABLE_MSG");
 
 // String
 self.back2uo_antiplay_sp_run = true;
 
 // For Schleife
 for(self.back2uo_spawntime=0; self.back2uo_spawntime < level.back2uo_antiplay_sp_time; self.back2uo_spawntime++)
 {
  // String
  self_org = back2uo\_back2uo_cvars::back2uo_player_origin();
  
  // Weiterleitung
  self back2uo\_back2uo_hudfx::back2uo_healthbar_spawn_prot(self.back2uo_spawntime);
 
  // Abfrage
  if(isdefined(self_org) && self_org > radius || self attackButtonPressed() || self meleeButtonPressed() || self useButtonPressed())
  {
   // Weiterleitung
   self back2uo\_back2uo_hudfx::back2uo_healthbar_spawn_prot(self.back2uo_spawntime, "1");
  
   // String
   self iprintln(&"BACK2UOMOD_SPAWN_DISABLED_MSG");
 
   // String
   self.back2uo_antiplay_sp_run = false;
   
   // Return
   return;
  }
 }
    
 // Weiterleitung
 self back2uo\_back2uo_hudfx::back2uo_healthbar_spawn_prot(self.back2uo_spawntime, "1");
 
 // String
 //self iprintln(&"BACK2UOMOD_SPAWN_DISABLED_MSG");
 
 // String
 self.back2uo_antiplay_sp_run = false;
}

/////////////////////////////////
// Back2uo AFK Monitor System //
///////////////////////////////
back2uo_antiplay_afk()
{
 // Abfrage
 if(!game["back2uo_antiplay_afk_enable"]) return;

 // String
 self endon("disconnect"); 
 self notify("spawned"); 
 
 // String
 radius = 20;
 self.back2uo_afk_time = 0;
 
 // Kill Threads
 level endon("back2uo_killthreads");
 
 // For Schleife
 for(;;)
 { 
  // Abfrage
  if(isdefined(self) && isPlayer(self) && isAlive(self) && self.pers["team"] != "spectator")
  {	 
   // String	 
   //self iprintln(&"BACK2UOMOD_AFK_TIME", self.back2uo_afk_time);
   
   // String
   posi_type = back2uo\_back2uo_cvars::back2uo_player_stance();
   self_org = back2uo\_back2uo_cvars::back2uo_player_origin();  
  
   // Abfrage
   if(self_org > radius || posi_type == "crouch" || posi_type == "prone" || self attackButtonPressed() || self meleeButtonPressed() || self useButtonPressed())
   {
    // String
	  self.back2uo_afk_time = 0; 
   }
   else if(self_org < radius)
   {
    // String
	  self.back2uo_afk_time++;
   } 
        
   // Abfrage
	 if (self.back2uo_afk_time == level.back2uo_antiplay_afk_limit)
	 {
	  self iprintlnbold(&"BACK2UOMOD_AFK_WARNING_MSG");
	 }
	 else if(self.back2uo_afk_time >= level.back2uo_antiplay_afk_limit + 10)
	 {
	  thisPlayerNum = self getEntityNumber();
	  setcvar("g_switchspec", thisPlayerNum);
	  self iprintlnbold(&"BACK2UOMOD_AFK_SWICHTING_MSG");
	  self.back2uo_afk_time = 0;
   }
  }
  else
  {
   // String
	 self.back2uo_afk_time = 0;   
  }
  
  // Warteschleife
  wait 0.1;
 }
} 

////////////////////////////////////
// Back2Uo Camper Monitor System //
//////////////////////////////////
back2uo_antiplay_camper()
{
 // Abfrage
 if(!game["back2uo_antiplay_cmp_enable"]) return;

 // String
 self endon("disconnect"); 
 self notify("spawned"); 
 
 // String
 radius = level.back2uo_antiplay_cmp_radius;
 self.back2uo_campingtime = 0;
 self.back2uo_antiplay_camper_marked = false;

 // Kill Threads
 level endon("back2uo_killthreads");
 
 // For Schleife 
 for(;;)
 {
  // Abfrage
  if(isdefined(self) && isPlayer(self) && isAlive(self) && self.pers["team"] != "spectator" && !self.back2uo_antiplay_camper_marked)
  {	
   // String
   self_org = back2uo\_back2uo_cvars::back2uo_player_origin();      
   
   // Abfrage
   if(self_org > radius)
   {
    // String
	  self.back2uo_campingtime = 0; 
	  
	  // Warteschleife
	  wait 5;
   }
   else if(self_org < radius)
   {
    // String
	  self.back2uo_campingtime++;
   }  
	 
   // Abfrage
	 if (self.back2uo_campingtime == level.back2uo_antiplay_cmp_timer)
	 {
	  self iprintlnbold(&"BACK2UOMOD_CAMPING_WARNING_MSG");
	 }
	 else if(self.back2uo_campingtime > level.back2uo_antiplay_cmp_timer + 20)
	 {
    // String
	  self iprintlnbold(&"BACK2UOMOD_CAMPING_MARKED_MSG", level.back2uo_antiplay_cmp_objtime);
 
    // Weiterleitung
	  thread back2uo_antiplay_camper_start(); 
	  thread back2uo_antiplay_camper_remove();
	  
	  // String
	  self.back2uo_antiplay_camper_marked = true;
    self.back2uo_campingtime = 0;
    
    // Continue
	  continue;         
	 }
  }
  else
  {
   // String
	 self.back2uo_campingtime = 0; 
  } 
  
  // Warteschleife
  wait 0.1;
 } 
}

///////////////////////////////////
// Back2Uo Camper Monitor Start //
/////////////////////////////////
back2uo_antiplay_camper_start()
{
 // Abfrage
 if(!game["back2uo_antiplay_cmp_enable"]) return;

 // Abfrage
 if(isDefined(self.back2uo_objnum))
 {
  // String
	objective_delete(self.back2uo_objnum);
	self.back2uo_objnum = undefined;
 }

 // String
 self.back2uo_objnum = back2uo_antiplay_camper_obj();
 
 // String
 compass_icon = "";
 compass_team = "";

 // Abfrage
 if(self.pers["team"] == "allies")
 { 
	compass_icon    = "gfx/custom/back2uo_camper_" + game["allies"] + ".tga";          
	compass_team     = "none";
 }
 else if(self.pers["team"] == "axis")
 {          
	compass_icon    = "gfx/custom/back2uo_camper_" + game["axis"] + ".tga";
	compass_team     = "none";
 }

 // String
 objective_add(self.back2uo_objnum, "current", self.origin, compass_icon);
 objective_team(self.back2uo_objnum, compass_team);

 // While Schleife
 while(isdefined(self.back2uo_objnum) && isdefined(self) && self.pers["team"] != "spectator")
 {
  // For Schleife
	for(i=0; i < level.back2uo_antiplay_cmp_objtime; i++)
	{                            
	 // String                          
   objective_icon(self.back2uo_objnum, compass_icon);
	}

  // String
	objective_position(self.back2uo_objnum, self.origin);  
  
  // Warteschleife     
	wait 0.05;
 }
}

////////////////////////////////////
// Back2Uo Camper Monitor Object //
//////////////////////////////////
back2uo_antiplay_camper_obj()
{
 // Abfrage
 if(!isDefined(level.objectives)) level.objectives = 5;

 // String
 level.objectives++;

 // Abfrage
 if(level.objectives > 15) level.objectives = 6;

 // Return
 return level.objectives;
}

////////////////////////////////////
// Back2Uo Camper Monitor Remove //
//////////////////////////////////
back2uo_antiplay_camper_remove()
{
 // String
 self endon("disconnect"); 
 self endon("killed_player");

 // For Schleife 
 for(z=0;z < level.back2uo_antiplay_cmp_objtime; z++)
 {
  // String	 
  //self iprintln(&"BACK2UOMOD_CAMPER_TIME", z);   
 
  // Warteschleife
  wait 1;
 }

 // Abfrage
 if(isdefined(self) && isPlayer(self) && isAlive(self) && self.pers["team"] != "spectator" && isDefined(self.back2uo_objnum))
 {
  // String	 
  self iprintlnbold(&"BACK2UOMOD_CAMPING_SURVIVED_MSG");  
 
  // String
	objective_delete(self.back2uo_objnum);

	// String
	self.back2uo_antiplay_camper_marked = false;
	self.back2uo_objnum = undefined;
 }
}

//////////////////////////////////////
// Back2Uo Camper Monitor Remove 2 //
////////////////////////////////////
back2uo_antiplay_camper_remove2()
{
 // Abfrage
 if(isDefined(self.back2uo_objnum))
 {
  // String
	objective_delete(self.back2uo_objnum);

	// String
	self.back2uo_antiplay_camper_marked = false;
	self.back2uo_objnum = undefined;
 }
}

///////////////////////////////////////////
// Back2uo AFK Monitor Switch Spectator //
/////////////////////////////////////////
back2uo_switchspec()
{
 // String
 level endon("boot");
 self notify("spawned");
 self endon("disconnect");
 
 // String
 setcvar("g_switchspec", "");
	
 // Whilfe Schleife
 while(1)
 {
  // Abfrage
	if(getcvar("g_switchspec") != "")
	{
	 // String
   movePlayerNum = getcvarint("g_switchspec");
	 players = getentarray("player", "classname");
	 
	 // For Schleife
   for(i = 0; i < players.size; i++)
	 {
	  // String
		thisPlayerNum = players[i] getEntityNumber();
				
    // Abfrage   
    if(thisPlayerNum == movePlayerNum) 
		{
		 // String
		 player = players[i];
			
     // Abfrage	
		 if(isAlive(player))
		 {
			player.switching_teams = true;
			player suicide();
		 }

     // String
		 player.pers["team"] = "spectator";
		 player.pers["weapon"] = undefined;
		 player.pers["savedmodel"] = undefined;
		 player.sessionteam = "spectator";
		 player setClientCvar("ui_allow_weaponchange", "0");
		 
		 // String
		 level.back2uo_playername = player.name;

     // Abfrage
     if(getcvar("g_gametype") == "dm")
		 {
		  // Weiterleitung
		  player thread maps\mp\gametypes\dm::spawnSpectator();
		 }
		 else if(getcvar("g_gametype") == "tdm")
		 {
		  // Weiterleitung
		  player thread maps\mp\gametypes\tdm::spawnSpectator();     
     }
     else if(getcvar("g_gametype") == "sd")
		 {
		  // Weiterleitung
		  player thread maps\mp\gametypes\sd::spawnSpectator();     
     }
     else if(getcvar("g_gametype") == "hq")
		 {
		  // Weiterleitung
		  player thread maps\mp\gametypes\hq::spawnSpectator();     
     }
     else if(getcvar("g_gametype") == "ctf")
		 {
		  // Weiterleitung
		  player thread maps\mp\gametypes\ctf::spawnSpectator();     
     }    

     // String
		 self notify("joined_spectators");
		}
	 }
	 
	 // Weiterleitung
   thread back2uo\_back2uo_messages::back2uo_playermsg_spectator(level.back2uo_playername);

   // String
	 setcvar("g_switchspec", "");
	}
	
	// Warteschleife
	wait 0.05;
 }
}

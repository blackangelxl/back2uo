/////////////////////////////////
// Back2Uo Weopon Limitierung //
///////////////////////////////
back2uo_weapon_limitiert()
{ 
 // Abfrage
 if(!game["back2uo_weaponsystem_enable"]) return;
 
 // Pistel Allow
 if(level.back2uo_pistel_allow)
 {
  setCvar("scr_allow_colt", "1");
  makeCvarServerInfo("scr_allow_colt", "1");
  setCvar("scr_allow_webley", "1");
  makeCvarServerInfo("scr_allow_webley", "1");  
  setCvar("scr_allow_luger", "1");
  makeCvarServerInfo("scr_allow_luger", "1");     
  setCvar("scr_allow_TT30", "1");
  makeCvarServerInfo("scr_allow_TT30", "1");  
 }
 else
 {
  setCvar("scr_allow_colt", "0");
  makeCvarServerInfo("scr_allow_colt", "0");
  setCvar("scr_allow_webley", "0");
  makeCvarServerInfo("scr_allow_webley", "0");
  setCvar("scr_allow_luger", "0");
  makeCvarServerInfo("scr_allow_luger", "0");
  setCvar("scr_allow_TT30", "0");
  makeCvarServerInfo("scr_allow_TT30", "0");  
 }
 
 // Panzerschreck Allow
 if(level.back2uo_rocketl_allow)
 {
  setCvar("scr_allow_panzerschreck", "1");
  makeCvarServerInfo("scr_allow_panzerschreck", "1"); 
 }
 else
 {
  setCvar("scr_allow_panzerschreck", "0");
  makeCvarServerInfo("scr_allow_panzerschreck", "0"); 
 }
 
 // G43 Sniper Allow
 if(level.back2uo_g43sniper_allow)
 {
  setCvar("scr_allow_g43sniper", "1");
  makeCvarServerInfo("scr_allow_g43sniper", "1");  
 }
 else
 {
  setCvar("scr_allow_g43sniper", "0");
  makeCvarServerInfo("scr_allow_g43sniper", "0"); 
 } 
 
 // Binocular Ranking Use
 if(level.back2uo_binocular_allow)
 {
  setCvar("scr_allow_binocular", "1");
  makeCvarServerInfo("scr_allow_binocular", "1");  
 }
 else
 {
  setCvar("scr_allow_binocular", "0");
  makeCvarServerInfo("scr_allow_binocular", "0"); 
 }  
}

/////////////////////////////////
// Back2Uo Weopon Optimierung //
///////////////////////////////
back2uo_weapon_optimizer()
{
 // Abfrage
 if(!game["back2uo_weaponsystem_enable"]) return;
 
 //-Melee Strength-// 
 level.back2uo_melee_strength = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_melee_strength", 100, 1, 100, "int");
 
 // String
 level.back2uo_weaponstrength = [];
 
 //-Turret Waffen-//
 level.back2uo_weaponstrength["mg42_bipod_duck_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_mg42_duck", 100, 1, 100, "int");
 level.back2uo_weaponstrength["mg42_bipod_prone_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_mg42_prone", 100, 1, 100, "int");
 level.back2uo_weaponstrength["mg42_bipod_stand_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_mg42_stand", 100, 1, 100, "int");
 level.back2uo_weaponstrength["30cal_stand_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_mg30cal_stand", 100, 1, 100, "int");
 level.back2uo_weaponstrength["30cal_prone_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_mg30cal_prone", 100, 1, 100, "int");

 //-Granaten-//
 level.back2uo_weaponstrength["frag_grenade_american_mp_cookable"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_frag_american", 100, 1, 100, "int");
 level.back2uo_weaponstrength["frag_grenade_british_mp_cookable"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_frag_british", 100, 1, 100, "int");
 level.back2uo_weaponstrength["frag_grenade_german_mp_cookable"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_frag_german", 100, 1, 100, "int");
 level.back2uo_weaponstrength["frag_grenade_russian_mp_cookable"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_frag_russian", 100, 1, 100, "int");
 
 //-Pistolen-//
 level.back2uo_weaponstrength["colt_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_colt", 100, 1, 100, "int");
 level.back2uo_weaponstrength["webley_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_webley", 100, 1, 100, "int");
 level.back2uo_weaponstrength["TT30_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_TT30", 100, 1, 100, "int");
 level.back2uo_weaponstrength["luger_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_luger", 100, 1, 100, "int");
	
 //-Spezial Waffen-//
 level.back2uo_weaponstrength["g43_sniper_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_g43scoped", 100, 1, 100, "int");
 level.back2uo_weaponstrength["rocketlancher_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_rocketlancher", 100, 1, 100, "int");
	
 //-Allgemeine Waffen-//
 level.back2uo_weaponstrength["shotgun_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_shotgun", 100, 1, 100, "int");
 level.back2uo_weaponstrength["thompson_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_thompson", 100, 1, 100, "int");
 level.back2uo_weaponstrength["m1garand_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_m1garand", 100, 1, 100, "int");
 
 //-Deutsche Waffen-//
 level.back2uo_weaponstrength["mp40_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_mp40", 100, 1, 100, "int");
 level.back2uo_weaponstrength["kar98k_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_kar98k", 100, 1, 100, "int");
 level.back2uo_weaponstrength["g43_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_g43", 100, 1, 100, "int");
 level.back2uo_weaponstrength["kar98k_sniper_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstrh_kar98k_sniper", 100, 1, 100, "int");
 level.back2uo_weaponstrength["mp44_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_mp44", 100, 1, 100, "int");
     
 //-Amerikanische Waffen-//
 level.back2uo_weaponstrength["greasegun_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_greasegun", 100, 1, 100, "int");
 level.back2uo_weaponstrength["m1carbine_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_m1carbine", 100, 1, 100, "int");
 level.back2uo_weaponstrength["springfield_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_springfield", 100, 1, 100, "int");
 level.back2uo_weaponstrength["bar_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_bar", 100, 1, 100, "int");

 //-Britische Waffen-//
 level.back2uo_weaponstrength["sten_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_sten", 100, 1, 100, "int");  
 level.back2uo_weaponstrength["enfield_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_enfield", 100, 1, 100, "int");
 level.back2uo_weaponstrength["enfield_scope_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_enfield_sniper", 100, 1, 100, "int");    
 level.back2uo_weaponstrength["bren_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_bren", 100, 1, 100, "int");
    
 //-Russische Waffen-//
 level.back2uo_weaponstrength["pps42_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_pps42", 100, 1, 100, "int");
 level.back2uo_weaponstrength["mosin_nagant_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_mosin_nagant", 100, 1, 100, "int");
 level.back2uo_weaponstrength["svt40_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_svt40", 100, 1, 100, "int");
 level.back2uo_weaponstrength["mosin_nagant_sniper_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_mosin_nagant_sniper", 100, 1, 100, "int");
 level.back2uo_weaponstrength["ppsh_mp"] = back2uo\_back2uo_cvars::back2uo_getcvardef("back2uo_weaponstr_ppsh", 100, 1, 100, "int");
}

/////////////////////////////////////
// Back2Uo - Weather Random Allow //
///////////////////////////////////
back2uo_weather_randomallow()
{
 // Abfrage
 if(!game["back2uo_weatherfx_enable"]) return; 

 // Abfrage
 if(isdefined(game["weather_allow_q"])) return;
  game["weather_allow_q"] = true;

 // Abfrage
 if(randomInt(100) < level.back2uo_weatherfx_random)
 {
  game["weather_allow"] = true;
 }
 else
 {
  game["weather_allow"] = undefined;
 }
}

/////////////////////////////////////////////
// Back2Uo - Weather Fx - Weather Control //
///////////////////////////////////////////
back2uo_weathercontrol()
{
 // Abfrage
 if(!game["back2uo_weatherfx_enable"]) return; 

 // Abfrage
 if(game["german_soldiertype"] == "winterlight" || game["german_soldiertype"] == "winterdark")
 {
  // Abfrage
  if(!game["back2uo_snowfx_enable"] || !isdefined(game["weather_allow"])) return; 
 
  // String
  level.back2uo_weatherart = "snow_";
 }
 else
 {
  // Abfrage    
  if(!game["back2uo_rainfx_enable"] || !isdefined(game["weather_allow"])) return; 
 
  level.back2uo_weatherart = "rain_";
 }
 
 // Weiterleitung - Weather Draw
 thread back2uo_weatherdraw();
 
 // Weiterleitung - Weather Sound
 thread back2uo_weather_sound();
}

//////////////////////////////////////////
// Back2Uo - Weather Fx - Play Weather //
////////////////////////////////////////
back2uo_weatherdraw()
{
 // Abfrage
 if(!game["back2uo_weatherfx_enable"] || !isdefined(game["weather_allow"])) return; 

 // String
 self endon("disconnect");
 
 // Abfrage
 if(game["german_soldiertype"] == "winterlight" || game["german_soldiertype"] == "winterdark")
 {
  // Abfrage
  if(!game["back2uo_snowfx_enable"] || !isdefined(game["weather_allow"])) return; 
 
  // String
  level.back2uo_weatherart = "snow_";
 }
 else
 {
  // Abfrage    
  if(!game["back2uo_rainfx_enable"] || !isdefined(game["weather_allow"])) return; 
 
  level.back2uo_weatherart = "rain_";
 }  
 
 // String
 level.back2uo_effect["drops"] = level.back2uo_effect[level.back2uo_weatherart + 1];      
  
 // While Schleife        
 while(1) 
 { 
  // String - Player Array   
  players = getentarray("player", "classname");       
    
  // Abfrage   
  if(players.size > 0) 
  { 
   // String
   max_nodes = 5; 
   max_nodes_per_player = max_nodes / players.size; 
       
   // For Schleife  
   for(ii=0; ii < max_nodes_per_player; ii++) 
   { 
    // For Schleife      
    for(i=0; i < players.size; i++) 
    { 
     // String              
     player = players[i]; 
     
     // Abfrage                 
     if(isAlive(player)) 
     {                    
      // Abfrage                
      if(isdefined(level.back2uo_effect["drops"])) 
      {
       playfx(level.back2uo_effect["drops"], (player.origin[0], player.origin[1], 800));
      }    
                         
      // Warteschleife
      wait 0.05; 
     }             
    }    
   } 
   
   // Warteschleife
   wait (2.5 / level.back2uo_rainfx_strength) ;             
  } 
  
  // Warteschleife    
  wait 0.05; 
 }     
}

///////////////////////////////////
// Back2Uo - Weather Fx - Sound //
/////////////////////////////////
back2uo_weather_sound()
{
 // Abfrage
 if(!game["back2uo_weatherfx_enable"] || !isdefined(game["weather_allow"])) return; 

 // String
 self endon("disconnect");

 // While Schleife        
 while(1) 
 {   
  // String - Player Array   
  players = getentarray("player", "classname");       
    
  // Abfrage   
  if(players.size > 0) 
  { 
   // For Schleife      
   for(i=0; i < players.size; i++) 
   { 
    // String              
    player = players[i];
   
    // Abfrage
    if(game["german_soldiertype"] == "winterlight" || game["german_soldiertype"] == "winterdark")
    {
     // Abfrage
     if(!game["back2uo_snowfx_enable"]) return;
    
     // String
     player thread back2uo\_back2uo_sounds::back2uo_soundambiente("amb_wind");
    }
    else
    {
     // Abfrage 
     if(!game["back2uo_rainfx_enable"]) return;  
 
     // String 
     player thread back2uo\_back2uo_sounds::back2uo_soundambiente("amb_rain");
    }
   }
   
   // Warteschleife 
   wait (2.5);	 
  }
  
  // Warteschleife    
  wait 0.05; 
 } 
}


/////////////////////////////////////////////
// Back2Uo - Weather Fx - Lightning Think //
///////////////////////////////////////////
back2uo_thunder_draw()
{
 // Abfrage
 if(!game["back2uo_weatherfx_enable"] || !game["back2uo_thunderfx_enable"] || !isdefined(game["weather_allow"])) return;
 if(game["german_soldiertype"] == "winterlight" || game["german_soldiertype"] == "winterdark") return;
 
 // For Schleife	
 for (;;)
 {
  // Warteschleife
	wait randomint(60);
 	
 	// Weiterleitung
	back2uo_lightningflash();
 }
}

////////////////////////////////////////////
// Back2Uo - Weather Fx - Lighning Flash //
//////////////////////////////////////////
back2uo_lightningflash()
{
 flash[0] = "quick";
 flash[1] = "double";
 flash[2] = "triple";

 lightfx[0] = "lightning";
	
 wait 0.5;
	
 // String
 if(!isdefined(level.back2uo_playerdimo_xMin) || !isdefined(level.back2uo_playerdimo_yMin) || !isdefined(level.back2uo_mapdimo_zMax)) return;
 xpos = level.back2uo_playerdimo_xMin + randomint(level.back2uo_playerdimo_breite);
 ypos = level.back2uo_playerdimo_yMin + randomint(level.back2uo_playerdimo_laenge);
 zpos = level.back2uo_mapdimo_zMax;	 	
 position = ( xpos, ypos, zpos);

 thread back2uo_thundersound(position);

 flashType = randomint(flash.size);
 lightFx = lightfx[randomInt(lightfx.size)];

 lit_num = 0;

 switch (flash[flashType])
 {
	case "quick":
	{
	 back2uo_thunderdraw(lightFx, position);
	 break;
	}
	case "double":
	{
	 back2uo_thunderdraw(lightFx, position);
	 wait (0.05);
	 back2uo_thunderdraw(lightFx, position);
	 break;
	}
	case "triple":
	{
	 back2uo_thunderdraw(lightFx, position);
	 wait (0.05);
	 back2uo_thunderdraw(lightFx, position);
	 wait (0.5);
	 back2uo_thunderdraw(lightFx, position);
	 break;
	}
 }
}

///////////////////////////////////////////
// Back2Uo - Weather Fx - Thunder Sound //
/////////////////////////////////////////
back2uo_thundersound(position)
{	
 // Weiterleitung
 thread back2uo\_back2uo_sounds::back2uo_soundonplayers("elm_thunder");
}

///////////////////////////////////////
// Back2Uo - Weather Fx - Lightning //
/////////////////////////////////////
back2uo_thunderdraw(lightFx, position)
{
 // String - Ausgabe
 playfx(level.back2uo_effect[lightFx], position);
}

////////////////////////////////
// Back2Uo Coldbreath - Draw //
//////////////////////////////
back2uo_coldbreath_draw()
{
 // Abfrage
 if(!game["back2uo_weatherfx_enable"] || !game["back2uo_coldbreath_enable"]) return;
 
 // String
 self endon("disconnect");
 self notify("spawned");
 
 // Abfrage
 if(game["german_soldiertype"] == "winterlight" || game["german_soldiertype"] == "winterdark")
 {
  // For Schleife
  for(;;)
  {
   // Warteschleife
   wait (2 + randomint(3));

   // While Schleife
   while(isdefined(self) && isPlayer(self) && isAlive(self) && self.sessionstate == "playing")
   {
    // String
	  playfxontag (level.back2uo_breathfx, self, "TAG_EYE");
		
	  // Warteschleife
    wait randomfloatrange(2.5,4.5);
	 }
  }
 } 
}

///////////////////////////////////
// ***************************** //
// * #GCF# German City Fighter * // 
// *   Back2Uo Mod Reloaded    * //
// * ------------------------- * //
// *    Created & Modified     * //
// *           by              * //
// * ------------------------- * //
// * ---> #GCF#Wulf <--------- * //
// * --------> #GCF#R@zor <--- * //
// * ---> #GCF#Lejack <------- * //
// * ------------------------- * //
// *  http://www.gcf-team.com  * //
// ***************************** //
///////////////////////////////////



///////////////////
// Mod Contents //
/////////////////

COD 2:
- Cod 2 Elements adjustable        
- COD 2 Hud Elements revised   
- COD 2 Map Ambiente FX adjustable
- COD 2 Map Vote revised  

MOD:
- Back2uo Mod Config inserted      
- Dimension calculation inserted     
- Health held back inserted
- Weapon Panzerschreck inserted           
- Weapon G43Sniper inserted               
- Medipacks inserted              
- Server Informations inserted      

HUD Elements:
- New Compass inserted           
- Player Stance revised 
- Healthbar inserted               
- Ranking System inserted             
- Player Score revised        
- Team Score revised          
- Hud Ambiente Fx Icons inserted   

Messages:
- Clan Messages inserted        
- Win Messages inserted    
- Wellcome Messages inserted 
- Server Info inserted             
- Status Messages inserted               
- Next Map Messages inserted        

Effects:
- Blood Effects inserted          
- Flak Effects inserted            
- Thunder & Lightning Effects inserted    
- Mortar Effects  inserted         
- Weather Rain Effects inserted    
- Weather Snow Effects inserted   
- Pain & Death Sounds inserted    
- Airplanes inserted                        
- Artillery inserted     
- Cold Breath inserted             

Systems:
- Random Generator for Weather FX inserted   
- Random Generator for War FX inserted       
- Map Systems inserted             
- Camper Protector inserted       
- Spawn Save inserted            
- AFK Protector inserted     



///////////////
// Mod Info //
/////////////

 - "startscript_linux"       = Back2Uo Reloaded Linux Server Startscript
 - "startscript_windows.bat" = Back2Uo Reloaded Windows Server Startscript

[back2uomod]
 - "back2uomod_deutsch.cfg"  = Back2Uo Reloaded Mod Config German 
 - "back2uomod_english.cfg"  = Back2Uo Reloaded Mod Config English 
 - "z_back2uomod_2.0_00.iwd" = Back2Uo Reloaded Mod Datei COD 2 v.1.0
 - "z_back2uomod_2.0_01.iwd" = Back2Uo Reloaded Mod Datei COD 2 v.1.2
 - "z_back2uomod_msg.iwd"    = Back2Uo Reloaded Mod Datei Server Clan Messages


[main]
 - "server.cfg"              = Back2Uo Reloaded Mod Server Config
 - "rotation.cfg"            = Back2Uo Reloaded Mod Rotation Config



///////////////////////
// Mod Installation //
/////////////////////

- the file "back2uomod" into your "Call Of Duty 2" copy. 
- link the "back2uomod/back2uomod_english.cfg" into your server.cfg. 
- exec back2uomod_english.cfg
- or choose the "server.cfg" and "rotation.cfg".



//////////////////////
// Mod Configuring //
////////////////////

- All Mod Functions is adjustable in "back2uomod.cfg".
- Messages are changed in "zzz_back2uomod_msg.iwd".
- Simply with a Zip Software open and the file "b2uomsg.str" work on.



////////////////
// Mod Start //
//////////////

Windows Server:

C:\Programme\Call of Duty\CoD2MP_s.exe +set fs_game back2uomod +set dedicated 2 +exec server.cfg 

- For Windows Server start, can use the "startscript_windows" File.


Linux Server:

screen -d -m -S cod2server /cod2ordner/cod2_lnxded +set fs_game back2uomod +set net_port deinport +set dedicated 2 +exec servercfg.cfg

- For Linux Server start, can use the "startscript_linux" File.



////////////////
// MOD Extra //
//////////////

- For all Back2Uo User under Linux COD 2 v.1.2.
- Please switch off all Messages in your Mod Config.
- This lead to problems with the unofficial "cod2_lnxded".

Config-Instructions:

- set back2uo_clanm_aktiv "0"
- set back2uo_wellm_aktiv "0"
- set back2uo_mapmsg_aktiv "0" 
- set back2uo_servertext_aktiv "0"
- set back2uo_statusmsg_aktiv "0" 



///////////////////
// Contact Data //
/////////////////

Homepage  = www.gcf-team.de / .com
E-Mail    = back2uomod@gcf-team.de